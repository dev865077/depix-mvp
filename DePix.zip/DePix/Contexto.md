# Contexto do MVP

<<<<<<< HEAD
> [!tip]
> Este e o ponto de entrada da documentacao do projeto.
=======
Este e o ponto de entrada da documentacao do projeto.
>>>>>>> origin/main

## Objetivo

Centralizar o contexto do MVP e fixar as decisoes que nao devem mais ficar soltas entre varias notas.

## Decisoes travadas

- `Cloudflare Worker` unico como runtime do MVP
- `Hono` para HTTP, rotas e middleware
- `grammY` para Telegram
- `XState` para conversa e estado do pedido
<<<<<<< HEAD
- `Drizzle ORM` sobre `Cloudflare D1` para persistencia
=======
- `Cloudflare D1` com `SQL cru` para persistencia
- `env.DB.batch()` como padrao obrigatorio para writes criticos multi-tabela
- um bot Telegram por parceiro
- um `Cloudflare Worker` compartilhado entre parceiros
- um `Cloudflare D1` compartilhado com isolamento por `tenantId`
- catalogo e configuracao por parceiro
>>>>>>> origin/main
- `Vitest` + integracao de testes do `Cloudflare Workers` + `MSW`
- `deposit webhook` como fonte primaria de confirmacao
- `deposit-status` e `deposits` apenas como fallback
- split obrigatorio em toda cobranca do MVP
- filas, painel interno e servicos separados ficam fora do MVP

## Ordem de leitura

1. [[Misc/DePix/Faturamento Automações|Faturamento Automacoes]]
2. [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]
3. [[Misc/DePix/Backlog Scrum do MVP|Backlog Scrum do MVP]]
4. [[Misc/DePix/KANBAN|KANBAN]]

## Documentos essenciais

- [[Misc/DePix/Faturamento Automações|Faturamento Automacoes]]
- [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]
- [[Misc/DePix/Backlog Scrum do MVP|Backlog Scrum do MVP]]
<<<<<<< HEAD
=======
- [[Misc/DePix/Contribuicao e PRs|Contribuicao e PRs]]
>>>>>>> origin/main
- [[Misc/DePix/KANBAN|KANBAN]]
- [[Misc/DePix/Mapa de Uso da API|Mapa de Uso da API]]
- [[Misc/DePix/Open-Source para Reduzir Complexidade no MVP|Open-Source para Reduzir Complexidade no MVP]]
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|Pix2DePix API - Documentacao Completa]]

## Plano resumido

<<<<<<< HEAD
- Fundacao: Worker, configuracao segura, `D1`, `Drizzle` e client Eulen
- Bot: webhook Telegram com `grammY`, conversa guiada por `XState` e criacao do pedido
- Cobranca: `deposit` com split, QR ao usuario e persistencia
- Confirmacao: webhook Eulen, mapeamento de status e fallback
- Qualidade: logs fortes e testes extensivos

## Como o sistema funciona de ponta a ponta

O MVP e um bot transacional no Telegram para vender `DePix`.

O fluxo completo e:

1. o usuario entra no bot no Telegram
2. `grammY` recebe a mensagem e entrega para o `Cloudflare Worker`
3. `Hono` roteia a entrada para o fluxo correto
4. `XState` decide em que etapa da conversa e do pedido o usuario esta
5. o sistema coleta ativo, valor e carteira
6. quando os dados minimos ficam completos, o sistema cria ou atualiza um pedido interno
7. o `deposit service` chama a Eulen para gerar a cobranca Pix
8. a Eulen devolve `qrCopyPaste` e `qrImageUrl`
9. o bot responde ao usuario com os dados de pagamento
10. a Eulen envia o `deposit webhook` quando houver confirmacao
11. o `webhook service` persiste o evento e atualiza pedido e cobranca
12. se necessario, o `recheck service` usa `deposit-status` e `deposits` como fallback
13. o sistema conclui o pedido ou envia para tratamento operacional

## Leitura correta da arquitetura

As pecas do MVP sao:

- `Telegram`: canal de entrada do usuario
- `grammY`: camada do bot
- `Hono`: borda HTTP do `Cloudflare Worker`
- `XState`: motor de estados da conversa e do pedido
- `order service`: cria e atualiza o pedido
- `deposit service`: cria a cobranca na Eulen
- `webhook service`: processa confirmacoes de pagamento
- `recheck service`: reconcilia quando webhook falhar, atrasar ou divergir
- `Drizzle + D1`: persistencia de conversa, pedido, cobranca e eventos
- `client Eulen`: camada isolada de integracao HTTP com a API da Eulen

## Papel do `XState`

`XState` nao e detalhe; ele e parte central da arquitetura.

Ele existe para:

- guiar a conversa no Telegram
- controlar as transicoes validas do pedido
- evitar regra espalhada entre bot, servicos e webhook
- impedir regressao de estado e duplicidade de conclusao

Leitura pratica:

- `grammY` recebe a mensagem
- `Hono` entrega para o fluxo interno
- `XState` calcula a proxima transicao valida
- os servicos executam a acao correspondente
- `D1` persiste o novo estado

## Sobre o diagrama simplificado de faturamento

O diagrama de faturamento mostra bem a integracao externa:

- Telegram
- Worker
- banco
- client Eulen
- Eulen API
- webhook de deposito

Mas ele simplifica demais a orquestracao interna e por isso pode passar a impressao errada de que `XState` nao participa.

A leitura correta e:

- o diagrama de faturamento mostra o caminho externo da cobranca e confirmacao
- a arquitetura interna completa inclui `XState` entre a entrada do bot, os servicos de aplicacao e a persistencia
- o nome `Cliente Eulen` significa o client da API da Eulen dentro do nosso sistema, nao um cliente humano

## Regra de entendimento do MVP

Para entender o sistema sem se perder:

1. `grammY` e a interface conversacional
2. `Hono` e a porta de entrada HTTP
3. `XState` e o cerebro do fluxo
4. os services executam cada responsabilidade de negocio
5. `Drizzle + D1` guardam o estado duravel
6. a Eulen cuida da cobranca e da confirmacao primaria
7. o fallback existe para recuperar consistencia quando o webhook nao bastar

=======
- Fundacao: Worker, configuracao segura, `D1`, migrations SQL e client Eulen
- Bot: um bot por parceiro, webhook Telegram com `grammY`, catalogo do parceiro, conversa guiada por `XState` e criacao do pedido
- Cobranca: `deposit` com split, QR ao usuario, persistencia e isolamento por `tenantId`
- Confirmacao: webhook Eulen, mapeamento de status, `batch()` atomico e fallback
- Qualidade: logs fortes e testes extensivos

>>>>>>> origin/main
## Regra de escopo

- um deploy
- um banco
<<<<<<< HEAD
- uma integracao de bot
- uma integracao de pagamento
- nada de microservicos no MVP
=======
- um Worker compartilhado
- um bot por parceiro
- uma integracao de pagamento
- nada de microservicos no MVP

## Governanca de mudancas

Mudancas no codigo devem entrar por branch e Pull Request no GitHub.

Regras base:

- toda PR deve estar ligada a um item do backlog, story ou bug
- uma PR deve tratar uma mudanca coesa e revisavel
- mudancas de arquitetura, schema, fluxo ou integracao devem atualizar a documentacao na mesma PR
- merge em `main` so ocorre com review e validacao minima concluidos
- o padrao de merge do projeto e `Squash`

## Fluxo Simplificado

- O usuario fala com o bot Telegram do parceiro.
- O bot do parceiro chama o Worker compartilhado.
- `Hono` resolve o `tenantId` na entrada e entrega o update ao `grammY`.
- O sistema carrega o catalogo daquele parceiro.
- `grammY` transforma o update em evento de conversa.
- `XState conversa` calcula a transicao valida.
- `Order Service` persiste `currentStep` e dados parciais em `D1` com `SQL cru`, sempre no escopo do `tenantId`.
- Quando o pedido fica completo, o `Deposit Service` cria a cobranca.
- O `Cliente Eulen` resolve a conta correta do tenant e chama `POST /deposit` na `Eulen API`.
- A resposta retorna com `depositEntryId` (`response.id`), `qrCopyPaste` e `qrImageUrl`.
- O sistema persiste `tenantId`, `orderId`, `nonce`, `depositEntryId` e status `pending`, usando `batch()` quando a mesma mudanca tocar mais de uma tabela.
- O `qrId` pode chegar depois, via webhook da Eulen ou pelos fallbacks de reconciliacao.
- O `grammY` envia a mensagem de resposta ao usuario no bot do parceiro.
>>>>>>> origin/main
