# Contribuicao e PRs

Documento ligado a:

- [[Misc/DePix/Contexto|Contexto]]
- [[Misc/DePix/Backlog Scrum do MVP|Backlog Scrum do MVP]]
- [[Misc/DePix/KANBAN|KANBAN]]

## Objetivo

Definir como mudancas no codigo entram no projeto via GitHub, com branch, Pull Request, review e merge.

## Regra geral

- nenhuma mudanca entra direto em `main`
- toda mudanca entra por branch e Pull Request
- toda PR deve estar ligada a um item do backlog, story, task ou bug
- uma PR deve tratar uma mudanca coesa
- mudanca tecnica relevante deve atualizar a documentacao na mesma PR

## Fluxo base

1. escolher o item do backlog, story, task ou bug
2. abrir uma branch propria
3. implementar a mudanca
4. atualizar docs se a mudanca afetar arquitetura, fluxo, schema, integracao ou operacao
5. abrir a Pull Request no GitHub
6. revisar, validar e fazer merge por `Squash`

## Nome de branch

Padrao recomendado:

- `feat/BG-05-catalogo-inicial`
- `fix/US-10-idempotencia-webhook`
- `docs/arquitetura-batch-d1`
- `chore/ajuste-ci-vitest`

Regra:

- prefixo curto e claro
- incluir o identificador do item quando existir
- descrever a mudanca principal, nao o detalhe interno

## Escopo da PR

Uma PR deve:

- tratar uma mudanca coesa
- ser pequena o suficiente para review serio
- nao misturar refactor grande com feature sem necessidade
- nao misturar docs, fix e feature sem relacao direta

## Corpo obrigatorio da PR

Toda PR deve trazer:

- objetivo
- item ligado
- escopo
- fora de escopo
- risco
- validacao executada
- impacto em documentacao

Modelo curto:

```md
## Objetivo

## Item ligado
- BG-00 / US-00 / bug

## Escopo
- ...

## Fora de escopo
- ...

## Risco
- baixo / medio / alto
- principal risco:

## Validacao
- testes rodados:
- checks locais:

## Documentacao
- atualizada / nao aplicavel
```

## Quando a PR deve atualizar docs

Atualizar documentacao na mesma PR quando houver mudanca em:

- arquitetura
- schema
- fluxo de usuario
- integracao externa
- operacao
- observabilidade

Docs mais afetados neste projeto:

- [[Misc/DePix/Contexto|Contexto]]
- [[Misc/DePix/Faturamento Automações|Faturamento Automacoes]]
- [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]
- [[Misc/DePix/Backlog Scrum do MVP|Backlog Scrum do MVP]]

## Review

Antes do merge, a PR deve permitir revisar:

- o que mudou
- por que mudou
- qual risco foi introduzido
- como foi validado
- se a documentacao ficou coerente

PR que nao explica isso direito nao esta pronta para merge.

## Merge

Padrao do projeto:

- branch protegida em `main`
- sem push direto em `main`
- merge por `Squash`
- merge so depois de review e validacao minima

## Regra para PR feita com IA

Se a PR foi montada com ajuda de IA, o corpo deve deixar claro:

- o que foi assumido
- o que foi validado
- o que nao foi validado
- qual risco residual ficou aberto

## Checklist minimo

- item ligado
- branch com nome claro
- escopo coeso
- validacao executada
- docs atualizadas quando aplicavel
- PR pronta para `Squash merge`
