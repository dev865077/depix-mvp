# Open-Source para Reduzir Complexidade no MVP

<<<<<<< HEAD
> [!tip]
> Base de comparacao:
> [[Misc/DePix/Faturamento Automações|Faturamento Automações]]
>
> [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]
>
> [[Misc/DePix/Backlog Scrum do MVP|Backlog Scrum do MVP]]
=======

Base de comparacao:
[[Misc/DePix/Faturamento Automações|Faturamento Automações]]

[[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

[[Misc/DePix/Backlog Scrum do MVP|Backlog Scrum do MVP]]
>>>>>>> origin/main

## Objetivo

Comparar o desenho atual do MVP com projetos open-source que podem reduzir trabalho real da equipe, mantendo o recorte `Cloudflare-first`.

<<<<<<< HEAD
> [!info]
> Premissas travadas nesta analise:
> - `Cloudflare Worker` continua sendo o runtime principal
> - priorizar licencas open-source classicas; quando houver licenciamento misto, isso deve aparecer como contra tecnico
> - a comparacao parte da documentacao atual do MVP, nao de uma implementacao ja pronta
> - data de coleta dos numeros de maturidade: `13 de abril de 2026`
=======

Premissas travadas nesta analise:
- `Cloudflare Worker` continua sendo o runtime principal
- priorizar licencas open-source classicas; quando houver licenciamento misto, isso deve aparecer como contra tecnico
- a comparacao parte da documentacao atual do MVP, nao de uma implementacao ja pronta
- data de coleta dos numeros de maturidade: `13 de abril de 2026`
>>>>>>> origin/main

## Resumo Executivo

| Projeto | Categoria | Encaixe com Cloudflare | Reducao de complexidade | BGs impactados | Recomendacao |
| --- | --- | --- | --- | --- | --- |
| `Hono` | HTTP framework | Alto | Alta | `BG-01`, `BG-03`, `BG-07`, `BG-10` | `Adotar agora` |
| `grammY` | Telegram bot framework | Alto | Alta | `BG-04`, `BG-05`, `BG-06` | `Adotar agora` |
<<<<<<< HEAD
| `Drizzle ORM` | ORM + migrations | Alto | Alta | `BG-02`, `BG-05`, `BG-06`, `BG-07`, parte de `BG-09` | `Adotar agora` |
=======
| `SQL cru sobre D1` | Persistencia SQL | Alto | Media | `BG-02`, `BG-05`, `BG-06`, `BG-07`, parte de `BG-09` | `Adotar agora` |
>>>>>>> origin/main
| `Vitest + Cloudflare Workers + MSW` | Stack de testes | Alto, com nuance | Alta | `BG-11`, `BG-12` | `Adotar agora` |
| `XState` | Maquina de estados | Medio | Media | `BG-05`, `BG-08` | `Adotar agora` |
| `BullMQ` | Filas e jobs | Baixo | Alta fora do recorte | `BG-08`, `BG-09` | `Descartar neste MVP` |
| `Temporal` | Orquestracao duravel | Baixo | Muito alta fora do recorte | `BG-06`, `BG-07`, `BG-08`, `BG-09` | `Descartar neste MVP` |
| `PocketBase` | Backend completo | Baixo | Alta fora do recorte | `BG-02`, `BG-05`, `BG-10` | `Descartar neste MVP` |
| `Appsmith` | Painel interno | Baixo | Alta fora do recorte | `BG-09`, `BG-10` | `Descartar neste MVP` |
| `SigNoz` | Observabilidade | Baixo | Alta fora do recorte | `BG-10`, `BG-11`, `BG-12` | `Descartar neste MVP` |

<<<<<<< HEAD
> [!success]
> Shortlist final para um MVP `Cloudflare-first`:
> - `Hono`
> - `grammY`
> - `XState`
> - `Drizzle ORM`
> - `Vitest` + `Cloudflare Workers` + `MSW`

> [!note]
> `XState` entra no MVP para formalizar tanto a conversa quanto as transicoes do pedido.

> [!info]
> Reavaliacao com alternativas reais:
> - `Hono`, `grammY`, `Drizzle ORM` e a stack de testes continuam como base
> - `XState` foi promovido para o stack oficial do MVP
> - o ponto mais disputado era `grammY`, e o runner-up real e `Telegraf`
> - mesmo com mais stars, `Telegraf` perde em simplicidade para este caso porque a historia de `Cloudflare Workers` esta menos no centro da documentacao do que em `grammY`
=======

Shortlist final para um MVP `Cloudflare-first`:
- `Hono`
- `grammY`
- `XState`
- `Cloudflare D1` + `SQL cru`
- `Vitest` + `Cloudflare Workers` + `MSW`


`XState` entra no MVP para formalizar tanto a conversa quanto as transicoes do pedido.


Reavaliacao com alternativas reais:
- `Hono`, `grammY`, `Cloudflare D1` com `SQL cru` e a stack de testes continuam como base
- `XState` foi promovido para o stack oficial do MVP
- o ponto mais disputado era `grammY`, e o runner-up real e `Telegraf`
- mesmo com mais stars, `Telegraf` perde em simplicidade para este caso porque a historia de `Cloudflare Workers` esta menos no centro da documentacao do que em `grammY`
>>>>>>> origin/main

## Como este documento compara com o desenho atual

| Area           | Hoje no desenho atual                                | Com OSS                                                                                      |
| -------------- | ---------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| HTTP do Worker | `fetch(request)` e middleware feitos na mao          | `Hono` centraliza rotas, middleware, validacao e bindings                                    |
| Telegram       | parsing manual de update, webhook e sessao           | `grammY` entrega `Bot`, `webhookCallback`, `session`, `menu`, `conversations`                |
<<<<<<< HEAD
| Persistencia   | schema, migrations e queries manuais                 | `Drizzle ORM` entrega schema tipado, migrations e queries consistentes                       |
=======
| Persistencia   | schema, migrations e queries manuais                 | `D1` com `SQL cru` mantem a camada pequena e previsivel para este MVP                        |
>>>>>>> origin/main
| Testes         | harness manual, mocks manuais, fetch monkey-patching | `Vitest` + `Cloudflare Workers` + `MSW` entrega runtime de Worker, mocks de rede e testes reaproveitaveis |
| Estados        | `if/else` espalhado                                  | `XState` formaliza estados, eventos e transicoes                                             |

## Impacto direto no backlog

| BG | Dor principal | OSS que reduz trabalho |
|---|---|---|
| `BG-01` | base do Worker e borda HTTP | `Hono` |
<<<<<<< HEAD
| `BG-02` | persistencia e migrations | `Drizzle ORM` |
| `BG-03` | client Eulen e padrao de integracao | `Hono` parcialmente |
| `BG-04` | webhook e comandos do Telegram | `grammY` |
| `BG-05` | conversa persistida e pedido em draft | `grammY`, `Drizzle ORM`, `XState` |
| `BG-06` | cobranca com split e entrega de QR | `grammY`, `Drizzle ORM` |
| `BG-07` | webhook de deposito e eventos externos | `Hono`, `Drizzle ORM` |
| `BG-08` | mapeamento de status e saida do pedido | `XState` |
| `BG-09` | recheck e reconciliacao | `Drizzle ORM` parcialmente |
=======
| `BG-02` | persistencia e migrations | `D1` + `SQL cru` |
| `BG-03` | client Eulen e padrao de integracao | `Hono` parcialmente |
| `BG-04` | webhook e comandos do Telegram | `grammY` |
| `BG-05` | conversa persistida e pedido em draft | `grammY`, `D1` + `SQL cru`, `XState` |
| `BG-06` | cobranca com split e entrega de QR | `grammY`, `D1` + `SQL cru` |
| `BG-07` | webhook de deposito e eventos externos | `Hono`, `D1` + `SQL cru` |
| `BG-08` | mapeamento de status e saida do pedido | `XState` |
| `BG-09` | recheck e reconciliacao | `D1` + `SQL cru` parcialmente |
>>>>>>> origin/main
| `BG-10` | logs estruturados | `Hono` parcialmente |
| `BG-11` e `BG-12` | testes unitarios, integracao, webhook e fluxo critico | `Vitest` + `Cloudflare Workers` + `MSW` |

## Criterios de avaliacao

- compatibilidade real com `Cloudflare Workers`
- quantidade de codigo proprio que deixa de existir
- ganho direto sobre `BGs` do backlog
- maturidade do projeto
- licenca
- custo de adocao
- risco de lock-in arquitetural

## Como a simplicidade pesa na decisao

Para este MVP, a ordem de peso usada nesta nota e:

1. encaixar bem em `Cloudflare Workers`
2. reduzir glue code proprio
3. reduzir numero de decisoes de implementacao
4. ja cobrir partes relevantes do backlog sem plugins paralelos demais
5. maturidade do projeto

<<<<<<< HEAD
> [!warning]
> `stars` entram na analise, mas nao definem a escolha sozinhos. Para este caso, simplicidade operacional e encaixe no runtime valem mais do que popularidade bruta.
=======

`stars` entram na analise, mas nao definem a escolha sozinhos. Para este caso, simplicidade operacional e encaixe no runtime valem mais do que popularidade bruta.
>>>>>>> origin/main

## Comparativo de alternativas reais por categoria

## Telegram: qual framework usar

| Projeto                                                                   | Evidencia oficial de Workers                                                            | O que ja vem pronto                                                         | Maturidade                                 | Simplicidade no nosso caso | Veredito                 |
| ------------------------------------------------------------------------- | --------------------------------------------------------------------------------------- | --------------------------------------------------------------------------- | ------------------------------------------ | -------------------------- | ------------------------ |
| [`grammY`](https://grammy.dev/hosting/cloudflare-workers)                 | guia oficial para `Cloudflare Workers` e bundle `grammy/web` voltado a Workers          | `session`, `conversations`, `menu`, `auto-retry`, ecossistema oficial amplo | `3.5k` stars, `144` forks, `915` commits   | Muito alta                 | `Melhor escolha`         |
| [`Telegraf`](https://github.com/telegraf/telegraf)                        | README cita modulo de integracao com `Cloudflare Workers`; release v5 diz edge runtimes | middleware maduro, webhook, sessao/ecossistema relevante                    | `9.1k` stars, `962` forks, `1,699` commits | Media                      | `Runner-up`              |
| [`node-telegram-bot-api`](https://github.com/yagop/node-telegram-bot-api) | sem foco oficial em Workers; exemplo principal usa polling                              | client e handlers basicos                                                   | `9.1k` stars, `1.7k` forks, `680` commits  | Baixa                      | `Nao escolher`           |
| [`GramIO`](https://gramio.dev/)                                           | projeto diz `multi-runtime`, mas nao achei documentacao oficial equivalente de Workers  | scaffold, tipagem forte, plugins                                            | `243` stars, `9` forks, `339` commits      | Media                      | `Observar`               |
| [`WorkerGram`](https://github.com/nghlt/workergram)                       | biblioteca focada explicitamente em `Cloudflare Workers`                                | handlers e contexto focados em Workers                                      | `62` stars, `19` forks, `76` commits       | Media                      | `Promissor, mas pequeno` |

### Por que `grammY` vence

- `grammY` e o unico da lista que combina, ao mesmo tempo:
  - guias oficiais dedicados para `Cloudflare Workers`
  - bundle explicitamente pensado para Workers
  - ecossistema oficial pronto para `session`, `conversations`, `menu` e `auto-retry`
- `Telegraf` e a alternativa mais forte em popularidade, mas a propria documentacao principal ainda gira muito em torno de `bot.launch`, `createServer`, `systemd` e `pm2`, o que denuncia um centro de gravidade mais Node-classico.
- `node-telegram-bot-api` e simples como client, mas simples no sentido errado para o nosso caso: ele simplifica pouco do backlog de conversa, sessao e fluxo.
- `GramIO` parece tecnicamente bom, mas hoje ainda e pequeno demais para ser a aposta principal deste MVP.
- `WorkerGram` tem o melhor marketing de encaixe em Workers, mas ainda esta muito abaixo em maturidade e ecossistema.

<<<<<<< HEAD
> [!success]
> Se a pergunta for apenas `grammY` ou `Telegraf`, a resposta para este MVP e:
> - `grammY` se a prioridade maxima for simplicidade em `Cloudflare Workers`
> - `Telegraf` so faria mais sentido se a equipe ja dominasse `Telegraf` e quisesse reaproveitar repertorio existente
=======

Se a pergunta for apenas `grammY` ou `Telegraf`, a resposta para este MVP e:
- `grammY` se a prioridade maxima for simplicidade em `Cloudflare Workers`
- `Telegraf` so faria mais sentido se a equipe ja dominasse `Telegraf` e quisesse reaproveitar repertorio existente
>>>>>>> origin/main

## HTTP do Worker: qual camada de borda usar

| Projeto | Evidencia oficial de Workers | O que reduz | Maturidade | Simplicidade no nosso caso | Veredito |
|---|---|---|---|---|---|
| [`Hono`](https://hono.dev/docs/getting-started/cloudflare-workers) | docs oficiais de `Cloudflare Workers` e GA em Cloudflare | rotas, middleware, tipagem, request handling | `29.9k` stars, `1k` forks, `2,595` commits | Muito alta | `Melhor escolha` |
| [`itty-router`](https://github.com/kwhitley/itty-router) | feito para serverless e citado para Cloudflare | roteamento ultraleve e middleware pequeno | `2k` stars, `82` forks, `724` commits | Alta se o escopo for minimo | `Boa alternativa minimalista` |
| `fetch` puro | nativo do runtime | zero dependencia | `n/a` | Baixa para este backlog | `Nao escolher` |

### Por que `Hono` vence

- `itty-router` e excelente se o problema for apenas rotear requests.
- O nosso problema nao e apenas rotear requests. Tambem envolve middleware, webhook, auth, logs e tipagem de borda.
- `Hono` ganha porque reduz mais codigo proprio sem sair do recorte `Cloudflare-first`.

## Persistencia: qual camada de dados usar

| Projeto | Evidencia oficial de Workers/D1 | O que reduz | Maturidade | Simplicidade no nosso caso | Veredito |
|---|---|---|---|---|---|
<<<<<<< HEAD
| [`Drizzle ORM`](https://orm.drizzle.team/docs/connect-cloudflare-d1) | documentacao oficial para `Cloudflare D1` | schema tipado, queries, migrations | `33.8k` stars, `1.3k` forks, `2,932` commits | Muito alta | `Melhor escolha` |
| [`Kysely`](https://kysely.dev/) | roda em `Cloudflare Workers`, mas o discurso oficial e mais geral | query builder tipado e migrations controladas | `13.7k` stars, `401` forks, `1,385` commits | Media | `Runner-up` |
| [`Prisma`](https://docs.prisma.io/docs/v6/orm/overview/databases/cloudflare-d1) | docs oficiais para `D1`, mas em `Preview` | schema, client, migrate | `45.8k` stars, `2.2k` forks, `12,207` commits | Media para baixa | `Forte, mas nao simples` |
| SQL cru | nativo | nenhuma camada extra | `n/a` | Baixa | `Nao escolher` |

### Por que `Drizzle ORM` vence

- `Drizzle` tem caminho oficial direto para `Cloudflare D1`.
- `Kysely` e forte e elegante, especialmente para quem gosta de SQL mais explicito, mas aqui ele nao aparece com o mesmo caminho oficial direto para `D1`.
- `Prisma` ficou mais forte em `Cloudflare`, mas a propria documentacao marca `D1` como `Preview` e exige `@prisma/adapter-d1` mais workflow de migracao com `Wrangler` e `prisma migrate diff`.
- Para o nosso objetivo, `Drizzle` tem o melhor equilibrio entre tipagem, simplicidade e encaixe nativo.
=======
| SQL cru | nativo em `Cloudflare D1` | nenhuma camada extra; queries e migrations sob controle direto da equipe | `n/a` | Muito alta | `Escolha do MVP` |
| [`Drizzle ORM`](https://orm.drizzle.team/docs/connect-cloudflare-d1) | documentacao oficial para `Cloudflare D1` | schema tipado, queries, migrations | `33.8k` stars, `1.3k` forks, `2,932` commits | Alta | `Considerado e descartado` |
| [`Kysely`](https://kysely.dev/) | roda em `Cloudflare Workers`, mas o discurso oficial e mais geral | query builder tipado e migrations controladas | `13.7k` stars, `401` forks, `1,385` commits | Media | `Descartar neste MVP` |
| [`Prisma`](https://docs.prisma.io/docs/v6/orm/overview/databases/cloudflare-d1) | docs oficiais para `D1`, mas em `Preview` | schema, client, migrate | `45.8k` stars, `2.2k` forks, `12,207` commits | Media para baixa | `Descartar neste MVP` |

### Por que `SQL cru` vence

- o schema do MVP e pequeno e conhecido
- a equipe ja domina SQL e nao precisa pagar curva de aprendizado extra
- `D1` continua como banco unico, sem ORM e sem query builder adicional
- migrations SQL versionadas e modulos de repositorio bastam para manter ordem
- o principal risco aqui nao e expressividade da camada de dados; e espalhar SQL em handlers, o que deve ser evitado pela estrutura do projeto

### O que muda na disciplina tecnica

- criar migrations SQL versionadas
- centralizar queries por modulo ou repositorio
- manter `orderId`, `depositEntryId` e `nonce` relacionaveis
- usar `env.DB.prepare(...).bind(...).run()` ou equivalente nativo do `D1`
- nao espalhar SQL cru em rotas HTTP ou handlers de webhook
>>>>>>> origin/main

## Testes: qual stack usar

| Projeto | Evidencia oficial | O que reduz | Maturidade | Simplicidade no nosso caso | Veredito |
|---|---|---|---|---|---|
| `Vitest` + docs oficiais do Cloudflare + `MSW` | Cloudflare tem integracao oficial com `Vitest`; `MSW` funciona em qualquer setup | setup de Worker, mocks de rede, reaproveitamento entre camadas | muito alta | Muito alta | `Melhor escolha` |
| [`Jest`](https://jestjs.io/) + mocks manuais | excelente framework geral, sem foco nativo em Workers | runner e mocking classicos | muito alta | Media | `Runner-up` |
| `vi.mock(fetch)` ou monkey-patch manual | sem dependencia extra | testes muito locais | `n/a` | Baixa | `Nao escolher` |

### Por que a stack oficial vence

- `Jest` continua excelente em termos gerais.
- Para `Cloudflare Workers`, o melhor ponto de partida e usar o caminho que o proprio Cloudflare documenta.
- `MSW` melhora a parte mais chata do teste de integracao: parar de stubbar `fetch` em toda parte e descrever comportamento de rede uma vez so.

## O que mudou depois da comparacao ampliada

- `grammY` continua escolhido, mas agora com justificativa comparativa real contra `Telegraf`, `node-telegram-bot-api`, `GramIO` e `WorkerGram`
- `Hono` continua escolhido, mas com `itty-router` registrado como alternativa minimalista legitima
<<<<<<< HEAD
- `Drizzle ORM` continua escolhido, agora comparado explicitamente com `Kysely`, `Prisma` e SQL cru
=======
- `SQL cru` sobre `D1` passa a ser a base do MVP
- `Drizzle ORM` foi considerado e descartado por custo de adocao desnecessario neste recorte
>>>>>>> origin/main
- a stack de testes continua a mesma, agora comparada explicitamente com `Jest`

## Projetos compativeis com o desenho atual

## Hono

<<<<<<< HEAD
> [!success]
> Decisao recomendada: `Adotar agora`
=======

Decisao recomendada: `Adotar agora`
>>>>>>> origin/main

### O que e

`Hono` e um framework HTTP pequeno para runtimes JavaScript. O proprio projeto afirma que funciona em `Cloudflare Workers`, entre outros runtimes.

### Por que reduz complexidade no nosso caso

No desenho atual, toda a borda HTTP do Worker precisaria ser feita na mao:
- roteamento
- parsing de path
- extracao de headers
- middleware de auth
- request id
- logger
- timeout
- uso tipado de `env`

Com `Hono`, isso deixa de ser uma colecao de utilitarios soltos e vira uma camada unica de borda.

### O que deixamos de construir manualmente

- `switch`/`if` manual por rota
- wrappers proprios para `Authorization`
- wrappers proprios para `requestId`
- wrappers proprios para logger e timeout
- cola manual entre `fetch`, `scheduled` e bindings

### BGs afetados

- `BG-01`
- `BG-03`
- `BG-07`
- `BG-10`

### Aderencia ao desenho atual

Encaixe muito alto. A documentacao oficial tem pagina propria para `Cloudflare Workers`, mostra `fetch`, `scheduled`, uso de `c.env`, e o ecossistema do framework cobre middleware de auth, logger, request id e timeout.

### O que fazer se adotarmos

1. Criar o Worker principal em `Hono`.
2. Mover o webhook da Eulen para rota dedicada.
3. Mover o webhook do Telegram para rota dedicada.
4. Centralizar `Authorization`, `requestId`, logs e timeout em middleware.
5. Tipar bindings e secrets no app, em vez de espalhar acesso a `env`.

### Custo de adocao

Baixo. O ganho aparece cedo e sem revirar a arquitetura.

### Tamanho e maturidade

- Porte percebido: `grande`
- Licenca: `MIT`
- Stars: `29.9k`
- Forks: `1.0k`
- Commits: `2,595`
- Coleta: `13 de abril de 2026`

### Hoje

```ts
export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/webhooks/eulen/deposit" && request.method === "POST") {
      const auth = request.headers.get("Authorization");
      if (auth !== `Bearer ${env.WEBHOOK_SECRET}`) {
        return new Response("unauthorized", { status: 401 });
      }

      const payload = await request.json();
      await handleDepositWebhook(payload, env);
      return new Response("ok");
    }

    if (url.pathname === "/health" && request.method === "GET") {
      return new Response("ok");
    }

    return new Response("not found", { status: 404 });
  },
};
```

### Com Hono

```ts
import { Hono } from "hono";
import { bearerAuth } from "hono/bearer-auth";
import { requestId } from "hono/request-id";
import { logger } from "hono/logger";
import { timeout } from "hono/timeout";

type Bindings = {
  WEBHOOK_SECRET: string;
};

const app = new Hono<{ Bindings: Bindings }>();

app.use("*", requestId());
app.use("*", logger());
app.use("/webhooks/*", timeout(15_000));

app.get("/health", (c) => c.text("ok"));

app.use(
  "/webhooks/eulen/*",
  (c, next) =>
    bearerAuth({ token: c.env.WEBHOOK_SECRET })(c, next),
);

app.post("/webhooks/eulen/deposit", async (c) => {
  const payload = await c.req.json();
  await handleDepositWebhook(payload, c.env);
  return c.text("ok");
});

export default app;
```

### Leitura pratica

`Hono` nao resolve a regra de negocio. Ele resolve a borda. Isso ja tira muito atrito do MVP.

### Fontes oficiais

- [Hono Cloudflare Workers](https://hono.dev/docs/getting-started/cloudflare-workers)
- [Hono GitHub](https://github.com/honojs/hono)

## grammY

<<<<<<< HEAD
> [!success]
> Decisao recomendada: `Adotar agora`
=======

Decisao recomendada: `Adotar agora`
>>>>>>> origin/main

### O que e

`grammY` e um framework de bots para Telegram. O projeto tem guia oficial para `Cloudflare Workers`.

### Por que reduz complexidade no nosso caso

No desenho atual, o canal Telegram teria de resolver manualmente:
- webhook do Telegram
- parse de update
- roteamento de comandos
- sessao
- menu
- conversa passo a passo
- retry e throttling

`grammY` ja entrega um ecossistema pronto para isso.

### O que deixamos de construir manualmente

- parse cru do payload do Telegram
- roteador de comandos
- camada propria de sessao
- menus e teclados ad hoc
- fluxo de conversa com muito `if/else`

### BGs afetados

- `BG-04`
- `BG-05`
- `BG-06`

### Aderencia ao desenho atual

Encaixe alto. O guia oficial cobre `Cloudflare Workers`, e o ecossistema oficial ja entrega `session`, `conversations`, `menu` e `auto-retry`.

### O que fazer se adotarmos

1. Criar o bot com `grammY`.
2. Expor o webhook do Telegram via rota do Worker.
3. Usar `session` para estado curto da conversa.
4. Usar `conversations` para o fluxo `ativo -> valor -> carteira`.
5. Usar `menu` para escolhas curtas e `auto-retry`/`throttler` onde fizer sentido.

### Custo de adocao

Baixo a medio. Entra cedo, mas muda a forma como o canal sera implementado.

### Tamanho e maturidade

- Porte percebido: `medio`
- Licenca: `MIT`
- Stars: `3.5k`
- Forks: `144`
- Commits: `915`
- Coleta: `13 de abril de 2026`

### Hoje

```ts
async function handleTelegramUpdate(update: TelegramUpdate, env: Env) {
  const message = update.message?.text ?? "";
  const chatId = update.message?.chat.id;

  if (!chatId) return;

  if (message === "/start") {
    await sendTelegramMessage(chatId, "Escolha o ativo.");
    return;
  }

  const session = await loadSession(chatId);
  const nextState = advanceConversation(session, message);
  await saveSession(chatId, nextState);
  await sendTelegramMessage(chatId, nextState.reply);
}
```

### Com grammY

```ts
import { Bot, session, webhookCallback } from "grammy";
import { conversations, createConversation } from "@grammyjs/conversations";
import { Menu } from "@grammyjs/menu";

type SessionData = {
  ativo?: string;
  valor?: number;
  carteira?: string;
};

const bot = new Bot<Context>(env.BOT_TOKEN);

bot.use(session({ initial: (): SessionData => ({}) }));
bot.use(conversations());

const ativoMenu = new Menu("ativo-menu")
<<<<<<< HEAD
  .text("BTC", async (ctx) => {
    ctx.session.ativo = "BTC";
    await ctx.reply("Digite o valor.");
  })
  .text("USDT", async (ctx) => {
    ctx.session.ativo = "USDT";
=======
  .text("DePix", async (ctx) => {
    ctx.session.ativo = "DePix";
>>>>>>> origin/main
    await ctx.reply("Digite o valor.");
  });

bot.use(ativoMenu);

bot.command("start", async (ctx) => {
  await ctx.reply("Escolha o ativo.", { reply_markup: ativoMenu });
});

export const telegramWebhook = webhookCallback(bot, "cloudflare-mod");
```

### Leitura pratica

No nosso caso, `grammY` reduz muito mais trabalho que escrever um adaptador Telegram proprio.

### Fontes oficiais

- [grammY Cloudflare Workers](https://grammy.dev/hosting/cloudflare-workers)
- [grammY GitHub](https://github.com/grammyjs/grammY)

<<<<<<< HEAD
## Drizzle ORM

> [!success]
> Decisao recomendada: `Adotar agora`

### O que e

`Drizzle ORM` e um ORM headless com schema tipado e migrations. A documentacao oficial afirma suporte completo a `Cloudflare D1` e ao ambiente `Cloudflare Workers`.
=======
## SQL cru sobre D1


Decisao recomendada: `Adotar agora`

### O que e

Persistencia nativa do MVP usando `Cloudflare D1` com queries SQL escritas diretamente pela equipe.
>>>>>>> origin/main

### Por que reduz complexidade no nosso caso

O desenho atual precisa de:
- schema de `pedido`, `cobranca`, `evento`
- migrations
- queries de leitura e escrita
<<<<<<< HEAD
- coerencia de tipos
- menos risco de drift entre codigo e banco

Sem uma camada como `Drizzle`, isso tende a virar SQL solto e repositorios pouco tipados.

### O que deixamos de construir manualmente

- migrations manuais sem padrao
- modelagem em interfaces desconectadas do banco
- wrappers proprios de query builder
- duplicacao de tipos entre banco e aplicacao
=======
- rastreabilidade entre identificadores

Como o schema do MVP e pequeno e o time ja domina SQL, adicionar ORM agora so aumenta a superficie de adocao.

### O que precisa existir para nao virar bagunca

- migrations SQL versionadas
- modulos ou repositorios por agregado principal
- queries de leitura e escrita isoladas da borda HTTP
- convencoes claras para `orderId`, `depositEntryId` e `nonce`
>>>>>>> origin/main

### BGs afetados

- `BG-02`
- `BG-05`
- `BG-06`
- `BG-07`
- parte de `BG-09`

### Aderencia ao desenho atual

<<<<<<< HEAD
Encaixe alto se a persistencia seguir em um banco SQL compativel com a stack Cloudflare, especialmente `D1`.

### O que fazer se adotarmos

1. Modelar `orders`, `charges` e `deposit_events` em schema Drizzle.
2. Gerar migrations com `drizzle-kit`.
3. Centralizar acesso a persistencia em queries tipadas.
4. Amarrar `orderId`, `depositId` e `nonce` nas tabelas principais.
5. Usar a mesma camada para reconciliacao e consulta operacional.

### Custo de adocao

Baixo a medio. Exige escolher bem o schema inicial, mas reduz retrabalho logo no inicio.

### Tamanho e maturidade

- Porte percebido: `grande`
- Licenca: `Apache-2.0`
- Stars: `33.8k`
- Forks: `1.3k`
- Commits: `2,932`
- Coleta: `13 de abril de 2026`
=======
Encaixe total. `D1` continua como banco unico e o Worker continua falando direto com o runtime nativo da Cloudflare.

### O que fazer se adotarmos

1. Modelar `orders`, `deposits` e `deposit_events` em SQL.
2. Versionar migrations SQL junto do projeto.
3. Criar repositorios ou modulos de acesso para cada agregado principal.
4. Amarrar `orderId`, `depositEntryId` e `nonce` nas tabelas principais.
5. Reaproveitar a mesma camada em reconciliacao e consulta operacional.

### Custo de adocao

Baixo. O custo maior passa a ser disciplina de organizacao, nao ferramenta nova.
>>>>>>> origin/main

### Hoje

```ts
type Order = {
  orderId: string;
  userId: string;
<<<<<<< HEAD
  ativo: "BTC" | "USDT" | "DePix";
=======
  ativo: "DePix";
>>>>>>> origin/main
  amountInCents: number;
  walletAddress: string;
  splitFee: number;
  statusInterno: string;
};

await env.DB.prepare(
  `insert into orders (
    order_id, user_id, ativo, amount_in_cents, wallet_address, split_fee, status_interno
  ) values (?, ?, ?, ?, ?, ?, ?)`
)
  .bind(
    order.orderId,
    order.userId,
    order.ativo,
    order.amountInCents,
    order.walletAddress,
    order.splitFee,
    order.statusInterno,
  )
  .run();
```

<<<<<<< HEAD
### Com Drizzle ORM

```ts
import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { drizzle } from "drizzle-orm/d1";
import { eq } from "drizzle-orm";

export const orders = sqliteTable("orders", {
  orderId: text("order_id").primaryKey(),
  userId: text("user_id").notNull(),
  ativo: text("ativo").notNull(),
  amountInCents: integer("amount_in_cents").notNull(),
  walletAddress: text("wallet_address").notNull(),
  splitFee: integer("split_fee").notNull(),
  statusInterno: text("status_interno").notNull(),
});

const db = drizzle(env.DB);

await db.insert(orders).values({
  orderId: order.orderId,
  userId: order.userId,
  ativo: order.ativo,
  amountInCents: order.amountInCents,
  walletAddress: order.walletAddress,
  splitFee: order.splitFee,
  statusInterno: "pending",
});

const storedOrder = await db
  .select()
  .from(orders)
  .where(eq(orders.orderId, order.orderId));
=======
### Exemplo de repositorio minimo

```ts
export async function insertOrder(env: Env, order: Order) {
  return env.DB.prepare(
    `insert into orders (
      order_id, user_id, ativo, amount_in_cents, wallet_address, split_fee, status_interno
    ) values (?, ?, ?, ?, ?, ?, ?)`
  )
    .bind(
      order.orderId,
      order.userId,
      order.ativo,
      order.amountInCents,
      order.walletAddress,
      order.splitFee,
      order.statusInterno,
    )
    .run();
}
>>>>>>> origin/main
```

### Leitura pratica

<<<<<<< HEAD
`Drizzle` nao substitui a modelagem do dominio. Ele substitui trabalho repetitivo e propenso a erro na camada de persistencia.

### Fontes oficiais

- [Drizzle Cloudflare D1](https://orm.drizzle.team/docs/connect-cloudflare-d1)
- [Drizzle ORM GitHub](https://github.com/drizzle-team/drizzle-orm)

## Vitest + Cloudflare Workers + MSW

> [!success]
> Decisao recomendada: `Adotar agora`
=======
`SQL cru` funciona bem neste MVP porque a equipe entende a ferramenta, o schema e pequeno e a disciplina de repositorio resolve o principal risco de manutencao.

### Registro da decisao

`Drizzle ORM` foi considerado, mas descartado neste MVP por custo de adocao desnecessario diante de um schema pequeno e da preferencia explicita da equipe por SQL direto.

## Vitest + Cloudflare Workers + MSW


Decisao recomendada: `Adotar agora`
>>>>>>> origin/main

### O que e

Esta combinacao cobre quase toda a necessidade de testes do MVP:
- `Vitest` como test runner
- `Miniflare` como simulacao local do runtime de Workers
- `MSW` como camada de mocks HTTP reaproveitavel

### Por que reduz complexidade no nosso caso

Sem isso, a equipe tende a cair em:
- monkey-patch de `fetch`
- mocks quebradicos
- testes que nao parecem `Cloudflare Workers`
- duplicacao de mocks entre unitario, integracao e E2E tecnico

Com a stack certa, o mesmo comportamento de rede pode ser reaproveitado em varios niveis.

### O que deixamos de construir manualmente

- harness proprio de testes para Worker
- mocks HTTP espalhados
- stub improvisado de bindings
- setup diferente para cada camada de teste

### BGs afetados

- `BG-11`
- `BG-12`

### Aderencia ao desenho atual

Encaixe alto, com uma nuance importante:
- a documentacao oficial do Cloudflare tem integracao propria de `Vitest` para Workers
- o Cloudflare tambem documenta `Miniflare` como simulador para desenvolvimento e testes de Workers
- o repositorio historico `cloudflare/miniflare` foi arquivado em `13 de marco de 2025`

Ou seja: o conceito continua valido, mas a adocao correta deve seguir a stack atual do Cloudflare Workers, nao travar o projeto no repositorio legado.

<<<<<<< HEAD
> [!warning]
> O ponto certo aqui nao e "adotar um repo arquivado". O ponto certo e adotar a historia de testes atual do Cloudflare, em que `Vitest` roda com suporte ao runtime de Workers e `Miniflare` aparece como simulador local.
=======

O ponto certo aqui nao e "adotar um repo arquivado". O ponto certo e adotar a historia de testes atual do Cloudflare, em que `Vitest` roda com suporte ao runtime de Workers e `Miniflare` aparece como simulador local.
>>>>>>> origin/main

### O que fazer se adotarmos

1. Padronizar `Vitest` como runner.
2. Configurar a integracao de testes do Cloudflare Workers.
3. Reaproveitar `MSW` para simular API da Eulen.
4. Criar testes unitarios, integracao de webhook e cenarios de falha em cima do mesmo setup.
5. Evitar mocks manuais de `fetch` sempre que o comportamento de rede puder vir de handlers `MSW`.

### Custo de adocao

Baixo. Esta e a stack com melhor relacao entre esforco e confiabilidade.

### Tamanho e maturidade

- `Vitest`
- Licenca: `MIT`
- Stars: `16.4k`
- Forks: `1.7k`
- Commits: `5,652`
- `MSW`
- Licenca: `MIT`
- Stars: `17.8k`
- Forks: `608`
- Commits: `1,748`
- `Miniflare` historico
- Licenca: `MIT`
- Stars: `3.9k`
- Forks: `212`
- Commits: `751`
- Observacao: repo v2 arquivado; seguir a stack atual do Cloudflare Workers
- Coleta: `13 de abril de 2026`

### Hoje

```ts
import { describe, it, expect, vi } from "vitest";

describe("deposit", () => {
  it("marca pedido como pending", async () => {
    globalThis.fetch = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ id: "dep_1", qrCopyPaste: "pix", async: false }))
    ) as typeof fetch;

    const result = await createDeposit(orderInput, env);

    expect(result.id).toBe("dep_1");
  });
});
```

### Com Vitest + Cloudflare Workers + MSW

```ts
import { http, HttpResponse } from "msw";
import { setupServer } from "msw/node";
import { describe, it, expect } from "vitest";
import { env } from "cloudflare:workers";
import worker from "../src";

const server = setupServer(
  http.post("https://api.eulen.app/deposit", async () => {
    return HttpResponse.json({
      id: "dep_1",
      qrCopyPaste: "pix",
      qrImageUrl: "https://example/qr.png",
      async: false,
    });
  }),
);

describe("deposit", () => {
  it("cria cobranca no runtime de Worker", async () => {
    server.listen();

    const request = new Request("http://local/deposit", { method: "POST" });
    const response = await worker.fetch(request, env, {} as ExecutionContext);

    expect(response.status).toBe(200);

    server.close();
  });
});
```

### Leitura pratica

Esta stack reduz mais risco do que qualquer test harness caseiro.

### Fontes oficiais

- [Vitest Guide](https://vitest.dev/guide/)
- [MSW](https://mswjs.io/)
- [Cloudflare Vitest integration](https://developers.cloudflare.com/workers/testing/vitest-integration/)
- [Cloudflare Miniflare docs](https://developers.cloudflare.com/workers/testing/miniflare/)
- [Vitest GitHub](https://github.com/vitest-dev/vitest)
- [MSW GitHub](https://github.com/mswjs/msw)
- [Miniflare GitHub](https://github.com/cloudflare/miniflare)

## XState

<<<<<<< HEAD
> [!success]
> Decisao recomendada: `Adotar agora`
=======

Decisao recomendada: `Adotar agora`
>>>>>>> origin/main

### O que e

`XState` e uma biblioteca para modelar logica com maquinas de estados e actors.

### Por que reduz complexidade no nosso caso

Ela ajuda em dois pontos do MVP:
- a conversa do Telegram
- o estado do pedido

Se a equipe fizer esses fluxos na mao, a chance de espalhar regras por varios pontos e alta.

### O que deixamos de construir manualmente

- transicoes implicitas em `if/else`
- regras de estado espalhadas
- interpretacao informal do fluxo

### BGs afetados

- `BG-05`
- `BG-08`

### Aderencia ao desenho atual

Boa. O projeto afirma uso em frontend, backend ou onde JavaScript rodar. O encaixe com `Cloudflare Workers` aqui e uma inferencia tecnica razoavel, nao uma pagina oficial de "Cloudflare support".

### O que fazer se adotarmos

1. Modelar a conversa como maquina explicita.
2. Modelar o pedido como maquina separada.
3. Manter os eventos principais como `START`, `ASSET_SELECTED`, `AMOUNT_FILLED`, `WALLET_FILLED`, `DEPOSIT_CREATED`, `WEBHOOK_RECEIVED`.
4. Evitar espalhar transicoes de negocio fora das maquinas.

### Custo de adocao

Medio. A equipe vai pagar um pequeno custo inicial para ganhar transicoes explicitas e menos ambiguidade de fluxo.

### Tamanho e maturidade

- Porte percebido: `grande`
- Licenca: `MIT`
- Stars: `29.5k`
- Forks: `1.4k`
- Commits: `6,916`
- Coleta: `13 de abril de 2026`

### Hoje

```ts
function nextConversationState(state: State, input: string): State {
  if (state.step === "ativo") {
    return { ...state, ativo: input, step: "valor" };
  }

  if (state.step === "valor") {
    return { ...state, valor: Number(input), step: "carteira" };
  }

  if (state.step === "carteira") {
    return { ...state, carteira: input, step: "confirmacao" };
  }

  return state;
}
```

### Com XState

```ts
import { createMachine, assign } from "xstate";

const orderConversationMachine = createMachine({
  id: "orderConversation",
  initial: "ativo",
  context: {
    ativo: undefined as string | undefined,
    valor: undefined as number | undefined,
    carteira: undefined as string | undefined,
  },
  states: {
    ativo: {
      on: {
        ASSET_SELECTED: {
          target: "valor",
          actions: assign({ ativo: ({ event }) => event.ativo }),
        },
      },
    },
    valor: {
      on: {
        AMOUNT_FILLED: {
          target: "carteira",
          actions: assign({ valor: ({ event }) => event.valor }),
        },
      },
    },
    carteira: {
      on: {
        WALLET_FILLED: {
          target: "confirmacao",
          actions: assign({ carteira: ({ event }) => event.carteira }),
        },
      },
    },
    confirmacao: {},
  },
});
```

### Leitura pratica

`XState` entra bem neste MVP porque a conversa e o pedido ja sao dois fluxos com estados claros e risco de espalhamento de regra.

### Fontes oficiais

- [XState docs](https://stately.ai/docs/xstate)
- [XState GitHub](https://github.com/statelyai/xstate)

## Projetos fortes, mas fora do recorte Cloudflare-first

## BullMQ

<<<<<<< HEAD
> [!danger]
> Decisao: `Descartar neste MVP`
=======

Decisao: `Descartar neste MVP`
>>>>>>> origin/main

### Onde ajudaria

- retries
- jobs atrasados
- reconciliacao em background
- tratamento operacional

### Por que parece atraente

O produto cobre fila, retry, rate limit, delayed jobs, repeatable jobs e concurrency.

### Por que nao entra agora

Ele e uma biblioteca de filas baseada em `Redis`. Isso empurra o MVP para fora do desenho `Cloudflare-first` e exige processo de worker dedicado.

### Qual BG ajudaria se o recorte mudasse

- `BG-08`
- `BG-09`

### Tamanho e maturidade

- Licenca: `MIT`
- Stars: `8.7k`
- Forks: `592`
- Commits: `3,331`
- Coleta: `13 de abril de 2026`

### Fontes oficiais

- [BullMQ docs](https://docs.bullmq.io/)
- [BullMQ GitHub](https://github.com/taskforcesh/bullmq)

## Temporal

<<<<<<< HEAD
> [!danger]
> Decisao: `Descartar neste MVP`
=======

Decisao: `Descartar neste MVP`
>>>>>>> origin/main

### Onde ajudaria

- orquestracao duravel
- retries automaticos
- workflows longos
- recuperacao apos falhas

### Por que parece atraente

Temporal resolve muito bem fluxo assincrono e duravel. Para faturamento, isso e tecnicamente excelente.

### Por que nao entra agora

Temporal traz outra classe de infraestrutura:
- servidor proprio
- workers proprios
- runtime Node/TS de execucao

Isso foge do desenho `Cloudflare Worker` simples que o MVP esta perseguindo.

### Qual BG ajudaria se o recorte mudasse

- `BG-06`
- `BG-07`
- `BG-08`
- `BG-09`

### Tamanho e maturidade

- Licenca: `MIT`
- Stars: `19.6k`
- Forks: `1.5k`
- Commits: `8,830`
- Coleta: `13 de abril de 2026`

### Fontes oficiais

- [Temporal docs](https://docs.temporal.io/)
- [Temporal server GitHub](https://github.com/temporalio/temporal)
- [Temporal TypeScript SDK](https://github.com/temporalio/sdk-typescript)

## PocketBase

<<<<<<< HEAD
> [!danger]
> Decisao: `Descartar neste MVP`
=======

Decisao: `Descartar neste MVP`
>>>>>>> origin/main

### Onde ajudaria

- persistencia
- auth
- admin UI
- API pronta

### Por que parece atraente

Ele entrega muito em um unico binario: banco embarcado, dashboard admin e API.

### Por que nao entra agora

- puxa o sistema para um backend Go separado
- sai do recorte `Cloudflare-first`
- a propria documentacao avisa que nao recomenda uso em aplicacoes de producao critica antes de `v1.0.0`

### Qual BG ajudaria se o recorte mudasse

- `BG-02`
- `BG-05`
- `BG-10`

### Tamanho e maturidade

- Licenca: `MIT`
- Stars: `57.6k`
- Forks: `3.3k`
- Commits: `2,197`
- Coleta: `13 de abril de 2026`

### Fontes oficiais

- [PocketBase docs](https://pocketbase.io/docs/)
- [PocketBase GitHub](https://github.com/pocketbase/pocketbase)

## Appsmith

<<<<<<< HEAD
> [!danger]
> Decisao: `Descartar neste MVP`
=======

Decisao: `Descartar neste MVP`
>>>>>>> origin/main

### Onde ajudaria

- painel operacional
- listagem de pedidos
- visualizacao de `under_review`
- trilha de auditoria

### Por que parece atraente

E o jeito mais rapido de ganhar backoffice sem construir UI interna do zero.

### Por que nao entra agora

Ele adiciona um produto inteiro fora do Worker. Para este recorte, isso aumenta superficie operacional cedo demais.

### Qual BG ajudaria se o recorte mudasse

- `BG-09`
- `BG-10`

### Tamanho e maturidade

- Licenca: `Apache-2.0`
- Stars: `39.6k`
- Forks: `4.5k`
- Commits: `20,269`
- Coleta: `13 de abril de 2026`

### Fontes oficiais

- [Appsmith site](https://www.appsmith.com/)
- [Appsmith GitHub](https://github.com/appsmithorg/appsmith)

## SigNoz

<<<<<<< HEAD
> [!danger]
> Decisao: `Descartar neste MVP`
=======

Decisao: `Descartar neste MVP`
>>>>>>> origin/main

### Onde ajudaria

- logs centralizados
- traces
- metrics
- dashboards
- alerta

### Por que parece atraente

Ele junta logs, traces e metrics em uma plataforma so e fala muito bem com OpenTelemetry.

### Por que nao entra agora

- adiciona uma plataforma operacional separada
- foge do recorte `Cloudflare-first`
- o repositorio tem licenciamento misto: fora de `ee/` e `cmd/enterprise/` o texto da licenca aponta `MIT Expat`, mas ha partes sob licenca propria de `ee`

### Qual BG ajudaria se o recorte mudasse

- `BG-10`
- `BG-11`
- `BG-12`

### Tamanho e maturidade

- Licenciamento observado no repo: `MIT Expat` fora de `ee/` e `cmd/enterprise/`, com diretorios enterprise sob licenca separada
- Stars: `26.5k`
- Forks: `2.1k`
- Commits: `5,935`
- Coleta: `13 de abril de 2026`

### Fontes oficiais

- [SigNoz site](https://signoz.io/)
- [SigNoz GitHub](https://github.com/SigNoz/signoz)
- [SigNoz LICENSE](https://raw.githubusercontent.com/SigNoz/signoz/main/LICENSE)

## Conclusao operacional

<<<<<<< HEAD
> [!success]
> Adotar agora:
> - `Hono`
> - `grammY`
> - `XState`
> - `Drizzle ORM`
> - `Vitest` + `Cloudflare Workers` + `MSW`

> [!danger]
> Nao adotar neste MVP:
> - `BullMQ`
> - `Temporal`
> - `PocketBase`
> - `Appsmith`
> - `SigNoz`
=======

Adotar agora:
- `Hono`
- `grammY`
- `XState`
- `Cloudflare D1` + `SQL cru`
- `Vitest` + `Cloudflare Workers` + `MSW`


Nao adotar neste MVP:
- `BullMQ`
- `Temporal`
- `PocketBase`
- `Appsmith`
- `SigNoz`
>>>>>>> origin/main

## Leitura final

Se o objetivo for reduzir o maximo de trabalho sem abandonar o desenho atual, a melhor jogada nao e trocar de arquitetura. A melhor jogada e reduzir o trabalho de borda:

- `Hono` na borda HTTP
- `grammY` no canal Telegram
- `XState` no estado da conversa e do pedido
<<<<<<< HEAD
- `Drizzle ORM` na persistencia
- `Vitest` + `Cloudflare Workers` + `MSW` nos testes

Isso reduz trabalho em `fundacao`, `canal`, `persistencia`, `webhook`, `logs` e principalmente `testes`, sem introduzir um segundo sistema principal fora do runtime atual.
=======
- `Cloudflare D1` + `SQL cru` na persistencia
- `Vitest` + `Cloudflare Workers` + `MSW` nos testes

Isso reduz trabalho em `fundacao`, `canal`, `persistencia`, `webhook`, `logs` e principalmente `testes`, sem introduzir um segundo sistema principal fora do runtime atual.

>>>>>>> origin/main
