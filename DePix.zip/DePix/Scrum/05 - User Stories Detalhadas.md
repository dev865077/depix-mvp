# User Stories Detalhadas

Voltar para [[Misc/DePix/Scrum/00 - Indice e Visao Consolidada do MVP|Indice e Visao Consolidada do MVP]]

Base de backlog: [[Misc/DePix/Scrum/04 - Backlog Mestre Priorizado|Backlog Mestre Priorizado]]

## US-01 - Fechar escopo comercial do MVP como DePix-first

Como responsavel pelo produto, quero fixar o MVP como `DePix-first`, para que o time implemente um fluxo completo sem depender de entrega externa ainda nao resolvida.

- Epic: `EP-01`
- Trigger: abertura do planejamento de execucao
- Resultado esperado: backlog obrigatorio sem buraco entre faturamento e conclusao
- Tarefas ligadas: `INF-01`
- Criterios chave: o backlog obrigatorio do MVP cobre apenas `DePix`

## US-02 - Abrir jornada guiada no bot do parceiro

Como usuario, quero iniciar a compra no bot do parceiro, para conseguir entrar no fluxo transacional sem atendimento manual.

- Epic: `EP-01`
- Trigger: usuario chama o bot do parceiro
- Fluxo principal:
  1. o bot recebe a mensagem inicial
  2. resolve o `tenantId`
  3. carrega o catalogo do parceiro
  4. conduz o usuario para escolha do produto
- Fluxos alternativos:
  1. mensagem fora de contexto recebe orientacao de retomada
  2. entrada invalida nao derruba o fluxo
- Tarefas ligadas: `TK-01`

## US-03 - Capturar valor e carteira com validacao

Como usuario, quero informar valor e carteira de forma guiada, para que o sistema gere uma cobranca correta e conclua o pedido certo.

- Epic: `EP-01`
- Trigger: o usuario decidiu comprar `DePix` no catalogo do parceiro
- Fluxo principal:
  1. o bot pede o valor
  2. valida minimo e formato
  3. pede a carteira
  4. valida se ha os dados minimos
  5. cria a intencao de compra
- Dados tocados: `tenantId`, `orderId`, `amountInCents`, `walletAddress`
- Tarefas ligadas: `TK-01`, `TK-02`

## US-04 - Persistir pedido, cobranca e eventos em D1

Como sistema, quero persistir o estado do negocio em `D1`, para que o runtime stateless nao perca continuidade nem auditabilidade.

- Epic: `EP-02`
- Trigger: criacao de pedido, cobranca ou recebimento de evento
- Dados tocados:
  - tenant
  - pedido
  - cobranca
  - evento externo
- Tarefas ligadas: `TK-02`
- Validacoes chave:
  - relacao entre `tenantId`, `orderId`, `depositEntryId` e `nonce`
  - timestamps de criacao e atualizacao

## US-05 - Implementar maquina de estados e idempotencia

Como sistema, quero aplicar uma maquina de estados explicita e regras de idempotencia, para evitar duplicidade de cobranca, regressao de estado e conclusao dupla.

- Epic: `EP-02`
- Trigger: retry, webhook, reconciliacao ou mudanca de status
- Fluxo principal:
  1. estado atual e recuperado
  2. evento externo e classificado
  3. regra de transicao e aplicada
  4. mudanca invalida e rejeitada ou ignorada
- Tarefas ligadas: `TK-03`
- Casos obrigatorios:
  - webhook repetido
  - retry com mesmo `nonce`
  - estado final nao pode regredir sem regra explicita

## US-06 - Carregar segredos e readiness basico

Como operacao, quero que os segredos e bindings sejam carregados de forma segura no Worker, para que a aplicacao suba com baixo risco operacional.

- Epic: `EP-03`, `EP-05`
- Trigger: bootstrap do ambiente
- Segredos minimos:
  - credencial Eulen por tenant quando aplicavel
  - segredo do webhook Eulen por tenant quando aplicavel
  - token do bot Telegram do parceiro
- Tarefas ligadas: `INF-01`

## US-07 - Validar ambiente Eulen com ping

Como time, queremos validar a integracao com `ping`, para saber se token e conectividade estao saudaveis antes de depender do fluxo de venda.

- Epic: `EP-03`
- Trigger: readiness, teste de integracao ou go-live
- Fluxo principal:
  1. resolver tenant
  2. carregar token correto
  3. chamar `ping`
  4. classificar resultado
  5. registrar readiness
- Tarefas ligadas: `TK-04`

## US-08 - Criar cobranca Pix com deposit

Como usuario, quero receber uma cobranca Pix valida, para poder pagar e seguir com a compra.

- Epic: `EP-03`
- Trigger: pedido completo e valido
- Fluxo principal:
  1. resolver `tenantId`
  2. gerar `nonce`
  3. montar payload
  4. resolver a conta Eulen correta
  5. chamar `deposit`
  6. persistir resposta
  7. exibir `qrCopyPaste` e `qrImageUrl`
- Tarefas ligadas: `TK-04`
- Dados tocados:
  - `tenantId`
  - `nonce`
  - `depositEntryId`
  - QR
  - expiracao

## US-09 - Tratar async com o mesmo nonce

Como sistema, quero repetir chamadas assincronas usando o mesmo `nonce`, para evitar duplicidade de cobranca e preservar a identidade da intencao.

- Epic: `EP-03`
- Trigger: resposta com `async: true`
- Fluxo principal:
  1. guardar expiracao
  2. repetir chamada mantendo `nonce`
  3. encerrar com sucesso ou expirar
- Tarefas ligadas: `TK-04`, `TK-03`
- Casos obrigatorios:
  - expiracao atingida
  - sucesso apos retry
  - erro temporario de rede

## US-10 - Confirmar pagamento por webhook

Como sistema, quero receber e autenticar o webhook de deposito, para atualizar o pedido de forma primaria e rapida.

- Epic: `EP-04`
- Trigger: webhook `deposit`
- Fluxo principal:
  1. resolver `tenantId`
  2. validar `Authorization`
  3. parsear payload
  4. persistir evento
  5. aplicar transicao
  6. responder `200 OK`
- Tarefas ligadas: `TK-05`, `TK-03`
- Casos obrigatorios:
  - webhook repetido
  - payload incompleto
  - status operacional

## US-11 - Concluir pedido DePix quando confirmado

Como usuario, quero que meu pedido de `DePix` seja concluido quando o pagamento for confirmado, para receber o resultado esperado do fluxo.

- Epic: `EP-04`
- Trigger: confirmacao valida no estado relevante
- Fluxo principal:
  1. identificar pedido
  2. validar estado
  3. concluir o pedido
  4. registrar trilha final
  5. responder ao usuario
- Tarefas ligadas: `TK-03`
- Observacao: esta e a conclusao obrigatoria do MVP; outros ativos nao entram no fluxo automatico

## US-12 - Reconciliar e tratar estados operacionais

Como operacao, quero recuperar pedidos sem webhook e tratar estados problematicos, para evitar perda de receita e cegueira operacional.

- Epic: `EP-04`
- Trigger:
  - pedido pendente tempo demais
  - divergencia de estado
  - reprocessamento manual
- Fluxo principal:
  1. cron encontra pedido elegivel no tenant correto
  2. consulta `deposit-status`
  3. usa `deposits` se necessario
  4. atualiza ou sinaliza o caso
- Tarefas ligadas: `TK-06`
- Casos obrigatorios:
  - `expired`
  - `under_review`
  - `error`
  - `refunded`

## US-13 - Emitir logs estruturados e trilha operacional

Como operacao, quero buscar um pedido ponta a ponta por identificadores consistentes, para investigar falhas sem depender de memoria humana.

- Epic: `EP-05`
- Trigger: qualquer evento relevante do fluxo
- Campos minimos:
  - `tenantId`
  - `orderId`
  - `nonce`
  - `depositEntryId`
  - `qrId`
  - status interno e externo
- Tarefas ligadas: `TK-07`

## US-14 - Garantir QA, runbook e go-live controlado

Como time, queremos validar o fluxo com testes e runbook, para entrar em operacao controlada sem improvisar incidentes.

- Epic: `EP-06`
- Trigger: fechamento do backlog funcional
- Entregas obrigatorias:
  - testes
  - checklist
  - runbook
  - criterio de pronto para operar
- Tarefas ligadas: `TK-08`, `TK-09`

## Cobertura dos fluxos pelos stories

| Fluxo | Stories |
|---|---|
| Entrada no bot | `US-02` |
| Captura de dados | `US-03` |
| Persistencia central | `US-04` |
| Idempotencia | `US-05`, `US-09`, `US-10` |
| Integracao Eulen | `US-06`, `US-07`, `US-08` |
| Confirmacao | `US-10` |
| Entrega DePix | `US-11` |
| Reconciliacao e operacao | `US-12` |
| Logs | `US-13` |
| Go-live | `US-14` |
