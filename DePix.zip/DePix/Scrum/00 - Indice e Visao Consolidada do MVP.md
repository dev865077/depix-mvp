﻿# Indice e Visao Consolidada do MVP

Este pacote assume um MVP `DePix-first`.

Isso significa:

- o produto inicial automatizado e a venda de `DePix`
- o canal inicial e `Telegram`
- o runtime inicial e `Cloudflare Workers`
- a persistencia principal e `D1`
- os segredos operacionais ficam em `Cloudflare Secrets`
- o webhook da Eulen e a fonte primaria de confirmacao
- `deposit-status` e `deposits` entram como fallback e reconciliacao

Essa decisao fecha o escopo em um MVP realmente completo e operavel: a jornada obrigatoria termina em `DePix`, sem depender de fluxos externos adicionais.

## Resultado esperado do MVP

Ao final deste backlog, o sistema deve conseguir:

- receber a jornada inicial do usuario no Telegram
- capturar ativo, valor e carteira
- criar a intencao de compra e persisti-la
- gerar cobranca Pix via Eulen/DePix
- exibir QR image e copia e cola ao usuario
- receber confirmacao via webhook
- atualizar estado interno do pedido com idempotencia
- concluir entrega para `DePix`
- reconciliar pedidos com fallback via `deposit-status` e `deposits`
- tratar `expired`, `under_review`, `error` e `refunded`
- operar com logs, segredos, cron de reconciliacao, testes minimos e runbook

## Artefatos deste pacote

- [[Misc/DePix/Scrum/01 - Escopo e Fronteiras do MVP|01 - Escopo e Fronteiras do MVP]]
- [[Misc/DePix/Scrum/02 - Fluxos de Usuario e Fluxos Tecnicos|02 - Fluxos de Usuario e Fluxos Tecnicos]]
- [[Misc/DePix/Scrum/03 - Epicos e Capacidades|03 - Epicos e Capacidades]]
- [[Misc/DePix/Scrum/04 - Backlog Mestre Priorizado|04 - Backlog Mestre Priorizado]]
- [[Misc/DePix/Scrum/05 - User Stories Detalhadas|05 - User Stories Detalhadas]]
- [[Misc/DePix/Scrum/06 - Plano de Sprints|06 - Plano de Sprints]]
- [[Misc/DePix/Scrum/07 - Definition of Done, QA e Pronto para Operar|07 - Definition of Done, QA e Pronto para Operar]]
- [[Misc/DePix/Scrum/08 - Riscos, Dependencias, Assumptions e Decisoes Abertas|08 - Riscos, Dependencias, Assumptions e Decisoes Abertas]]

## Fontes de origem

- [[Misc/DePix/Faturamento Automações|Faturamento Automações]]
- [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]
- [[Misc/DePix/Docs/Cloudflare para o MVP - Free Tier e Arquitetura Simples|Cloudflare para o MVP - Free Tier e Arquitetura Simples]]
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|Pix2DePix API - Documentacao Completa]]
- [[Misc/DePix/Contexto|Contexto]]
- [[Misc/DePix/KANBAN|KANBAN]]

## Resumo executivo

### Produto

- venda automatizada e monetizacao por meio de bot transacional
- foco inicial em `DePix`
- operacao enxuta, sem plataforma pesada e sem painel avancado

### Arquitetura

- `Telegram` como canal inicial
- `Cloudflare Workers` como runtime principal
- `D1` como fonte principal de verdade
- `Cloudflare Secrets` para segredos
- `Cron Triggers` para reconciliacao
- `Workers Logs` para observabilidade minima

### Integracao financeira

- `ping` para validacao de ambiente
- `deposit` para criacao de cobranca
- webhook `deposit` como confirmacao primaria
- `deposit-status` e `deposits` como fallback
- `nonce` como mecanismo obrigatorio de idempotencia

### Fronteira do MVP

Dentro:

- jornada Telegram
- criacao e persistencia de pedido
- cobranca Pix
- confirmacao do pagamento
- entrega de `DePix`
- reconciliacao
- operacao minima

Fora:

- Instagram
- WhatsApp
- curso
- IA de suporte
- painel operacional avancado
- expansao para outros ativos

## Cadencia recomendada

Este pacote assume `5 sprints de 1 semana`, com foco em reduzir risco financeiro cedo e deixar o fluxo principal pronto antes de investir em refinamentos.

## Estado final esperado

Se os itens `P0` e `P1` forem entregues e passarem nos criterios de aceite definidos neste pacote, o MVP estara pronto para uma primeira operacao controlada.

## Autoauditoria final do pacote

| Item | Status | Observacao |
|---|---|---|
| Escopo fiel aos docs | OK | Pacote ancorado em Faturamento, Arquitetura, Cloudflare e API |
| Sem features inventadas | OK | Expansoes ficaram fora do escopo obrigatorio |
| Backlog completo | OK | Cobre produto, integracao, persistencia, operacao, QA e go-live |
| Dependencias mapeadas | OK | Dependencias tecnicas e operacionais foram listadas |
| Historias implementaveis | OK | Todas possuem fluxo, dono sugerido e aceite |
| Sprints coerentes | OK | Ordem segue dependencias e risco |
| DoD suficiente | OK | Existe DoD geral, por item e por integracao financeira |
| Cobertura tecnica do MVP | OK | Runtime, D1, webhook, cron, logs, segredos e testes cobertos |
| Cobertura operacional do MVP | OK | Runbook, reconciliacao e tratamento operacional incluidos |
| Estado final realmente entrega o MVP | OK | MVP DePix-first fica operacional ao concluir backlog |

