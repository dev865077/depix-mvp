﻿# Backlog Mestre Priorizado

Voltar para [[Misc/DePix/Scrum/00 - Indice e Visao Consolidada do MVP|Indice e Visao Consolidada do MVP]]

## Ordem mestre de execucao

| Ordem | ID | Tipo | Titulo | Prioridade | Sprint |
|---|---|---|---|---|---|
| 1 | US-01 | Story | Fechar escopo comercial do MVP como DePix-first | P0 | S1 |
| 2 | INF-01 | Infra | Provisionar stack base na Cloudflare | P0 | S1 |
| 3 | US-02 | Story | Abrir jornada guiada no bot do parceiro | P0 | S1 |
| 4 | US-03 | Story | Capturar valor e carteira com validacao | P0 | S1 |
| 5 | US-04 | Story | Persistir pedido, cobranca e eventos em D1 | P0 | S1 |
| 6 | US-06 | Story | Carregar segredos e readiness basico | P0 | S2 |
| 7 | US-07 | Story | Validar ambiente Eulen com ping | P0 | S2 |
| 8 | US-08 | Story | Criar cobranca Pix com deposit | P0 | S2 |
| 9 | US-05 | Story | Implementar maquina de estados e idempotencia | P0 | S3 |
| 10 | US-09 | Story | Tratar async com o mesmo nonce | P1 | S3 |
| 11 | US-10 | Story | Confirmar pagamento por webhook | P0 | S3 |
| 12 | US-11 | Story | Concluir pedido DePix quando confirmado | P1 | S4 |
| 13 | US-12 | Story | Reconciliar e tratar estados operacionais | P1 | S4 |
| 14 | US-13 | Story | Emitir logs estruturados e trilha operacional | P1 | S4 |
| 15 | US-14 | Story | Garantir QA, runbook e go-live controlado | P1 | S5 |
| 16 | TK-01 | Task | Modelar estados da conversa no Telegram | P0 | S1 |
| 17 | TK-02 | Task | Implementar schema D1 multi-tenant, migrations SQL e repositorios | P0 | S1 |
| 18 | TK-03 | Task | Implementar mapeamento de estados e idempotencia | P0 | S3 |
| 19 | TK-04 | Task | Implementar client Eulen e adaptador deposit | P0 | S2 |
| 20 | TK-05 | Task | Implementar webhook e validacao de Authorization | P0 | S3 |
| 21 | TK-06 | Task | Implementar cron de reconciliacao | P1 | S4 |
| 22 | TK-07 | Task | Padronizar contrato de logs e correlation ids | P1 | S4 |
| 23 | TK-08 | Task | Montar suites automatizadas e fixtures | P1 | S5 |
| 24 | TK-09 | Task | Escrever runbook e checklist de release | P1 | S5 |
| 25 | SPK-01 | Spike | Avaliar Durable Objects se aparecer corrida real | P3 | Backlog futuro |

## Epicos

### EP-01 - Jornada Telegram e escopo comercial

- Tipo: Epic
- Objetivo: transformar o escopo do MVP em um fluxo comercial simples e executavel
- Descricao: define o produto inicial como `DePix-first` e implementa a jornada minima do usuario no bot Telegram do parceiro
- Justificativa de negocio: sem uma fronteira comercial clara, o backlog vira alvo movel e o time entrega lacunas
- Necessidade: 5/5
- Valor de negocio: 5/5
- Retorno esperado: 5/5
- Risco: 4/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 13
- Dependencias: nenhuma
- Criterios de aceite:
  1. o escopo do MVP esta fechado como `DePix-first`
  2. o usuario consegue entrar no bot do parceiro e iniciar a compra
  3. valor e carteira sao coletados com validacao basica
- Definition of Done aplicavel: DoD de Epic e Story em [[Misc/DePix/Scrum/07 - Definition of Done, QA e Pronto para Operar|Definition of Done, QA e Pronto para Operar]]
- Owner sugerido: PM + Backend
- Sprint sugerida: S1
- Observacoes tecnicas: evitar abrir backlog obrigatorio para outros ativos
- Referencia aos docs de origem: [[Misc/DePix/Contexto|Contexto]], [[Misc/DePix/Faturamento Automações|Faturamento Automações]], [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

### EP-02 - Core de pedido e persistencia

- Tipo: Epic
- Objetivo: criar a fonte principal de verdade do fluxo
- Descricao: cobre tenant, catalogo, modelo de pedido, cobranca, evento externo, estado interno e persistencia em `D1` com `SQL cru`
- Justificativa de negocio: sem persistencia confiavel o runtime stateless perde rastreabilidade e consistencia
- Necessidade: 5/5
- Valor de negocio: 5/5
- Retorno esperado: 5/5
- Risco: 5/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 13
- Dependencias: `EP-01`
- Criterios de aceite:
  1. tenant, pedido, cobranca e evento externo possuem schema persistido com migrations SQL versionadas
  2. estado interno e externo ficam relacionaveis por identificadores consistentes no escopo do `tenantId`
  3. o sistema nao depende de memoria local para seguir o fluxo
- Definition of Done aplicavel: DoD de Epic e Story
- Owner sugerido: Backend
- Sprint sugerida: S1-S3
- Observacoes tecnicas: `D1` e a base principal; `Durable Objects` ficam fora do nucleo inicial
- Referencia aos docs de origem: [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]], [[Misc/DePix/Docs/Cloudflare para o MVP - Free Tier e Arquitetura Simples|Cloudflare para o MVP - Free Tier e Arquitetura Simples]]

### EP-03 - Integracao Eulen e cobranca Pix

- Tipo: Epic
- Objetivo: validar ambiente e gerar cobranca Pix com consistencia
- Descricao: cobre segredos, `ping`, `deposit`, QR, tratamento de `async` e resolucao da conta Eulen correta por tenant
- Justificativa de negocio: sem cobranca confiavel nao existe faturamento
- Necessidade: 5/5
- Valor de negocio: 5/5
- Retorno esperado: 5/5
- Risco: 5/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 13
- Dependencias: `EP-01`, `EP-02`
- Criterios de aceite:
  1. o ambiente consegue autenticar com a Eulen na conta correta do tenant
  2. o sistema cria cobranca valida com `deposit`
  3. o usuario recebe QR e copia e cola
- Definition of Done aplicavel: DoD de Epic e Story
- Owner sugerido: Backend + Infra
- Sprint sugerida: S2-S3
- Observacoes tecnicas: o mesmo `nonce` deve sobreviver a retries da mesma intencao
- Referencia aos docs de origem: [[Misc/DePix/Faturamento Automações|Faturamento Automações]], [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|Pix2DePix API - Documentacao Completa]]

### EP-04 - Confirmacao, entrega e reconciliacao

- Tipo: Epic
- Objetivo: fechar o ciclo do pedido ate conclusao ou tratamento operacional
- Descricao: cobre webhook, mudanca de estado, entrega `DePix`, reconciliacao e operacao minima
- Justificativa de negocio: faturar sem concluir ou sem reconciliar gera risco financeiro e reputacional
- Necessidade: 5/5
- Valor de negocio: 5/5
- Retorno esperado: 5/5
- Risco: 5/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 13
- Dependencias: `EP-02`, `EP-03`
- Criterios de aceite:
  1. webhook altera o estado interno com seguranca
  2. pedidos sem webhook podem ser reconciliados
  3. `DePix` pode ser concluido no fluxo adotado
- Definition of Done aplicavel: DoD de Epic e Story
- Owner sugerido: Backend
- Sprint sugerida: S3-S4
- Observacoes tecnicas: `deposit-status` e `deposits` continuam secundarios
- Referencia aos docs de origem: [[Misc/DePix/Faturamento Automações|Faturamento Automações]], [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

### EP-05 - Plataforma, seguranca e observabilidade

- Tipo: Epic
- Objetivo: sustentar a operacao minima na Cloudflare com rastreabilidade
- Descricao: cobre `Workers`, `D1`, `Secrets`, cron, logs e protecoes basicas em um desenho multi-tenant
- Justificativa de negocio: sem base operacional minima, cada incidente vira investigacao manual cega
- Necessidade: 4/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 4/5
- Urgencia: 4/5
- Prioridade: P1
- Story Points: 8
- Dependencias: `EP-02`, `EP-03`
- Criterios de aceite:
  1. segredos nao aparecem em codigo ou logs
  2. logs permitem buscar um pedido ponta a ponta por `tenantId`
  3. cron de reconciliacao esta definido e agendado
- Definition of Done aplicavel: DoD de Epic e Story
- Owner sugerido: Infra + Backend
- Sprint sugerida: S2-S4
- Observacoes tecnicas: nao adicionar servicos Cloudflare opcionais sem justificativa
- Referencia aos docs de origem: [[Misc/DePix/Docs/Cloudflare para o MVP - Free Tier e Arquitetura Simples|Cloudflare para o MVP - Free Tier e Arquitetura Simples]], [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

### EP-06 - QA, release e pronto para operar

- Tipo: Epic
- Objetivo: garantir que o MVP entre no ar com criterio
- Descricao: cobre testes minimos, runbook, checklist e criterio de entrada em producao
- Justificativa de negocio: integracao financeira sem readiness gera perda de dinheiro e confianca
- Necessidade: 4/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 5/5
- Urgencia: 4/5
- Prioridade: P1
- Story Points: 8
- Dependencias: todos os epics anteriores
- Criterios de aceite:
  1. existe matriz de testes minima aprovada
  2. existe runbook operacional para falhas principais
  3. existe checklist objetivo de entrada em operacao controlada
- Definition of Done aplicavel: DoD de Epic e Story
- Owner sugerido: QA + Backend + PM
- Sprint sugerida: S5
- Observacoes tecnicas: priorizar testes em pontos com risco financeiro
- Referencia aos docs de origem: [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]], [[Misc/DePix/Faturamento Automações|Faturamento Automações]]

## User stories

### US-01 - Fechar escopo comercial do MVP como DePix-first

- Tipo: Story
- Objetivo: remover ambiguidade de produto antes da implementacao
- Descricao: formalizar que o MVP obrigatorio entrega venda automatizada de `DePix` e nao abre escopo para outros ativos
- Justificativa de negocio: backlog completo depende de uma fronteira comercial sem buracos
- Necessidade: 5/5
- Valor de negocio: 5/5
- Retorno esperado: 5/5
- Risco: 4/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 3
- Dependencias: `EP-01`
- Criterios de aceite:
  1. os artefatos do projeto descrevem o MVP como `DePix-first`
  2. backlog obrigatorio nao assume expansao para outros ativos
  3. itens futuros ficam claramente marcados como fora do escopo
- Definition of Done aplicavel: DoD de Story
- Owner sugerido: PM
- Sprint sugerida: S1
- Observacoes tecnicas: usar `Contexto` como reforco da decisao
- Referencia aos docs de origem: [[Misc/DePix/Contexto|Contexto]], [[Misc/DePix/Faturamento Automações|Faturamento Automações]]

### US-02 - Abrir jornada guiada no bot do parceiro

- Tipo: Story
- Objetivo: permitir que o usuario entre no fluxo transacional
- Descricao: implementar entrada, mensagens iniciais e sequencia minima da conversa, carregando o catalogo do parceiro e a captura do produto escolhido
- Justificativa de negocio: sem canal funcional nao existe captura de demanda
- Necessidade: 5/5
- Valor de negocio: 5/5
- Retorno esperado: 4/5
- Risco: 3/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 5
- Dependencias: `US-01`, `INF-01`
- Criterios de aceite:
  1. o usuario consegue iniciar a conversa no bot do parceiro
  2. o bot apresenta o catalogo do parceiro e o fluxo minimo de compra
  3. a conversa segue um estado previsivel
- Definition of Done aplicavel: DoD de Story
- Owner sugerido: Backend
- Sprint sugerida: S1
- Observacoes tecnicas: evitar logica de negocio acoplada ao handler do canal
- Referencia aos docs de origem: [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

### US-03 - Capturar valor e carteira com validacao

- Tipo: Story
- Objetivo: coletar os dados minimos para abrir um pedido valido
- Descricao: capturar `amountInCents` e `depixAddress`, validando consistencia e completude
- Justificativa de negocio: pedido mal formado gera cobranca errada e retrabalho
- Necessidade: 5/5
- Valor de negocio: 5/5
- Retorno esperado: 4/5
- Risco: 4/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 5
- Dependencias: `US-02`
- Criterios de aceite:
  1. valor minimo e formato sao validados
  2. carteira exigida para `DePix` e validada no nivel disponivel
  3. o pedido nao segue sem dados minimos
- Definition of Done aplicavel: DoD de Story
- Owner sugerido: Backend
- Sprint sugerida: S1
- Observacoes tecnicas: guardar entrada ja normalizada para persistencia
- Referencia aos docs de origem: [[Misc/DePix/Faturamento Automações|Faturamento Automações]], [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

### US-04 - Persistir pedido, cobranca e eventos em D1

- Tipo: Story
- Objetivo: dar ao fluxo uma base persistente confiavel
- Descricao: criar schemas, acessos e relacionamento entre tenant, catalogo, pedido, cobranca e eventos externos
- Justificativa de negocio: pedido financeiro nao pode depender de memoria do runtime
- Necessidade: 5/5
- Valor de negocio: 5/5
- Retorno esperado: 5/5
- Risco: 5/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 8
- Dependencias: `INF-01`
- Criterios de aceite:
  1. `tenantId`, `orderId`, `depositEntryId`, `nonce` e timestamps ficam persistidos
  2. historico de eventos externos pode ser consultado
  3. o sistema consegue reconstituir o estado de um pedido apos reinicio no escopo do tenant
- Definition of Done aplicavel: DoD de Story
- Owner sugerido: Backend
- Sprint sugerida: S1
- Observacoes tecnicas: `D1` e a fonte principal de verdade
- Referencia aos docs de origem: [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]], [[Misc/DePix/Docs/Cloudflare para o MVP - Free Tier e Arquitetura Simples|Cloudflare para o MVP - Free Tier e Arquitetura Simples]]

### US-05 - Implementar maquina de estados e idempotencia

- Tipo: Story
- Objetivo: impedir duplicidade e regressao de estado
- Descricao: mapear estados externos para estados internos e aplicar regras de idempotencia em retry e webhook
- Justificativa de negocio: duplicidade e mudanca incorreta de estado sao riscos centrais do fluxo financeiro
- Necessidade: 5/5
- Valor de negocio: 5/5
- Retorno esperado: 5/5
- Risco: 5/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 8
- Dependencias: `US-04`
- Criterios de aceite:
  1. existe mapa explicito entre status externo e interno
  2. webhook duplicado nao gera conclusao duplicada
  3. retry da mesma intencao nao gera nova cobranca por erro de `nonce`
- Definition of Done aplicavel: DoD de Story
- Owner sugerido: Backend
- Sprint sugerida: S3
- Observacoes tecnicas: cobrir `pending`, `depix_sent`, `under_review`, `expired`, `error`, `refunded`, `canceled`
- Referencia aos docs de origem: [[Misc/DePix/Faturamento Automações|Faturamento Automações]], [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

### US-06 - Carregar segredos e readiness basico

- Tipo: Story
- Objetivo: preparar o runtime de forma segura
- Descricao: configurar `Cloudflare Secrets`, bindings de `D1` e readiness minimo do Worker compartilhado
- Justificativa de negocio: sem segredos e ambiente corretos o fluxo nao sobe de forma confiavel
- Necessidade: 5/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 5/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 3
- Dependencias: `INF-01`
- Criterios de aceite:
  1. tokens e segredos obrigatorios por tenant ficam previstos em `Secrets` ou referencias equivalentes
  2. `D1` esta conectado ao Worker
  3. existe verificacao basica de readiness
- Definition of Done aplicavel: DoD de Story
- Owner sugerido: Infra
- Sprint sugerida: S2
- Observacoes tecnicas: nunca expor segredo em log ou codigo
- Referencia aos docs de origem: [[Misc/DePix/Docs/Cloudflare para o MVP - Free Tier e Arquitetura Simples|Cloudflare para o MVP - Free Tier e Arquitetura Simples]]

### US-07 - Validar ambiente Eulen com ping

- Tipo: Story
- Objetivo: provar que token e conectividade estao saudaveis antes do uso principal
- Descricao: implementar chamada de `ping` e criterio de saude da integracao
- Justificativa de negocio: evita descobrir falha de autenticacao apenas no momento da venda
- Necessidade: 4/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 4/5
- Urgencia: 4/5
- Prioridade: P0
- Story Points: 3
- Dependencias: `US-06`
- Criterios de aceite:
  1. `ping` pode ser executado com segredo valido
  2. falha de autenticacao e distinguivel de falha temporaria
  3. readiness da integracao fica observavel
- Definition of Done aplicavel: DoD de Story
- Owner sugerido: Backend
- Sprint sugerida: S2
- Observacoes tecnicas: usar isso tambem como parte do go-live
- Referencia aos docs de origem: [[Misc/DePix/Faturamento Automações|Faturamento Automações]], [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|Pix2DePix API - Documentacao Completa]]

### US-08 - Criar cobranca Pix com deposit

- Tipo: Story
- Objetivo: gerar cobranca vinculada ao pedido
- Descricao: chamar `deposit`, persistir `depositEntryId`, QR e expiracao, e responder ao usuario no bot do parceiro
- Justificativa de negocio: essa e a entrada de faturamento real do MVP
- Necessidade: 5/5
- Valor de negocio: 5/5
- Retorno esperado: 5/5
- Risco: 5/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 8
- Dependencias: `US-03`, `US-04`, `US-07`
- Criterios de aceite:
  1. `deposit` e chamado com payload valido
  2. `depositEntryId`, `qrCopyPaste`, `qrImageUrl` e expiracao ficam persistidos
  3. o bot do parceiro devolve cobranca ao usuario
- Definition of Done aplicavel: DoD de Story
- Owner sugerido: Backend
- Sprint sugerida: S2
- Observacoes tecnicas: usar `depixAddress` quando o fluxo exigir entrega direta de `DePix`
- Referencia aos docs de origem: [[Misc/DePix/Faturamento Automações|Faturamento Automações]], [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|Pix2DePix API - Documentacao Completa]]

### US-09 - Tratar async com o mesmo nonce

- Tipo: Story
- Objetivo: manter consistencia em resposta assincrona
- Descricao: implementar repeticao segura da mesma chamada com o mesmo `nonce` ate sincronizar ou expirar
- Justificativa de negocio: `async` sem controle pode duplicar cobranca ou quebrar o pedido
- Necessidade: 4/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 5/5
- Urgencia: 4/5
- Prioridade: P1
- Story Points: 5
- Dependencias: `US-08`, `US-05`
- Criterios de aceite:
  1. retry da mesma intencao sempre reutiliza o mesmo `nonce`
  2. expiracao de janela e tratada sem loop infinito
  3. tentativas e resultado ficam logados
- Definition of Done aplicavel: DoD de Story
- Owner sugerido: Backend
- Sprint sugerida: S3
- Observacoes tecnicas: preferir fluxo automatico e curto
- Referencia aos docs de origem: [[Misc/DePix/Faturamento Automações|Faturamento Automações]], [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|Pix2DePix API - Documentacao Completa]]

### US-10 - Confirmar pagamento por webhook

- Tipo: Story
- Objetivo: transformar o webhook em confirmacao primaria do pagamento
- Descricao: receber, autenticar, resolver tenant, persistir e processar webhook `deposit`
- Justificativa de negocio: sem webhook o fluxo dependeria de polling caro e menos confiavel
- Necessidade: 5/5
- Valor de negocio: 5/5
- Retorno esperado: 5/5
- Risco: 5/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 8
- Dependencias: `US-04`, `US-05`, `US-06`
- Criterios de aceite:
  1. o endpoint resolve o tenant e valida `Authorization`
  2. eventos sao persistidos antes de atualizar estado
  3. a resposta `200 OK` respeita o fluxo esperado
- Definition of Done aplicavel: DoD de Story
- Owner sugerido: Backend
- Sprint sugerida: S3
- Observacoes tecnicas: payload duplicado deve ser idempotente
- Referencia aos docs de origem: [[Misc/DePix/Faturamento Automações|Faturamento Automações]], [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

### US-11 - Concluir pedido DePix quando confirmado

- Tipo: Story
- Objetivo: fechar o caminho automatizado do produto escolhido
- Descricao: concluir o pedido `DePix` quando o estado de confirmacao relevante for atingido
- Justificativa de negocio: faturar sem concluir o ativo quebra a proposta do MVP
- Necessidade: 5/5
- Valor de negocio: 5/5
- Retorno esperado: 5/5
- Risco: 4/5
- Urgencia: 4/5
- Prioridade: P1
- Story Points: 5
- Dependencias: `US-10`
- Criterios de aceite:
  1. o pedido muda para concluido no caminho definido
  2. a mensagem final ao usuario e coerente com a conclusao
  3. a conclusao fica rastreada por pedido
- Definition of Done aplicavel: DoD de Story
- Owner sugerido: Backend
- Sprint sugerida: S4
- Observacoes tecnicas: manter separacao entre confirmacao de pagamento e conclusao do pedido
- Referencia aos docs de origem: [[Misc/DePix/Faturamento Automações|Faturamento Automações]], [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

### US-12 - Reconciliar e tratar estados operacionais

- Tipo: Story
- Objetivo: recuperar pedidos inconsistentes e tratar excecoes
- Descricao: consultar `deposit-status` e `deposits`, mover casos problematicos para tratamento operacional e resolver ausencia de webhook no escopo do tenant
- Justificativa de negocio: sem reconciliacao, o sistema fica cego a falhas de notificacao
- Necessidade: 5/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 5/5
- Urgencia: 4/5
- Prioridade: P1
- Story Points: 8
- Dependencias: `US-10`, `US-05`
- Criterios de aceite:
  1. pedidos pendentes antigos podem ser verificados por cron
  2. `under_review`, `error`, `expired` e `refunded` possuem tratamento minimo
  3. divergencia entre estado interno e externo fica visivel ao operador
- Definition of Done aplicavel: DoD de Story
- Owner sugerido: Backend + Ops
- Sprint sugerida: S4
- Observacoes tecnicas: `deposits` continua fallback, nao caminho principal
- Referencia aos docs de origem: [[Misc/DePix/Faturamento Automações|Faturamento Automações]], [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

### US-13 - Emitir logs estruturados e trilha operacional

- Tipo: Story
- Objetivo: tornar cada pedido investigavel ponta a ponta
- Descricao: padronizar logs, correlation ids e visibilidade operacional
- Justificativa de negocio: integracao financeira sem log forte aumenta o tempo e o custo de incidentes
- Necessidade: 4/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 4/5
- Urgencia: 4/5
- Prioridade: P1
- Story Points: 5
- Dependencias: `US-04`, `US-08`, `US-10`
- Criterios de aceite:
  1. logs carregam `tenantId`, `orderId`, `nonce`, `depositEntryId` e `qrId` quando aplicavel
  2. segredos e dados sensiveis nao aparecem em log
  3. eventos principais do fluxo ficam cobertos
- Definition of Done aplicavel: DoD de Story
- Owner sugerido: Backend
- Sprint sugerida: S4
- Observacoes tecnicas: usar `Workers Logs` como base minima
- Referencia aos docs de origem: [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]], [[Misc/DePix/Docs/Cloudflare para o MVP - Free Tier e Arquitetura Simples|Cloudflare para o MVP - Free Tier e Arquitetura Simples]]

### US-14 - Garantir QA, runbook e go-live controlado

- Tipo: Story
- Objetivo: fechar o MVP com criterio de qualidade e operacao
- Descricao: consolidar testes, checklist de release, readiness e runbook
- Justificativa de negocio: risco financeiro exige prontidao minima antes de producao
- Necessidade: 4/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 5/5
- Urgencia: 4/5
- Prioridade: P1
- Story Points: 8
- Dependencias: `US-08`, `US-10`, `US-12`, `US-13`
- Criterios de aceite:
  1. existe suite minima de testes definida e executavel
  2. existe runbook para falhas principais
  3. existe checklist objetivo de entrada em operacao controlada
- Definition of Done aplicavel: DoD de Story
- Owner sugerido: QA + Backend + PM
- Sprint sugerida: S5
- Observacoes tecnicas: concentrar esforco nos riscos que mexem com dinheiro, duplicidade e perda de evento
- Referencia aos docs de origem: [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]], [[Misc/DePix/Faturamento Automações|Faturamento Automações]]

## Itens tecnicos

### INF-01 - Provisionar stack base na Cloudflare

- Tipo: Infra
- Objetivo: disponibilizar a base minima para desenvolvimento e deploy
- Descricao: criar Worker compartilhado, `D1`, `Secrets`, cron e configuracoes essenciais
- Justificativa de negocio: sem fundacao de plataforma o backlog nao sai do papel
- Necessidade: 5/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 5/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 5
- Dependencias: nenhuma
- Criterios de aceite:
  1. Worker principal existe
  2. banco `D1` e binding estao definidos
  3. secrets e referencias obrigatorias por tenant estao previstos
- Definition of Done aplicavel: DoD de Infra
- Owner sugerido: Infra
- Sprint sugerida: S1
- Observacoes tecnicas: manter apenas recursos Cloudflare necessarios
- Referencia aos docs de origem: [[Misc/DePix/Docs/Cloudflare para o MVP - Free Tier e Arquitetura Simples|Cloudflare para o MVP - Free Tier e Arquitetura Simples]]

### TK-01 - Modelar estados da conversa no bot do parceiro

- Tipo: Task
- Objetivo: organizar a sequencia de interacao do usuario
- Descricao: definir estados, transicoes e validacoes basicas da conversa a partir do catalogo do parceiro
- Justificativa de negocio: evita fluxo inconsistente e mensagens sem contexto
- Necessidade: 4/5
- Valor de negocio: 4/5
- Retorno esperado: 3/5
- Risco: 3/5
- Urgencia: 4/5
- Prioridade: P0
- Story Points: 3
- Dependencias: `US-02`
- Criterios de aceite:
  1. estados da conversa estao enumerados
  2. transicoes invalidas sao bloqueadas
  3. fluxo permite retomar contexto minimo no escopo do tenant
- Definition of Done aplicavel: DoD de Task
- Owner sugerido: Backend
- Sprint sugerida: S1
- Observacoes tecnicas: manter adaptador de canal separado do nucleo
- Referencia aos docs de origem: [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

### TK-02 - Implementar schema D1 multi-tenant, migrations SQL e repositorios

- Tipo: Task
- Objetivo: viabilizar persistencia central
- Descricao: criar schema, migrations SQL e camada de acesso para tenant, catalogo, pedido, cobranca e evento
- Justificativa de negocio: sem repositorio consistente nao existe rastreabilidade
- Necessidade: 5/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 5/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 5
- Dependencias: `INF-01`, `US-04`
- Criterios de aceite:
  1. schema cobre campos minimos documentados, incluindo `tenantId`
  2. migrations SQL estao versionadas
  3. repositorios suportam leitura e escrita basicas
  4. identificadores principais sao indexaveis no escopo do tenant
- Definition of Done aplicavel: DoD de Task
- Owner sugerido: Backend
- Sprint sugerida: S1
- Observacoes tecnicas: priorizar consulta por `tenantId`, `orderId`, `nonce`, `depositEntryId` e `qrId`, sem SQL espalhado em handlers
- Referencia aos docs de origem: [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

### TK-03 - Implementar mapeamento de estados e idempotencia

- Tipo: Task
- Objetivo: codificar regras centrais de consistencia
- Descricao: construir servico de transicao de estado e barreiras contra duplicidade
- Justificativa de negocio: esse ponto protege contra erros financeiros
- Necessidade: 5/5
- Valor de negocio: 5/5
- Retorno esperado: 4/5
- Risco: 5/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 5
- Dependencias: `US-05`, `TK-02`
- Criterios de aceite:
  1. transicoes invalidas sao rejeitadas
  2. webhook repetido nao duplica conclusao
  3. retry da mesma intencao reaproveita contexto
- Definition of Done aplicavel: DoD de Task
- Owner sugerido: Backend
- Sprint sugerida: S3
- Observacoes tecnicas: considerar chave logica por `orderId` e `nonce`
- Referencia aos docs de origem: [[Misc/DePix/Faturamento Automações|Faturamento Automações]], [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

### TK-04 - Implementar client Eulen e adaptador deposit

- Tipo: Task
- Objetivo: encapsular a integracao externa
- Descricao: criar client com auth header, `ping`, `deposit`, parse de resposta, tratamento de erro e resolucao da conta Eulen correta por tenant
- Justificativa de negocio: isolamento da integracao reduz acoplamento e facilita testes
- Necessidade: 5/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 5/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 5
- Dependencias: `US-06`, `US-07`
- Criterios de aceite:
  1. client centraliza headers, parsing e resolucao da conta do tenant
  2. erros HTTP e timeouts sao classificados
  3. `deposit` retorna objeto pronto para persistencia
- Definition of Done aplicavel: DoD de Task
- Owner sugerido: Backend
- Sprint sugerida: S2
- Observacoes tecnicas: manter integracao isolada em um client proprio
- Referencia aos docs de origem: [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]], [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|Pix2DePix API - Documentacao Completa]]

### TK-05 - Implementar webhook e validacao de Authorization

- Tipo: Task
- Objetivo: processar confirmacao primaria com seguranca
- Descricao: criar endpoint, resolver tenant, validar segredo, persistir evento e devolver `200 OK`
- Justificativa de negocio: webhook e o caminho central de confirmacao do pagamento
- Necessidade: 5/5
- Valor de negocio: 5/5
- Retorno esperado: 4/5
- Risco: 5/5
- Urgencia: 5/5
- Prioridade: P0
- Story Points: 5
- Dependencias: `US-10`, `TK-02`
- Criterios de aceite:
  1. requisicoes validas sao aceitas no tenant correto
  2. requisicoes invalidas sao rejeitadas
  3. o evento fica persistido antes da atualizacao de estado
- Definition of Done aplicavel: DoD de Task
- Owner sugerido: Backend
- Sprint sugerida: S3
- Observacoes tecnicas: responder rapido e evitar trabalho pesado inline
- Referencia aos docs de origem: [[Misc/DePix/Faturamento Automações|Faturamento Automações]]

### TK-06 - Implementar cron de reconciliacao

- Tipo: Task
- Objetivo: recuperar consistencia de pedidos sem webhook ou com duvida
- Descricao: criar job para consultar `deposit-status` e `deposits` conforme regra operacional por tenant
- Justificativa de negocio: protege contra perda de evento e atraso de notificacao
- Necessidade: 4/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 5/5
- Urgencia: 4/5
- Prioridade: P1
- Story Points: 5
- Dependencias: `US-12`, `TK-04`
- Criterios de aceite:
  1. o cron encontra pedidos pendentes elegiveis
  2. o fallback atualiza ou sinaliza casos divergentes
  3. limite de uso da API e respeitado
- Definition of Done aplicavel: DoD de Task
- Owner sugerido: Backend
- Sprint sugerida: S4
- Observacoes tecnicas: usar `deposit-status` como primeira opcao para caso individual
- Referencia aos docs de origem: [[Misc/DePix/Faturamento Automações|Faturamento Automações]], [[Misc/DePix/Docs/Cloudflare para o MVP - Free Tier e Arquitetura Simples|Cloudflare para o MVP - Free Tier e Arquitetura Simples]]

### TK-07 - Padronizar contrato de logs e correlation ids

- Tipo: Task
- Objetivo: tornar o sistema auditavel
- Descricao: definir formato de log, campos obrigatorios e pontos de emissao
- Justificativa de negocio: logs bons reduzem tempo de incidente
- Necessidade: 4/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 4/5
- Urgencia: 4/5
- Prioridade: P1
- Story Points: 3
- Dependencias: `US-13`
- Criterios de aceite:
  1. identificadores obrigatorios, incluindo `tenantId`, estao definidos
  2. eventos principais do fluxo geram log
  3. segredos nao sao emitidos
- Definition of Done aplicavel: DoD de Task
- Owner sugerido: Backend
- Sprint sugerida: S4
- Observacoes tecnicas: usar `Workers Logs` como observabilidade minima
- Referencia aos docs de origem: [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

### TK-08 - Montar suites automatizadas e fixtures

- Tipo: Task
- Objetivo: cobrir os pontos de maior risco do MVP
- Descricao: criar testes unitarios, de integracao, webhook e reconciliacao com fixtures minimas
- Justificativa de negocio: reduz risco de erro silencioso em fluxo financeiro
- Necessidade: 4/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 5/5
- Urgencia: 4/5
- Prioridade: P1
- Story Points: 5
- Dependencias: `US-14`
- Criterios de aceite:
  1. cenarios minimos definidos no pacote estao cobertos
  2. testes criticos podem rodar de forma repetivel
  3. falhas apontam o fluxo quebrado com clareza
- Definition of Done aplicavel: DoD de Task
- Owner sugerido: QA + Backend
- Sprint sugerida: S5
- Observacoes tecnicas: priorizar `deposit`, webhook, `nonce` e reconciliacao
- Referencia aos docs de origem: [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

### TK-09 - Escrever runbook e checklist de release

- Tipo: Task
- Objetivo: permitir operacao controlada
- Descricao: documentar verificacoes de ambiente, incidentes principais, reconciliacao manual e entrada em producao
- Justificativa de negocio: incidentes iniciais precisam de resposta simples e previsivel
- Necessidade: 4/5
- Valor de negocio: 4/5
- Retorno esperado: 4/5
- Risco: 4/5
- Urgencia: 4/5
- Prioridade: P1
- Story Points: 3
- Dependencias: `US-14`
- Criterios de aceite:
  1. existe checklist de go-live
  2. existe procedimento para `under_review`, `error` e ausencia de webhook
  3. existe criterio de rollback ou pausa operacional
- Definition of Done aplicavel: DoD de Task
- Owner sugerido: PM + Ops
- Sprint sugerida: S5
- Observacoes tecnicas: o runbook deve partir de identificadores operacionais reais
- Referencia aos docs de origem: [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]], [[Misc/DePix/Faturamento Automações|Faturamento Automações]]

### SPK-01 - Avaliar Durable Objects se aparecer corrida real

- Tipo: Spike
- Objetivo: avaliar reforco de coordenacao por entidade apenas se necessario
- Descricao: estudar `Durable Objects` para serializacao por `orderId` ou `nonce` se houver corrida que `D1` e desenho atual nao resolvam de forma simples
- Justificativa de negocio: evita sofisticacao precoce, mas deixa uma resposta pronta se a concorrencia apertar
- Necessidade: 1/5
- Valor de negocio: 2/5
- Retorno esperado: 2/5
- Risco: 2/5
- Urgencia: 1/5
- Prioridade: P3
- Story Points: 2
- Dependencias: operacao real ou evidencias de corrida
- Criterios de aceite:
  1. existem criterios objetivos para decidir se `DO` entra
  2. o estudo compara custo de complexidade vs ganho real
  3. nenhuma mudanca estrutural entra sem necessidade comprovada
- Definition of Done aplicavel: DoD de Spike
- Owner sugerido: Tech Lead
- Sprint sugerida: Backlog futuro
- Observacoes tecnicas: nao faz parte do MVP obrigatorio
- Referencia aos docs de origem: [[Misc/DePix/Docs/Cloudflare para o MVP - Free Tier e Arquitetura Simples|Cloudflare para o MVP - Free Tier e Arquitetura Simples]]


