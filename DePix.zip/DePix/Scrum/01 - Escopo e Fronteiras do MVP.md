﻿# Escopo e Fronteiras do MVP

Voltar para [[Misc/DePix/Scrum/00 - Indice e Visao Consolidada do MVP|Indice e Visao Consolidada do MVP]]

## Missao do MVP

Entregar um bot transacional capaz de vender `DePix` via `Telegram`, gerar cobranca Pix pela API da Eulen, confirmar pagamento com confiabilidade, concluir o pedido com rastreabilidade e operar com o minimo de friccao na Cloudflare.

## Objetivo de negocio

- validar venda automatizada
- monetizar operacao com baixo custo fixo
- reduzir atrito entre conversa, cobranca e conclusao do pedido
- construir uma base enxuta que possa ser expandida depois

## Escopo dentro do MVP

### Produto

- fluxo guiado no Telegram
- definicao do ativo suportado no MVP como `DePix`
- captura de valor e carteira do usuario
- envio de QR code e copia e cola
- mensagens de status do pedido

### Integracao Eulen/DePix

- carregamento de token
- validacao de ambiente com `ping`
- criacao de cobranca com `deposit`
- tratamento de `sync` e `async`
- uso obrigatorio de `nonce`
- webhook `deposit`
- consulta de `deposit-status`
- consulta de `deposits`

### Core do sistema

- criacao de pedido interno
- persistencia do pedido
- persistencia da cobranca
- persistencia de eventos externos
- mapeamento de status externos para internos
- idempotencia
- entrega automatica de `DePix`

### Plataforma

- `Cloudflare Workers`
- `D1`
- `Cron Triggers`
- `Workers Logs`
- `Cloudflare Secrets`

### Operacao minima

- logs estruturados
- reconciliacao por cron
- tratamento de `expired`
- tratamento de `under_review`
- tratamento de `error`
- tratamento de `refunded`
- runbook minimo
- checklist de go-live

## Fora do escopo do MVP

- Instagram
- WhatsApp
- site completo
- painel operacional avancado
- suporte conversacional com IA
- automacoes de marketing
- venda de curso
- expansao para outros ativos
- Pix2FA como caminho principal
- withdraw
- split de cobranca
- whitelist
- lightning
- QR delay

## Justificativa da fronteira adotada

O material atual permite fechar um MVP consistente se o produto inicial for `DePix-only`. Isso evita buracos de escopo e mantem faturamento, confirmacao e conclusao dentro da mesma jornada.

## Restricoes obrigatorias

- webhook e a fonte primaria de confirmacao
- `deposit-status` e `deposits` entram so como fallback
- estado do negocio precisa ficar fora da memoria do runtime
- `nonce` deve ser reutilizado no retry da mesma intencao
- segredos nao podem ir para codigo, git ou configuracao plaintext
- logs nao podem vazar token ou segredo
- runtime deve continuar simples e stateless

## Dependencias externas

- conta Cloudflare operacional
- Worker publicado
- banco `D1`
- secrets configurados
- token da Eulen valido
- webhook da Eulen registrado
- token do bot do Telegram
- acesso operacional aos logs

## Assumptions adotadas para este pacote

- o MVP comercial inicial vende `DePix`
- qualquer expansao para outros ativos fica para fase posterior
- um time pequeno ou agentes conseguem trabalhar em sprints curtas de 1 semana
- a operacao inicial pode ser controlada e assistida
- ainda nao e necessario painel web

## Criterio de escopo completo

O MVP e considerado completo quando:

- o usuario consegue sair da conversa ate a cobranca
- o pagamento confirmado muda o estado interno corretamente
- a entrega de `DePix` e concluida no fluxo definido
- o sistema tolera webhook ausente ou atrasado com reconciliacao
- erros operacionais possuem tratamento minimo
- existe trilha de logs e runbook suficiente para operar

## Fronteira de backlog

O backlog obrigatorio e formado apenas pelos itens `P0` e `P1` do [[Misc/DePix/Scrum/04 - Backlog Mestre Priorizado|Backlog Mestre Priorizado]].

Itens `P2` e `P3` existem apenas como opcao posterior, nunca como pre-requisito para declarar o MVP concluido.
