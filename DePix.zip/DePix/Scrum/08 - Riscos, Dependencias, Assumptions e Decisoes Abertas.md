# Riscos, Dependencias, Assumptions e Decisoes Abertas

Voltar para [[Misc/DePix/Scrum/00 - Indice e Visao Consolidada do MVP|Indice e Visao Consolidada do MVP]]

## Dependencias obrigatorias

### Externas

- token Eulen valido
- cadastro do webhook `deposit`
- token do bot Telegram
- conta Cloudflare com `Workers`, `D1`, `Cron` e `Secrets`

### Internas

- definicao comercial `DePix-first`
- schema de `D1`
- client Eulen isolado
- estado interno e identificadores consistentes
- runbook minimo

## Riscos principais

| ID | Risco | Impacto | Probabilidade | Mitigacao |
|---|---|---|---|---|
| R-01 | Duplicidade por retry com novo `nonce` | Alto | Medio | Maquina de estados e regra de idempotencia |
| R-02 | Webhook duplicado concluir duas vezes | Alto | Medio | Persistir evento antes da transicao e tratar idempotencia |
| R-03 | Ausencia de webhook deixar pedido invisivel | Alto | Medio | Cron de reconciliacao com `deposit-status` e `deposits` |
| R-04 | Segredo exposto em codigo ou logs | Alto | Baixo | `Cloudflare Secrets` e revisao de logging |
| R-05 | Escopo abrir para outros ativos antes de consolidar o fluxo atual | Alto | Medio | Manter MVP `DePix-only` |
| R-06 | Logs insuficientes para investigar incidente | Medio | Medio | Contrato minimo de logs e correlation ids |
| R-07 | Dependencia exagerada de servicos opcionais da Cloudflare | Medio | Baixo | Manter stack base enxuta |

## Assumptions adotadas

- o MVP que este pacote fecha e de venda de `DePix`
- a operacao inicial pode ser controlada e nao exige painel completo
- uma equipe pequena ou agentes podem trabalhar em sprints de 1 semana
- `Workers + D1 + Cron + Logs + Secrets` e suficiente para a primeira operacao
- `Durable Objects` ficam fora ate existir prova de corrida real

## Decisoes ja fechadas

- canal inicial: `Telegram`
- persistencia principal: `D1`
- runtime: `Workers`
- segredos: `Cloudflare Secrets`
- confirmacao primaria: webhook
- fallback: `deposit-status` e `deposits`
- MVP comercial: `DePix-first`

## Decisoes abertas nao bloqueantes

Nenhuma decisao aberta bloqueia a execucao do backlog `P0` e `P1`.

Ainda assim, itens abaixo podem aparecer depois do MVP:

- necessidade real de `Durable Objects`
- necessidade de `Queues`
- necessidade de `Pages` para suporte ou painel simples
- eventual expansao para outros canais

## Sinais de que o MVP saiu da fronteira correta

Se qualquer um destes sinais aparecer, o time deve pausar e reavaliar:

- backlog comecar a incluir outros ativos antes da hora
- backlog incluir painel operacional completo
- backlog incluir IA de suporte
- backlog incluir marketing ou curso
- backlog comecar a depender de muitos servicos Cloudflare opcionais

## Plano de mitigacao por fase

### Antes da cobranca

- validar secrets
- validar `ping`
- revisar input do usuario

### Antes de producao

- registrar webhook
- testar `deposit`
- testar cron de reconciliacao
- verificar logs

### Durante operacao

- monitorar pedidos pendentes
- monitorar estados operacionais
- conferir trilha por `orderId` e `depositId`

## Tabela final de verificacao

| Item | Status | Observacao |
|---|---|---|
| Escopo fiel aos docs | OK | Fronteira segue os docs mais operacionais |
| Sem features inventadas | OK | Expansoes foram mantidas fora |
| Backlog completo | OK | Produto, infra, integracao, operacao, QA e release incluidos |
| Dependencias mapeadas | OK | Dependencias internas e externas listadas |
| Historias implementaveis | OK | Stories ligadas a epics, tarefas e fluxos |
| Sprints coerentes | OK | Ordem respeita dependencias e risco |
| DoD suficiente | OK | Definido em arquivo proprio |
| Cobertura tecnica do MVP | OK | Worker, D1, webhook, cron, segredos e logs cobertos |
| Cobertura operacional do MVP | OK | Reconciliacao, runbook e tratamento operacional incluidos |
| Estado final realmente entrega o MVP | OK | MVP DePix-first fica operavel |
