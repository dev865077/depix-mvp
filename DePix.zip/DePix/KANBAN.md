---

kanban-plugin: board

---

## BACKLOG

<<<<<<< HEAD
- [ ] [[Misc/DePix/Backlog Scrum do MVP#EP01 - Base e Integracao|EP01 - Base e Integracao]] `T15 / R29`
- [ ] [[Misc/DePix/Backlog Scrum do MVP#EP02 - Bot, Pedido e Cobranca|EP02 - Bot, Pedido e Cobranca]] `T19 / R29`
- [ ] [[Misc/DePix/Backlog Scrum do MVP#EP03 - Confirmacao e Fallback|EP03 - Confirmacao e Fallback]] `T17 / R34`
- [ ] [[Misc/DePix/Backlog Scrum do MVP#EP04 - Logs e Testes|EP04 - Logs e Testes]] `T18 / R34`
=======
- [ ] [[Misc/DePix/Backlog Scrum do MVP#EP02 - Bot, Pedido e Cobranca|EP02 - Bot, Pedido e Cobranca]] `T19 / R29`
- [ ] [[Misc/DePix/Backlog Scrum do MVP#EP03 - Confirmacao e Fallback|EP03 - Confirmacao e Fallback]] `T17 / R34`
- [ ] [[Misc/DePix/Backlog Scrum do MVP#EP04 - Logs e Testes|EP04 - Logs e Testes]] `T18 / R34`

>>>>>>> origin/main

## EM PROCESSO

- [ ] [[Misc/DePix/Backlog Scrum do MVP#EP01 - Base e Integracao|EP01 - Base e Integracao]] `T15 / R29`


## CONCLUIDOS
<<<<<<< HEAD
=======


>>>>>>> origin/main



%% kanban:settings
```
{"kanban-plugin":"board","list-collapse":[false,false,false]}
```
%%