<<<<<<< HEAD
# Arquitetura Tecnica do MVP

> [!tip]
> Documento mestre: [[Misc/DePix/Contexto|Contexto]]
>
> Fluxo funcional: [[Misc/DePix/Faturamento Automações|Faturamento Automacoes]]
>
> Backlog: [[Misc/DePix/Backlog Scrum do MVP|Backlog Scrum do MVP]]
=======
Documento mestre: [[Misc/DePix/Contexto|Contexto]]
Fluxo funcional: [[Misc/DePix/Faturamento Automações|Faturamento Automações]]
Backlog: [[Misc/DePix/Backlog Scrum do MVP|Backlog Scrum do MVP]]
>>>>>>> origin/main

## Objetivo

Descrever a arquitetura minima do MVP ja alinhada ao stack OSS escolhido.

## Decisao de arquitetura

- `Cloudflare Worker` unico
- `Hono` como borda HTTP
- `grammY` para Telegram
- `XState` para maquina de conversa e do pedido
<<<<<<< HEAD
- `Drizzle ORM` sobre `Cloudflare D1`
=======
- `Cloudflare D1` com `SQL cru`
- `env.DB.batch()` como padrao obrigatorio para writes criticos multi-tabela
- um bot Telegram por parceiro
- um `Cloudflare Worker` compartilhado
- um `Cloudflare D1` compartilhado com isolamento por `tenantId`
- catalogo por parceiro
>>>>>>> origin/main
- `Vitest` + integracao de testes do `Cloudflare Workers` + `MSW`
- sem microservicos e sem fila no MVP

## Visao do sistema

```mermaid
flowchart LR
<<<<<<< HEAD
    U["Usuario"] --> TG["Telegram"]
    TG --> BOT["grammY"]

    subgraph W["Cloudflare Worker"]
=======
    U["Usuario"] --> TB["Bot Telegram do parceiro"]
    TB --> W["Cloudflare Worker"]

    subgraph W["Plano de controle compartilhado"]
>>>>>>> origin/main
        H["Hono"]
        XM["XState Machines"]
        S1["Order Service"]
        S2["Deposit Service"]
        S3["Webhook Service"]
        S4["Recheck Service"]
<<<<<<< HEAD
        BOT --> H
=======
>>>>>>> origin/main
        H --> S1
        S1 --> XM
        H --> S2
        H --> S3
        H --> S4
    end

<<<<<<< HEAD
    W --> DB["Drizzle + D1"]
    W --> API["Eulen API"]
    API -->|deposit webhook| W
    W --> X["Entrega externa de BTC/USDT"]
=======
    W --> DB["D1"]
    W --> API["Eulen API"]
    API -->|deposit webhook| W
    W --> END["Pedido encerrado"]
>>>>>>> origin/main
```

## Componentes

### 1. `Hono`

Camada unica de entrada HTTP do MVP.

Rotas minimas:

- `GET /health`
<<<<<<< HEAD
- `POST /telegram/webhook`
- `POST /webhooks/eulen/deposit`
=======
- `POST /telegram/webhook/:tenantSlug`
- `POST /webhooks/eulen/:tenantSlug/deposit`
>>>>>>> origin/main
- `POST /ops/recheck/deposit`

### 2. `grammY`

<<<<<<< HEAD
Camada do Telegram dentro do mesmo Worker.
=======
Camada do Telegram dentro do mesmo Worker compartilhado.
>>>>>>> origin/main

Responsabilidades:

- receber o webhook do Telegram
<<<<<<< HEAD
- tratar comandos e mensagens
- conduzir o fluxo `ativo -> valor -> carteira`
=======
- resolver o `tenantId` do bot parceiro na entrada
- carregar o catalogo do parceiro
- tratar comandos e mensagens
- conduzir o fluxo adequado ao item escolhido no catalogo
>>>>>>> origin/main
- devolver QR e mensagens de status

### 3. Servicos de aplicacao

Separacao minima recomendada:

- `order service`: cria e atualiza o pedido
- `deposit service`: chama `deposit`, aplica split e persiste cobranca
- `webhook service`: processa evento da Eulen
- `recheck service`: usa `deposit-status` e `deposits` quando preciso
<<<<<<< HEAD
=======
- todos os services operam no escopo de `tenantId`
>>>>>>> origin/main

### 4. `XState`

Camada de estado explicito do MVP.

Responsabilidades:

- dirigir a conversa do Telegram
- controlar transicoes validas do pedido
- evitar `if/else` espalhado entre bot, servicos e webhook
- deixar os eventos principais claros no codigo
<<<<<<< HEAD
### 5. `Drizzle` + `D1`
=======
### 5. `D1` + `SQL cru`
>>>>>>> origin/main

Persistencia unica do MVP.

Ela deve guardar:

<<<<<<< HEAD
=======
- tenant
- bot Telegram
- catalogo
>>>>>>> origin/main
- estado da conversa
- pedido
- cobranca
- historico de eventos externos

<<<<<<< HEAD
### 6. Client Eulen

Camada isolada de integracao HTTP.

Responsabilidades:

- `ping`
- `deposit`
- `deposit-status`
- `deposits`
- `Authorization`
- `X-Nonce`
- `X-Async`

### 7. Saida externa de entrega

So existe para `BTC` e `USDT`.

No MVP, ela nao entra na API da Eulen. O sistema apenas libera uma saida clara para o fluxo externo de entrega.

## Modelo minimo de dados

### `orders`
=======
Regras da camada de dados:

- `D1` e o banco unico do MVP
- migrations SQL devem ser versionadas
- queries ficam isoladas por modulo ou repositorio
- evitar SQL espalhado em handlers HTTP
- sem ORM no MVP
- `env.DB.batch()` e obrigatorio quando uma mesma transicao tocar `orders`, `deposits` e/ou `deposit_events`
- tabelas centrais carregam `tenantId`
- toda query operacional filtra por `tenantId`

### 5.1 Atomicidade e consistencia de transacoes

`D1` opera em `auto-commit`. Isso significa que uma query isolada via `prepare(...).bind(...).run()` faz commit sozinha. Se um fluxo gravar `orders`, depois `deposits`, e a segunda query falhar, a primeira ja ficou persistida.

No Worker Binding do `D1`, o mecanismo oficial para atomicidade de multiplos statements e `env.DB.batch()`. O lote executa statements preparados em ordem e, se um deles falhar, o `D1` aborta ou faz rollback da sequencia inteira.

No projeto, `BEGIN TRANSACTION`, `COMMIT` e `ROLLBACK` nao entram como padrao de implementacao. O padrao obrigatorio para escrita critica e `env.DB.batch()` com prepared statements.

| Padrao | Comportamento no `D1` | Risco | Uso no MVP |
|---|---|---|---|
| query isolada com `prepare().run()` | cada statement faz commit individual | alto quando a mesma mudanca depende de mais de uma tabela | leituras, consultas pontuais e writes simples de uma unica tabela |
| `env.DB.batch([...])` | statements executam em ordem dentro de uma transacao atomica | baixo, desde que o lote cubra toda a mudanca critica | obrigatorio em cobranca, webhook, recheck e finalizacao de status |

### 5.2 Riscos de estado inconsistente

Sem atomicidade, os riscos centrais do MVP sao:

- `orders` em `pending` sem linha correspondente em `deposits`
- `deposit_events` persistido sem atualizacao de `deposits` e `orders`
- `deposits` marcado com status novo enquanto `orders` permanece em status antigo
- recheck corrigindo so uma tabela e deixando a outra em divergencia
- status final como `depix_sent`, `under_review`, `error`, `expired`, `canceled` ou `refunded` aplicado pela metade
>>>>>>> origin/main

Exemplos concretos de falha:

- o `deposit` responde com sucesso, a insercao em `deposits` passa, mas o update de `orders` falha: o QR existe no banco, mas o pedido continua em `draft`
- o webhook entra, `deposit_events` e persistido, mas a atualizacao de `orders` falha: a auditoria mostra pagamento confirmado, mas o pedido nao fecha
- o recheck corrige `deposits.externalStatus`, mas nao corrige `orders.status`: a operacao enxerga duas verdades para o mesmo pedido

### 5.3 Fluxos que exigem atomicidade

Operacoes que devem usar `env.DB.batch()` neste MVP:

1. criacao de pedido + deposito no fim da conversa
2. processamento do webhook da Eulen
3. recheck e reconciliacao de status
4. finalizacao de status do pedido
### 6. Client Eulen

Camada isolada de integracao HTTP.

Responsabilidades:

- `ping`
- `deposit`
- `deposit-status`
- `deposits`
- `Authorization`
- `X-Nonce`
- `X-Async`
- resolver a conta Eulen correta do tenant
- suportar conta compartilhada ou propria por parceiro

### 7. Conclusao do pedido

No MVP, o fluxo termina no proprio `DePix`.

Quando o status chega a `depix_sent`, o sistema pode encerrar o pedido dentro do proprio Worker.

## Modelo minimo de dados

### `tenants`

- `tenantId`
- `slug`
- `displayName`
- `status`
- `createdAt`
- `updatedAt`

### `telegram_bots`

- `tenantId`
- `botToken`
- `botUsername`
- `webhookPath`
- `createdAt`
- `updatedAt`

### `eulen_accounts`

- `tenantId`
- `mode`
- `authTokenRef`
- `webhookSecretRef`
- `createdAt`
- `updatedAt`

### `products`

- `tenantId`
- `productId`
- `productType`
- `title`
- `status`
- `createdAt`
- `updatedAt`

### `orders`

- `tenantId`
- `orderId`
- `userId`
- `channel`
<<<<<<< HEAD
=======
- `productId`
>>>>>>> origin/main
- `productType`
- `amountInCents`
- `walletAddress`
- `currentStep`
- `status`
- `splitAddress`
- `splitFee`
- `createdAt`
- `updatedAt`

### `deposits`

- `tenantId`
- `orderId`
- `depositEntryId`
- `nonce`
- `qrId`
- `qrCopyPaste`
- `qrImageUrl`
- `externalStatus`
- `expiration`
- `createdAt`
- `updatedAt`

### `deposit_events`

- `tenantId`
- `orderId`
<<<<<<< HEAD
- `depositId`
=======
- `depositEntryId`
- `qrId`
>>>>>>> origin/main
- `source`
- `externalStatus`
- `bankTxId`
- `blockchainTxID`
- `rawPayload`
- `receivedAt`

<<<<<<< HEAD
## Fluxos principais

### 1. Conversa e pedido

1. `grammY` recebe a mensagem.
2. `XState` calcula a proxima transicao valida.
3. `order service` atualiza `currentStep` no banco.
4. Quando os dados ficam completos, o pedido sai de `draft`.

### 2. Cobranca

1. `deposit service` gera `nonce`.
2. Chama `deposit` com split.
3. Persiste `depositId`, QR e status inicial.
4. O bot responde com os dados de pagamento.

### 3. Confirmacao

1. `webhook service` recebe o evento da Eulen.
2. Persiste o payload em `deposit_events`.
3. `XState` aplica a transicao valida do pedido.
4. Atualiza `orders` e `deposits`.
5. Decide conclusao, fila manual ou entrega externa.

### 4. Recheck

1. Se o webhook falhar ou ficar duvidoso, `recheck service` consulta `deposit-status`.
2. Se a divergencia for maior, consulta `deposits` por janela.
3. O resultado corrige o estado interno.

## Logs

=======
## Identificadores canonicos

### IDs do fluxo

| ID | Origem | Uso correto |
|---|---|---|
| `tenantId` | sistema interno | eixo de isolamento logico entre parceiros |
| `orderId` | sistema interno | chave do pedido no bot |
| `nonce` | header `X-Nonce` | representa a intencao da cobranca; retry da mesma cobranca reutiliza o mesmo valor |
| `depositEntryId` | `response.id` do `POST /deposit` | identificador correto para `deposit-status` |
| `qrId` | webhook da Eulen e `deposits` | identificador do QR/deposito confirmado externamente |
| `bankTxId` | webhook/evento externo | conciliacao bancaria quando existir |
| `blockchainTxID` | webhook/evento externo | conciliacao on-chain quando existir |

## Fluxos principais

### 1. Conversa e pedido

1. `grammY` recebe a mensagem no bot do parceiro.
2. `Hono` e a camada de entrada resolvem `tenantId` e carregam o catalogo do parceiro.
3. `XState` calcula a proxima transicao valida para o item escolhido.
4. `order service` atualiza `currentStep` no banco.
5. Quando os dados ficam completos e a cobranca e aceita, `order service` e `deposit service` persistem `orders` e `deposits` no mesmo `batch()`, no escopo do tenant.

### 2. Cobranca

1. `deposit service` gera `nonce`.
2. Resolve a conta Eulen correta do tenant e chama `deposit` com split.
3. Persiste `tenantId`, `depositEntryId`, `nonce`, QR e status inicial em lote atomico com o update do pedido.
4. O bot responde com os dados de pagamento.

### 3. Confirmacao

1. `webhook service` recebe o evento da Eulen e resolve o tenant correto.
2. `XState` calcula a transicao valida do pedido.
3. Persiste `deposit_events`, atualiza `deposits` e atualiza `orders` no mesmo `batch()`, sempre dentro do mesmo `tenantId`.
4. Decide conclusao, fila manual ou entrega externa.

### 4. Recheck

1. Se o webhook falhar ou ficar duvidoso, `recheck service` consulta `deposit-status` pelo `depositEntryId`.
2. Se a divergencia for maior, consulta `deposits` por janela e correlaciona pelo `qrId`.
3. Se houver correcao multi-tabela, o resultado e aplicado com `batch()` para manter `orders` e `deposits` sincronizados dentro do tenant.

## Logs

>>>>>>> origin/main
Cada evento relevante deve carregar:

- `tenantId`
- `orderId`
<<<<<<< HEAD
- `depositId`
=======
- `depositEntryId`
- `qrId`
>>>>>>> origin/main
- `nonce`
- `currentStep`
- `externalStatus`
- `requestId`, se existir

Nunca logar:

- token JWT
- segredo do webhook
- headers sensiveis completos

## Testes

Cobertura minima do MVP:

- unitarios da regra de pedido, split e mapeamento de status
- unitarios das maquinas de estado
- integracao do client Eulen
- webhook com idempotencia
- fluxo critico completo do pedido

Stack definida:

- `Vitest`
- integracao de testes do `Cloudflare Workers`
<<<<<<< HEAD
- `MSW`
=======
- `MSW` 
>>>>>>> origin/main
- `XState`
