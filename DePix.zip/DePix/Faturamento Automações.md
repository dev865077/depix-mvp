# Faturamento e Automacoes do MVP

<<<<<<< HEAD
> [!tip]
> Documento mestre: [[Misc/DePix/Contexto|Contexto]]
>
> Arquitetura: [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]
>
> Backlog: [[Misc/DePix/Backlog Scrum do MVP|Backlog Scrum do MVP]]
=======
Documento mestre: [[Misc/DePix/Contexto|Contexto]]
Arquitetura: [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]
Backlog: [[Misc/DePix/Backlog Scrum do MVP|Backlog Scrum do MVP]]
>>>>>>> origin/main

## Objetivo

Definir como o MVP usa a API da Eulen/DePix no fluxo real de venda, cobranca e confirmacao.

## Decisoes travadas do MVP

- a API da Eulen entra como camada de cobranca e confirmacao
- split faz parte obrigatoria do `deposit`
- `DePix` pode ser concluido dentro do fluxo da API
<<<<<<< HEAD
- `BTC` e `USDT` ficam com entrega final fora da API da Eulen
- o MVP sera implementado com `Hono`, `grammY`, `XState`, `Drizzle` e `Cloudflare D1`

## Fluxo tecnico do MVP

```mermaid
flowchart LR
    U["Usuario"] --> T["Telegram"]
    T --> G["grammY"]
    G --> H["Hono / Cloudflare Worker"]
    H --> DB["Drizzle + D1"]
    H --> E["Cliente Eulen"]
    E --> API["Eulen API"]
    API -->|qrCopyPaste + qrImageUrl| H
    H --> G
    API -->|deposit webhook| H
    H --> DB
    H --> X["Entrega externa de BTC/USDT"]
```

## Stack usada no fluxo

| Camada | Escolha | Papel no MVP |
|---|---|---|
| HTTP e webhooks | `Hono` | rotas, middleware e borda do Worker |
| Telegram | `grammY` | webhook do bot, comandos e conversa |
| Estados | `XState` | conversa guiada e transicoes do pedido |
| Persistencia | `Drizzle ORM` + `Cloudflare D1` | pedido, cobranca, eventos e estado da conversa |
| Testes | `Vitest` + `Cloudflare Workers` + `MSW` | unitario, integracao, webhook e fluxo critico |

## O que usamos da API no MVP

- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#🔑 Authentication|Authentication]] para token
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#Ping|Ping]] para validar ambiente
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#Deposit (PIX ➔ DePix)|Deposit (PIX ➔ DePix)]] para criar a cobranca
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#DepositRequest|DepositRequest]] para o request
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#🪝 Webhook|Webhook]] para confirmacao principal
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#Deposit Status|Deposit Status]] para fallback por deposito
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#Deposits|Deposits]] para fallback por janela
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#🎲 Nonce|Nonce]] para idempotencia
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#🔄 Sync / Async call|Sync / Async call]] para retry controlado

## Request real do `deposit` no MVP

| Campo | Origem | Uso |
|---|---|---|
=======
- o MVP cobre apenas `DePix`
- o MVP sera implementado com `Hono`, `grammY`, `XState`, `Cloudflare D1` e `SQL cru`
- existe um bot Telegram por parceiro
- o Worker e compartilhado entre parceiros
- o `D1` e compartilhado com isolamento por `tenantId`
- o catalogo e carregado por parceiro

## Parametros financeiros publicos observados

Tabela publica observada em [depix.online/faq](https://depix.online/faq) em `2026-04-15`.

### Taxas publicas de compra

| Faixa | Taxa publica |
|---|---|
| `R$ 100 - R$ 499` | `10% + R$ 0,99` |
| `R$ 500 - R$ 2.000` | `3% + R$ 0,99` |
| `R$ 2.001 - R$ 3.500` | `2% + R$ 0,99` |
| `R$ 3.501 - R$ 5.000` | `1,5% + R$ 0,99` |

### Taxas publicas de venda

| Faixa | Taxa publica |
|---|---|
| `R$ 499 - R$ 2.000` | `5%` |
| `R$ 2.001 - R$ 3.500` | `4%` |
| `R$ 3.501 - R$ 6.000` | `3%` |

### Limites publicos relevantes

| Regra | Valor publico observado |
|---|---|
| compra minima | `R$ 100` |
| venda minima | `R$ 500` |
| limite diario por CPF/CNPJ | `R$ 6.000` |
| limite por transacao | `R$ 5.000` |
| frequencia | `1` transacao a cada `30` minutos por CPF/CNPJ |

Esses numeros sao importantes porque afetam onboarding, UX, volume maximo por usuario e a leitura de margem do bot.

## Fluxo tecnico do MVP

### 1. Visao geral do sistema

```mermaid
flowchart LR
    U["Usuario"] --> TG["Bot Telegram do parceiro"]
    TG --> W["Cloudflare Worker compartilhado<br/>Hono + grammY + XState + Services"]
    W --> DB["D1"]
    W --> EC["Cliente Eulen"]
    EC --> API["Eulen API"]
    API -->|deposit webhook| W
    W --> END["Pedido encerrado"]
```

### 2. Conversa, pedido e cobranca

```mermaid
sequenceDiagram
    participant U as Usuario
    participant TG as Bot
    participant H as Hono
    participant G as grammY
    participant XC as XState conversa
    participant OS as Order Service
    participant DS as Deposit Service
    participant DB as D1
    participant EC as Cliente Eulen
    participant API as Eulen API

    U->>TG: envia mensagem
    TG->>H: POST /telegram/webhook/:tenantSlug
    H->>G: resolve tenant e entrega update
    G->>OS: carrega catalogo do parceiro
    G->>XC: envia evento da conversa
    XC->>OS: calcula transicao valida
    OS->>DB: persiste draft e currentStep
    OS->>DS: cria cobranca
    DS->>EC: resolve conta Eulen do tenant
    EC->>API: POST /deposit
    API-->>EC: depositEntryId (response.id), qrCopyPaste, qrImageUrl
    EC-->>DS: resposta normalizada
    DS->>DB: batch atomico atualiza order e cria deposit
    DS-->>G: devolve dados do QR
    G->>TG: responde ao usuario
    TG-->>U: entrega QR e instrucoes
```

### 3. Confirmacao, saida e reconciliacao

```mermaid
sequenceDiagram
    participant API as Eulen API
    participant H as Hono
    participant WS as Webhook Service
    participant XO as XState pedido
    participant DB as D1
    participant RS as Recheck Service

    API->>H: POST /webhooks/eulen/:tenantSlug/deposit
    H->>WS: resolve tenant e entrega webhook
    WS->>XO: calcula transicao valida
    XO->>DB: batch atomico evento + deposito + pedido

    alt produto DePix e status depix_sent
        XO->>DB: status final fica no mesmo batch
    else status under_review, error, expired, canceled ou refunded
        XO->>DB: estado final fica no mesmo batch
    end

    opt webhook ausente ou estado duvidoso
        RS->>API: consulta /deposit-status ou /deposits
        API-->>RS: retorna estado externo
        RS->>XO: recalcula estado correto
        XO->>DB: batch atomico de reconciliacao
    end
```

## Como ler o fluxo tecnico

1. `Hono` e a borda unica do Worker compartilhado. Ele recebe tres entradas reais do sistema: webhook do Telegram do parceiro, webhook da Eulen associado ao parceiro e recheck operacional.
2. `grammY` nao decide regra de negocio. Ele traduz o update do bot do parceiro, chama a maquina da conversa e devolve mensagem ao usuario.
3. `XState` aparece em dois pontos diferentes:
   - maquina da conversa: controla o passo atual `ativo -> valor -> carteira -> confirmacao`
   - maquina do pedido: controla o ciclo `draft -> pending -> depix_sent / under_review / error / expired / canceled / refunded`
4. O fluxo comeca resolvendo `tenantId` e carregando o catalogo do parceiro. O usuario ve apenas o que aquele parceiro oferece.
5. `Order Service` e a camada que transforma eventos da conversa em persistencia real. A cada transicao valida, ele grava `currentStep`, ativo, valor e carteira em `D1`. Isso pode ser query isolada enquanto o pedido ainda esta em `draft`.
6. Quando a maquina do pedido entende que o pedido esta completo e pronto para cobrar, ela libera o `Deposit Service`.
7. `Deposit Service` monta o request com `amountInCents`, `depixSplitAddress`, `splitFee`, `depixAddress` quando aplicavel, `X-Nonce` e `X-Async`, resolve a conta Eulen correta do tenant, chama a Eulen e persiste `depositEntryId` (`response.id`), `qrCopyPaste`, `qrImageUrl` e status inicial. Quando essa gravacao tambem muda o status do pedido, `orders` e `deposits` entram no mesmo `env.DB.batch()`.
8. A resposta de cobranca sai do Worker pelo caminho `Deposit Service -> grammY -> bot do parceiro`. O QR nao sai direto da Eulen para o usuario; ele sempre passa pelo Worker.
9. O webhook da Eulen entra por `Hono`, passa pelo `Webhook Service`, resolve o tenant correto, valida autenticacao, calcula a transicao valida e grava `deposit_events`, `deposits` e `orders` no mesmo `env.DB.batch()`.
10. A maquina do pedido decide a saida final:
   - `DePix`: `depix_sent` pode encerrar o pedido
   - `under_review`, `error`, `expired`, `canceled` e `refunded` levam para tratamento especifico
11. `Recheck Service` nao faz parte do caminho feliz. Ele entra quando o webhook nao chegou ou quando o estado ficou duvidoso, usando `deposit-status` por `depositEntryId` e `deposits` por janela para reconciliar e corrigir o estado interno. Quando a reconciliacao toca mais de uma tabela, ela tambem usa `env.DB.batch()`, sempre no escopo do tenant.

## Atomicidade nos fluxos criticos

`D1` faz `auto-commit` por statement. Por isso, query isolada serve para leituras e writes simples de uma unica tabela, mas nao para transicoes que precisam manter `orders`, `deposits` e `deposit_events` coerentes.

Fluxos que devem usar `env.DB.batch()`:

1. fim da conversa com criacao da cobranca
2. processamento do webhook da Eulen
3. recheck e reconciliacao
4. aplicacao de status finais do pedido

## Stack usada no fluxo

| Camada          | Escolha                                 | Papel no MVP                                   |
| --------------- | --------------------------------------- | ---------------------------------------------- |
| HTTP e webhooks | `Hono`                                  | rotas, middleware e borda do Worker            |
| Telegram        | `grammY`                                | webhook do bot do parceiro, comandos e conversa|
| Estados         | `XState`                                | conversa guiada e transicoes do pedido         |
| Persistencia    | `Cloudflare D1` + `SQL cru`             | tenant, catalogo, pedido, cobranca, eventos e estado da conversa |
| Testes          | `Vitest` + `Cloudflare Workers` + `MSW` | unitario, integracao, webhook e fluxo critico  |

## O que usamos da API no MVP

- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|Authentication]] para token
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#Ping|Ping]] para validar ambiente
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|Deposit]] para criar a cobranca
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#DepositRequest|DepositRequest]] para o request
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|Webhook]] para confirmacao principal
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#Deposit Status|Deposit Status]] para fallback por deposito
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#Deposits|Deposits]] para fallback por janela
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|Nonce]] para idempotencia
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|Sync / Async call]] para retry controlado

## Request real do `deposit` no MVP

| Campo | Origem | Uso |
|---|---|---|
>>>>>>> origin/main
| `amountInCents` | valor escolhido pelo usuario | cria a cobranca |
| `depixSplitAddress` | configuracao interna | direciona o split |
| `splitFee` | configuracao interna | define o split |
| `depixAddress` | carteira do usuario | so quando o produto for `DePix` |
| `X-Nonce` | sistema | idempotencia por intencao |
| `X-Async` | sistema | modo `auto` do fluxo |

<<<<<<< HEAD
> [!warning]
> `depixSplitAddress` e `splitFee` nunca devem vir do usuario final. Eles entram por configuracao interna do projeto.

## Fluxo de negocio

1. O usuario inicia o fluxo no Telegram.
2. `XState` dirige a conversa e o bot coleta ativo, valor e carteira.
3. O sistema cria ou atualiza um pedido em `draft`.
4. O sistema chama `deposit` com split.
5. O usuario recebe `qrCopyPaste` e `qrImageUrl`.
6. A Eulen confirma o pagamento via webhook.
7. O sistema atualiza o pedido e decide a saida final.

## Status que importam

| Status externo | Tratamento interno |
|---|---|
| `pending` | aguardando pagamento |
| `depix_sent` | pagamento confirmado |
| `under_review` | fila manual |
| `error` | fila manual |
| `expired` | encerrar como expirado |
| `canceled` | encerrar como cancelado |
| `refunded` | encerrar como reembolsado |

> [!note]
> Para `DePix`, `depix_sent` pode encerrar o pedido. Para `BTC` e `USDT`, `depix_sent` confirma o faturamento e libera a entrega externa.

## Fallback

- usar [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#Deposit Status|Deposit Status]] para um deposito especifico
- usar [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#Deposits|Deposits]] para reconciliar por janela
- manter webhook como caminho principal; fallback entra so quando houver falha ou duvida

## Fora do MVP

- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#Pix2FA|Pix2FA]]
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#💬 Pix Messaging|Pix Messaging]]
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#⏱️ QR Delay|QR Delay]]
=======
`depixSplitAddress` e `splitFee` nunca devem vir do usuario final. Eles entram por configuracao interna do projeto.

Na documentacao e no codigo, a convencao de identificadores deve ficar assim:

- `tenantId`: identificador interno do parceiro
- `orderId`: identificador interno do pedido
- `nonce`: identificador da intencao da chamada; retries da mesma cobranca reutilizam o mesmo valor
- `depositEntryId`: `response.id` retornado por `POST /deposit`; e o identificador certo para `deposit-status`
- `qrId`: identificador do QR/deposito que aparece no webhook e em `deposits`; pode nascer depois da criacao inicial da cobranca

## Fluxo de negocio

1. O usuario envia mensagem no bot Telegram do parceiro e o update entra no Worker pelo webhook daquele tenant.
2. `Hono` resolve `tenantId` e entrega o update para `grammY`.
3. `grammY` carrega o catalogo do parceiro e converte a mensagem em evento para a maquina da conversa em `XState`.
4. `Order Service` persiste o estado da conversa e mantem o pedido em `draft` ate os dados obrigatorios ficarem completos.
5. A maquina do pedido libera o `Deposit Service` para criar a cobranca.
6. O `Deposit Service` resolve a conta Eulen correta do tenant, chama `deposit` com split, nonce estavel e modo `async` controlado, depois persiste `depositEntryId`, `nonce` e os dados do QR.
7. O Worker responde ao usuario por meio do `grammY`, no bot do parceiro, com `qrCopyPaste` e `qrImageUrl`.
8. Quando a Eulen envia o webhook, `Webhook Service` resolve o tenant correto, valida, persiste `qrId` e status externo, aplica idempotencia e consulta a maquina do pedido.
9. A maquina do pedido atualiza `orders` e `deposits`, decide conclusao e tratamento manual dentro do escopo do tenant.
10. Se o webhook falhar ou houver divergencia, `Recheck Service` usa `deposit-status` por `depositEntryId` e `deposits` por janela/`qrId` para reconciliar o estado.

## Status que importam

| Status externo | Tratamento interno |
|---|---|
| `pending` | aguardando pagamento |
| `depix_sent` | pagamento confirmado |
| `under_review` | fila manual |
| `error` | fila manual |
| `expired` | encerrar como expirado |
| `canceled` | encerrar como cancelado |
| `refunded` | encerrar como reembolsado |

## Leitura financeira direta do app

### Formulas base

- `receita bruta do app = volume bruto do mes x taxa cobrada do app`
- `custo Eulen sem pool propria = soma das taxas de compra e venda em cada ordem`
- `custo Eulen com pool propria = taxa Eulen apenas sobre o volume liquido levado para rebalance`
- `margem bruta antes de suporte, fraude, rede Liquid e hedge = receita bruta do app - custo Eulen`

### Receita bruta do app por taxa propria

| Volume bruto do mes | `1%` | `1,5%` | `2%` |
|---|---|---|---|
| `R$ 100.000` | `R$ 1.000` | `R$ 1.500` | `R$ 2.000` |
| `R$ 250.000` | `R$ 2.500` | `R$ 3.750` | `R$ 5.000` |
| `R$ 500.000` | `R$ 5.000` | `R$ 7.500` | `R$ 10.000` |

### Exemplo direto de margem

Hipotese:

- `100` compras de `R$ 1.000`
- `80` vendas de `R$ 1.000`
- taxa do app: `1,5%`
- volume bruto: `R$ 180.000`
- desequilibrio liquido a rebalancear: `R$ 20.000` de compra

| Item | Sem pool propria | Com pool propria |
|---|---|---|
| receita bruta do app | `R$ 2.700,00` | `R$ 2.700,00` |
| custo Eulen em compras | `R$ 3.099,00` | `R$ 619,80` |
| custo Eulen em vendas | `R$ 4.000,00` | `R$ 0,00` |
| margem bruta antes de outros custos | `-R$ 4.399,00` | `R$ 2.080,20` |

Leitura objetiva:

- sem netting interno, a margem pode morrer na taxa da Eulen
- com pool propria, a taxa da Eulen deixa de incidir no bruto e passa a incidir no liquido
- a tese economica do sistema melhora muito quando compra e venda se compensam internamente

## Fallback

- usar [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#Deposit Status|Deposit Status]] para um deposito especifico, consultando pelo `depositEntryId`
- usar [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#Deposits|Deposits]] para reconciliar por janela e correlacionar pelo `qrId`
- manter webhook como caminho principal; fallback entra so quando houver falha ou duvida

## Fora do MVP

- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#Pix2FA|Pix2FA]]
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|Pix Messaging]]
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|QR Delay]]
>>>>>>> origin/main
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#User Info|User Info]]
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa#Withdraw|Withdraw]]
- fila dedicada
- painel interno
