
- [ ] Remover do código de produção Drizzle e implementar SQL nativo.
- [ ] Deixa o código acessível pelo Obsidian para eu poder ler e entender durante labor
- [ ] Apresentação Leandro


Pensando nessa apresnetação em fazer o bot ser meu e ele ser um cliente dele, ou seja, gahar 30% SOBRE AS VENDAS DELE NESSE BOT MAS CADA UM SER LIVRE PRA VENDER ONDE QUISER, PRA QUEM QUISER, E EU USAR ESSE BOT COMIGO 