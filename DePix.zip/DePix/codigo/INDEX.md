# codigo

## Pastas

- [Docs](Docs/INDEX.md)
- [migrations](migrations/INDEX.md)
- [scripts](scripts/INDEX.md)
- [src](src/INDEX.md)
- [test](test/INDEX.md)

## Arquivos

- [dot-dev.vars.example.md](dot-dev.vars.example.md)
- [dot-gitignore.md](dot-gitignore.md)
- [Arquitetura Tecnica do MVP.md](Arquitetura Tecnica do MVP.md)
- [Backlog Scrum do MVP.md](Backlog Scrum do MVP.md)
- [Contexto.md](Contexto.md)
- [Exportar Codigo Para Obsidian.cmd.md](Exportar Codigo Para Obsidian.cmd.md)
- [Faturamento Automações.md](Faturamento Automações.md)
- [KANBAN.md](KANBAN.md)
- [Mapa de Uso da API.md](Mapa de Uso da API.md)
- [package-lock.json.md](package-lock.json.md)
- [package.json.md](package.json.md)
- [vitest.config.js.md](vitest.config.js.md)
- [worker-configuration.d.ts.md](worker-configuration.d.ts.md)
- [wrangler.jsonc.md](wrangler.jsonc.md)

Exportado automaticamente em 15/04/2026, 22:17:46.

Raiz original do repositório: `C:/Users/poske/Desktop/DePix MVP`
