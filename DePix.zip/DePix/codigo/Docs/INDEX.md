# codigo/Docs

[Voltar para a pasta anterior](../INDEX.md)

## Arquivos

- [Cloudflare para o MVP - Free Tier e Arquitetura Simples.md](Cloudflare para o MVP - Free Tier e Arquitetura Simples.md)
- [Pix2DePix API - Documentacao Completa.md](Pix2DePix API - Documentacao Completa.md)

Exportado automaticamente em 15/04/2026, 22:17:46.

Raiz original do repositório: `C:/Users/poske/Desktop/DePix MVP`
