# request-context.js

Origem no repositório: `src/middleware/request-context.js`

````javascript
/**
 * Middleware responsável por contexto de requisição.
 *
 * Este middleware cria o requestId, mede a duração de cada chamada, lê a
 * configuração segura do runtime e adiciona logs estruturados de entrada e
 * saída para todas as rotas do Worker.
 */
import { readRuntimeConfig } from "../config/runtime.js";
import { getDatabase } from "../db/client.js";
import { log } from "../lib/logger.js";

/**
 * Prepara o contexto de cada requisição antes de chegar às rotas.
 *
 * @param {import("hono").Context} c Contexto da requisição atual.
 * @param {import("hono").Next} next Próximo passo da cadeia de middlewares.
 * @returns {Promise<void>} Promessa resolvida quando a requisição termina.
 */
export async function requestContextMiddleware(c, next) {
  const requestId = crypto.randomUUID();
  const requestStartedAt = Date.now();
  const runtimeConfig = readRuntimeConfig(c.env);
  const db = runtimeConfig.database.bindingConfigured ? getDatabase(c.env) : undefined;

  c.set("requestId", requestId);
  c.set("requestStartedAt", requestStartedAt);
  c.set("runtimeConfig", runtimeConfig);
  c.set("db", db);

  log(runtimeConfig, {
    level: "info",
    message: "request.received",
    requestId,
    method: c.req.method,
    path: c.req.path,
  });

  await next();

  c.header("x-request-id", requestId);

  log(runtimeConfig, {
    level: "info",
    message: "request.completed",
    requestId,
    method: c.req.method,
    path: c.req.path,
    status: c.res.status,
    durationMs: Date.now() - requestStartedAt,
  });
}

````
