# codigo/src/middleware

[Voltar para a pasta anterior](../INDEX.md)

## Arquivos

- [request-context.js.md](request-context.js.md)

Exportado automaticamente em 15/04/2026, 22:17:46.

Raiz original do repositório: `C:/Users/poske/Desktop/DePix MVP`
