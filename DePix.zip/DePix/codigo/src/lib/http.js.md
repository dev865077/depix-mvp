# http.js

Origem no repositório: `src/lib/http.js`

````javascript
/**
 * Utilitários HTTP compartilhados pela aplicação.
 *
 * Este arquivo padroniza respostas de erro e respostas de capacidade ainda não
 * implementada, mantendo a API do Worker consistente desde a primeira entrega
 * do projeto.
 */
import { HTTPException } from "hono/http-exception";

/**
 * Cria uma resposta JSON de erro com requestId para facilitar rastreabilidade.
 *
 * @param {import("hono").Context} c Contexto atual da requisição.
 * @param {number} status Status HTTP da resposta.
 * @param {string} code Código interno do erro.
 * @param {string} message Mensagem clara para consumo operacional.
 * @param {Record<string, unknown>=} details Detalhes adicionais sem segredos.
 * @returns {Response} Resposta JSON padronizada.
 */
export function jsonError(c, status, code, message, details) {
  return c.json(
    {
      error: {
        code,
        message,
        details,
      },
      requestId: c.get("requestId"),
    },
    status,
  );
}

/**
 * Retorna um erro padronizado para capacidades que entram em backlog posterior.
 *
 * @param {import("hono").Context} c Contexto atual da requisição.
 * @param {string} capability Nome da capacidade ainda não implementada.
 * @returns {Response} Resposta JSON com status 501.
 */
export function jsonNotImplemented(c, capability) {
  return jsonError(
    c,
    501,
    "feature_not_implemented",
    `${capability} is not implemented yet in this phase of the MVP.`,
  );
}

/**
 * Normaliza qualquer erro para HTTPException, simplificando o handler global.
 *
 * @param {unknown} error Erro bruto lançado em qualquer ponto da aplicação.
 * @returns {HTTPException} Erro HTTP padronizado.
 */
export function normalizeHttpError(error) {
  if (error instanceof HTTPException) {
    return error;
  }

  return new HTTPException(500, {
    message: error instanceof Error ? error.message : "Unexpected internal error",
  });
}

````
