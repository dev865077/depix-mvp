# codigo/src/lib

[Voltar para a pasta anterior](../INDEX.md)

## Arquivos

- [http.js.md](http.js.md)
- [logger.js.md](logger.js.md)

Exportado automaticamente em 15/04/2026, 22:17:46.

Raiz original do repositório: `C:/Users/poske/Desktop/DePix MVP`
