# logger.js

Origem no repositório: `src/lib/logger.js`

````javascript
/**
 * Logger estruturado e mínimo para o MVP.
 *
 * A ideia aqui é gerar logs JSON consistentes para Cloudflare Workers Logs,
 * sempre preservando dados úteis de rastreabilidade e evitando qualquer vazamento
 * de credencial ou header sensível.
 */

const LOG_LEVEL_SEVERITY = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
};

/**
 * Decide se uma mensagem deve ou não ser emitida conforme o nível ativo.
 *
 * @param {"debug" | "info" | "warn" | "error"} configuredLevel Nível configurado no ambiente.
 * @param {"debug" | "info" | "warn" | "error"} incomingLevel Nível do evento atual.
 * @returns {boolean} `true` quando o log deve ser escrito.
 */
export function shouldLog(configuredLevel, incomingLevel) {
  return LOG_LEVEL_SEVERITY[incomingLevel] >= LOG_LEVEL_SEVERITY[configuredLevel];
}

/**
 * Emite um log estruturado pronto para consumo operacional.
 *
 * @param {{
 *   appName: string,
 *   environment: "local" | "test" | "production",
 *   logLevel: "debug" | "info" | "warn" | "error"
 * }} runtimeConfig Configuração segura do runtime atual.
 * @param {{
 *   level: "debug" | "info" | "warn" | "error",
 *   message: string,
 *   requestId?: string,
 *   method?: string,
 *   path?: string,
 *   status?: number,
 *   durationMs?: number,
 *   details?: Record<string, unknown>
 * }} record Conteúdo do evento a ser escrito.
 */
export function log(runtimeConfig, record) {
  if (!runtimeConfig || !shouldLog(runtimeConfig.logLevel, record.level)) {
    return;
  }

  console.log(
    JSON.stringify({
      timestamp: new Date().toISOString(),
      app: runtimeConfig.appName,
      environment: runtimeConfig.environment,
      ...record,
    }),
  );
}

````
