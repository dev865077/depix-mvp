# app.js

Origem no repositório: `src/app.js`

````javascript
/**
 * Composição principal da aplicação Hono.
 *
 * Este arquivo conecta middleware, tratamento global de erro, rotas mínimas do
 * MVP e o redirecionamento da raiz para `/health`. Ele é o coração da borda
 * HTTP do Worker.
 */
import { Hono } from "hono";
import { HTTPException } from "hono/http-exception";

import { requestContextMiddleware } from "./middleware/request-context.js";
import { normalizeHttpError, jsonError } from "./lib/http.js";
import { log } from "./lib/logger.js";
import { healthRouter } from "./routes/health.js";
import { telegramRouter } from "./routes/telegram.js";
import { webhooksRouter } from "./routes/webhooks.js";
import { opsRouter } from "./routes/ops.js";

/**
 * Escreve logs de erro sem quebrar quando o runtimeConfig ainda não existe.
 *
 * @param {import("hono").Context} c Contexto atual da requisição.
 * @param {import("hono/http-exception").HTTPException} httpError Erro HTTP normalizado.
 */
export function logAppError(c, httpError) {
  const runtimeConfig = c.get("runtimeConfig");

  if (!runtimeConfig) {
    return;
  }

  log(runtimeConfig, {
    level: "error",
    message: "request.failed",
    requestId: c.get("requestId"),
    method: c.req.method,
    path: c.req.path,
    status: httpError.status,
    details: {
      error: httpError.message,
    },
  });
}

/**
 * Trata qualquer erro não capturado e devolve JSON padronizado.
 *
 * @param {unknown} error Erro bruto lançado na requisição.
 * @param {import("hono").Context} c Contexto atual da requisição.
 * @returns {Response} Resposta JSON de erro.
 */
export function handleAppError(error, c) {
  const httpError = normalizeHttpError(error);

  logAppError(c, httpError);

  return jsonError(c, httpError.status, "request_failed", httpError.message);
}

/**
 * Responde quando a rota solicitada não existe no Worker.
 *
 * @param {import("hono").Context} c Contexto atual da requisição.
 * @returns {Response} Resposta JSON 404 padronizada.
 */
export function handleNotFound(c) {
  return jsonError(c, 404, "route_not_found", `No route matches ${c.req.path}`);
}

/**
 * Redireciona a raiz da aplicação para o healthcheck oficial.
 *
 * @param {import("hono").Context} c Contexto atual da requisição.
 * @returns {never} Esta função sempre lança um redirecionamento HTTP.
 */
export function handleRootRedirect(c) {
  throw new HTTPException(302, {
    res: c.redirect("/health"),
  });
}

/**
 * Monta a aplicação Hono completa do Worker.
 *
 * @returns {import("hono").Hono} Aplicação pronta para exportar no entrypoint.
 */
export function createApp() {
  const app = new Hono();

  app.use("*", requestContextMiddleware);
  app.onError(handleAppError);
  app.notFound(handleNotFound);

  app.route("/health", healthRouter);
  app.route("/telegram", telegramRouter);
  app.route("/webhooks", webhooksRouter);
  app.route("/ops", opsRouter);
  app.get("/", handleRootRedirect);

  return app;
}

````
