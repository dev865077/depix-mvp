# codigo/src

[Voltar para a pasta anterior](../INDEX.md)

## Pastas

- [clients](clients/INDEX.md)
- [config](config/INDEX.md)
- [db](db/INDEX.md)
- [lib](lib/INDEX.md)
- [middleware](middleware/INDEX.md)
- [routes](routes/INDEX.md)

## Arquivos

- [app.js.md](app.js.md)
- [index.js.md](index.js.md)

Exportado automaticamente em 15/04/2026, 22:17:46.

Raiz original do repositório: `C:/Users/poske/Desktop/DePix MVP`
