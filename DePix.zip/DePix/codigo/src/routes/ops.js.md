# ops.js

Origem no repositório: `src/routes/ops.js`

````javascript
/**
 * Rotas operacionais internas.
 *
 * Este arquivo reserva a superfície HTTP para operações internas do MVP, como
 * o recheck de depósitos. A implementação real entra mais adiante, mas a rota
 * já existe e mantém a estrutura do Worker fechada desde a fundação.
 */
import { Hono } from "hono";

import { jsonNotImplemented } from "../lib/http.js";

export const opsRouter = new Hono();

/**
 * Responde enquanto a operação de recheck ainda não foi implementada.
 *
 * @param {import("hono").Context} c Contexto da requisição atual.
 * @returns {Response} Resposta JSON informando o status da capacidade.
 */
export function handleDepositRecheck(c) {
  return jsonNotImplemented(c, "Deposit recheck operation");
}

opsRouter.post("/recheck/deposit", handleDepositRecheck);

````
