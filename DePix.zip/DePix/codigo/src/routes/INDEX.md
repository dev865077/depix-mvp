# codigo/src/routes

[Voltar para a pasta anterior](../INDEX.md)

## Arquivos

- [health.js.md](health.js.md)
- [ops.js.md](ops.js.md)
- [telegram.js.md](telegram.js.md)
- [webhooks.js.md](webhooks.js.md)

Exportado automaticamente em 15/04/2026, 22:17:46.

Raiz original do repositório: `C:/Users/poske/Desktop/DePix MVP`
