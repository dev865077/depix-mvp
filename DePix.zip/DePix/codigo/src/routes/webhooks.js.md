# webhooks.js

Origem no repositório: `src/routes/webhooks.js`

````javascript
/**
 * Rotas de webhooks externos.
 *
 * Este arquivo já declara o endpoint da Eulen previsto na arquitetura do MVP.
 * A validação e o processamento real entram no BG-07; por enquanto a rota é
 * controlada e deixa claro que o caminho HTTP já existe.
 */
import { Hono } from "hono";

import { jsonNotImplemented } from "../lib/http.js";

export const webhooksRouter = new Hono();

/**
 * Responde de forma controlada até a entrada do processamento real do webhook.
 *
 * @param {import("hono").Context} c Contexto da requisição atual.
 * @returns {Response} Resposta JSON informando o status da capacidade.
 */
export function handleEulenDepositWebhook(c) {
  return jsonNotImplemented(c, "Eulen deposit webhook");
}

webhooksRouter.post("/eulen/deposit", handleEulenDepositWebhook);

````
