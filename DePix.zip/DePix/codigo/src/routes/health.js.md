# health.js

Origem no repositório: `src/routes/health.js`

````javascript
/**
 * Rotas de healthcheck.
 *
 * Este arquivo expõe a rota mais importante da base técnica do MVP: a rota que
 * prova que o Worker subiu, que o Hono está conectado ao entrypoint e que a
 * configuração essencial foi lida com segurança.
 */
import { Hono } from "hono";

export const healthRouter = new Hono();

/**
 * Retorna um retrato seguro da saúde do serviço.
 *
 * @param {import("hono").Context} c Contexto da requisição atual.
 * @returns {Response} Resposta JSON com status do serviço e configuração segura.
 */
export function handleHealth(c) {
  const runtimeConfig = c.get("runtimeConfig");

  return c.json({
    status: "ok",
    service: runtimeConfig.appName,
    environment: runtimeConfig.environment,
    requestId: c.get("requestId"),
    timestamp: new Date().toISOString(),
    configuration: {
      eulenApiBaseUrl: runtimeConfig.eulenApiBaseUrl,
      database: runtimeConfig.database,
      secrets: runtimeConfig.secrets,
    },
  });
}

healthRouter.get("/", handleHealth);

````
