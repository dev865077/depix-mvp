# telegram.js

Origem no repositório: `src/routes/telegram.js`

````javascript
/**
 * Rotas do Telegram.
 *
 * Este arquivo já reserva a borda HTTP que o grammY vai usar no BG-04. Neste
 * momento a rota existe e responde de forma controlada, o que mantém a
 * estrutura do Worker pronta sem simular comportamento que ainda não foi
 * implementado.
 */
import { Hono } from "hono";

import { jsonNotImplemented } from "../lib/http.js";

export const telegramRouter = new Hono();

/**
 * Responde de forma explícita enquanto a integração do bot ainda não entrou.
 *
 * @param {import("hono").Context} c Contexto da requisição atual.
 * @returns {Response} Resposta JSON informando o status da capacidade.
 */
export function handleTelegramWebhook(c) {
  return jsonNotImplemented(c, "Telegram webhook");
}

telegramRouter.post("/webhook", handleTelegramWebhook);

````
