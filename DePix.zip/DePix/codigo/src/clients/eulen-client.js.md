# eulen-client.js

Origem no repositório: `src/clients/eulen-client.js`

````javascript
/**
 * Client HTTP isolado da Eulen.
 *
 * Este módulo concentra autenticação, nonce, async mode, timeout e parsing de
 * resposta para os endpoints usados no MVP. Ele existe para separar integração
 * externa da regra de negócio.
 */

/**
 * Erro padronizado para falhas de integração com a Eulen.
 */
export class EulenApiError extends Error {
  /**
   * Cria um erro rico com contexto suficiente para logs e tratamento.
   *
   * @param {string} message Mensagem principal do erro.
   * @param {Record<string, unknown>=} details Metadados úteis do erro.
   */
  constructor(message, details = {}) {
    super(message);
    this.name = "EulenApiError";
    this.details = details;
  }
}

/**
 * Garante que o token da API exista antes de qualquer chamada externa.
 *
 * @param {Record<string, unknown>} env Bindings recebidos pelo Worker.
 * @returns {string} Token Bearer configurado para a Eulen.
 */
export function assertEulenApiToken(env) {
  if (!env.EULEN_API_TOKEN || String(env.EULEN_API_TOKEN).trim().length === 0) {
    throw new EulenApiError("Missing required Eulen API token.", {
      binding: "EULEN_API_TOKEN",
    });
  }

  return String(env.EULEN_API_TOKEN);
}

/**
 * Gera um nonce novo para uma intenção inédita de chamada externa.
 *
 * @returns {string} Nonce UUID pronto para uso nos headers da Eulen.
 */
export function generateNonce() {
  return crypto.randomUUID();
}

/**
 * Normaliza o modo de chamada assíncrona aceito pela Eulen.
 *
 * @param {string | undefined} asyncMode Valor solicitado pela camada chamadora.
 * @returns {"auto" | "true" | "false"} Valor pronto para o header `X-Async`.
 */
export function normalizeAsyncMode(asyncMode) {
  if (asyncMode === undefined || asyncMode === null || asyncMode === "") {
    return "auto";
  }

  const normalizedValue = String(asyncMode).toLowerCase();

  if (normalizedValue !== "auto" && normalizedValue !== "true" && normalizedValue !== "false") {
    throw new EulenApiError("Invalid Eulen async mode.", {
      asyncMode,
    });
  }

  return normalizedValue;
}

/**
 * Monta os headers obrigatórios para qualquer chamada à API da Eulen.
 *
 * @param {{
 *   token: string,
 *   nonce?: string,
 *   asyncMode?: string,
 *   contentType?: string
 * }} options Opções da chamada atual.
 * @returns {{ headers: Headers, nonce: string, asyncMode: "auto" | "true" | "false" }} Cabeçalhos e valores normalizados.
 */
export function buildEulenRequestHeaders(options) {
  const nonce = options.nonce ?? generateNonce();
  const asyncMode = normalizeAsyncMode(options.asyncMode);
  const headers = new Headers({
    Authorization: `Bearer ${options.token}`,
    "X-Nonce": nonce,
    "X-Async": asyncMode,
  });

  if (options.contentType) {
    headers.set("Content-Type", options.contentType);
  }

  return { headers, nonce, asyncMode };
}

/**
 * Constrói a URL final da chamada a partir do base URL configurado.
 *
 * @param {string} baseUrl URL base configurada para a Eulen.
 * @param {string} path Caminho do endpoint desejado.
 * @param {Record<string, string | undefined>=} query Query string opcional.
 * @returns {string} URL final pronta para o `fetch`.
 */
export function buildEulenUrl(baseUrl, path, query = {}) {
  const normalizedBaseUrl = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  const normalizedPath = path.startsWith("/") ? path.slice(1) : path;
  const url = new URL(normalizedPath, normalizedBaseUrl);

  for (const [key, value] of Object.entries(query)) {
    if (value !== undefined && value !== null && value !== "") {
      url.searchParams.set(key, value);
    }
  }

  return url.toString();
}

/**
 * Cria um controller de timeout para abortar chamadas externas lentas.
 *
 * @param {number} timeoutMs Tempo máximo da chamada em milissegundos.
 * @returns {{ controller: AbortController, cleanup: () => void }} Controller e rotina de limpeza do timeout.
 */
export function createTimeoutController(timeoutMs) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort("Eulen request timeout"), timeoutMs);

  return {
    controller,
    cleanup() {
      clearTimeout(timeoutId);
    },
  };
}

/**
 * Tenta interpretar o corpo da resposta sem assumir sempre JSON válido.
 *
 * @param {Response} response Resposta HTTP recebida da Eulen.
 * @returns {Promise<unknown>} Corpo parseado como JSON quando possível.
 */
export async function parseEulenResponseBody(response) {
  const rawBody = await response.text();

  if (!rawBody) {
    return null;
  }

  try {
    return JSON.parse(rawBody);
  } catch {
    return rawBody;
  }
}

/**
 * Executa uma chamada padronizada para a API da Eulen.
 *
 * @param {Record<string, unknown>} env Bindings recebidos pelo Worker.
 * @param {{
 *   path: string,
 *   method?: string,
 *   query?: Record<string, string | undefined>,
 *   body?: Record<string, unknown>,
 *   nonce?: string,
 *   asyncMode?: string
 * }} request Configuração da chamada atual.
 * @returns {Promise<{
 *   ok: boolean,
 *   status: number,
 *   nonce: string,
 *   asyncMode: "auto" | "true" | "false",
 *   headers: Record<string, string>,
 *   data: unknown
 * }>} Resposta normalizada da integração.
 */
export async function requestEulenApi(env, request) {
  const token = assertEulenApiToken(env);
  const { headers, nonce, asyncMode } = buildEulenRequestHeaders({
    token,
    nonce: request.nonce,
    asyncMode: request.asyncMode,
    contentType: request.body ? "application/json" : undefined,
  });
  const url = buildEulenUrl(String(env.EULEN_API_BASE_URL), request.path, request.query);
  const timeoutMs = Number.parseInt(String(env.EULEN_API_TIMEOUT_MS), 10);
  const { controller, cleanup } = createTimeoutController(timeoutMs);

  try {
    const response = await fetch(url, {
      method: request.method ?? "GET",
      headers,
      body: request.body ? JSON.stringify(request.body) : undefined,
      signal: controller.signal,
    });
    const data = await parseEulenResponseBody(response);

    if (!response.ok) {
      throw new EulenApiError("Eulen API request failed.", {
        status: response.status,
        nonce,
        path: request.path,
        data,
      });
    }

    return {
      ok: response.ok,
      status: response.status,
      nonce,
      asyncMode,
      headers: Object.fromEntries(response.headers.entries()),
      data,
    };
  } catch (error) {
    if (error instanceof EulenApiError) {
      throw error;
    }

    if (error instanceof Error && error.name === "AbortError") {
      throw new EulenApiError("Eulen API request timed out.", {
        nonce,
        path: request.path,
        timeoutMs,
      });
    }

    throw new EulenApiError("Unexpected Eulen API error.", {
      nonce,
      path: request.path,
      cause: error instanceof Error ? error.message : String(error),
    });
  } finally {
    cleanup();
  }
}

/**
 * Executa o ping da Eulen para validar credencial e conectividade básica.
 *
 * @param {Record<string, unknown>} env Bindings recebidos pelo Worker.
 * @param {{ nonce?: string, asyncMode?: string }=} options Opções da chamada atual.
 * @returns {Promise<ReturnType<typeof requestEulenApi>>} Resposta normalizada do ping.
 */
export function pingEulen(env, options = {}) {
  return requestEulenApi(env, {
    path: "/ping",
    method: "GET",
    nonce: options.nonce,
    asyncMode: options.asyncMode,
  });
}

/**
 * Cria uma cobrança Pix ➔ DePix usando o contrato da Eulen.
 *
 * @param {Record<string, unknown>} env Bindings recebidos pelo Worker.
 * @param {{ body: Record<string, unknown>, nonce?: string, asyncMode?: string }} options Opções da chamada atual.
 * @returns {Promise<ReturnType<typeof requestEulenApi>>} Resposta normalizada do depósito.
 */
export function createEulenDeposit(env, options) {
  return requestEulenApi(env, {
    path: "/deposit",
    method: "POST",
    body: options.body,
    nonce: options.nonce,
    asyncMode: options.asyncMode,
  });
}

/**
 * Consulta o status de um depósito específico na Eulen.
 *
 * @param {Record<string, unknown>} env Bindings recebidos pelo Worker.
 * @param {{ id: string, nonce?: string, asyncMode?: string }} options Opções da chamada atual.
 * @returns {Promise<ReturnType<typeof requestEulenApi>>} Resposta normalizada do status do depósito.
 */
export function getEulenDepositStatus(env, options) {
  return requestEulenApi(env, {
    path: "/deposit-status",
    method: "GET",
    query: {
      id: options.id,
    },
    nonce: options.nonce,
    asyncMode: options.asyncMode,
  });
}

/**
 * Lista depósitos em uma janela de tempo para reconciliar divergências.
 *
 * @param {Record<string, unknown>} env Bindings recebidos pelo Worker.
 * @param {{ start: string, end: string, status?: string, nonce?: string, asyncMode?: string }} options Opções da chamada atual.
 * @returns {Promise<ReturnType<typeof requestEulenApi>>} Resposta normalizada da listagem de depósitos.
 */
export function listEulenDeposits(env, options) {
  return requestEulenApi(env, {
    path: "/deposits",
    method: "GET",
    query: {
      start: options.start,
      end: options.end,
      status: options.status,
    },
    nonce: options.nonce,
    asyncMode: options.asyncMode,
  });
}

````
