# codigo/src/clients

[Voltar para a pasta anterior](../INDEX.md)

## Arquivos

- [eulen-client.js.md](eulen-client.js.md)

Exportado automaticamente em 15/04/2026, 22:17:46.

Raiz original do repositório: `C:/Users/poske/Desktop/DePix MVP`
