# deposits-repository.js

Origem no repositório: `src/db/repositories/deposits-repository.js`

````javascript
/**
 * Repositório de cobranças Pix/DePix.
 *
 * Este arquivo centraliza operações de `deposits`, preservando rastreabilidade
 * por `depositId`, `orderId` e `nonce` desde o começo do projeto.
 */
import { getAllowedPatchEntries } from "../client.js";

const DEPOSIT_SELECT_SQL = `
  SELECT
    deposit_id AS depositId,
    order_id AS orderId,
    nonce AS nonce,
    qr_copy_paste AS qrCopyPaste,
    qr_image_url AS qrImageUrl,
    external_status AS externalStatus,
    expiration AS expiration,
    created_at AS createdAt,
    updated_at AS updatedAt
  FROM deposits
`;

const INSERT_DEPOSIT_SQL = `
  INSERT INTO deposits (
    deposit_id,
    order_id,
    nonce,
    qr_copy_paste,
    qr_image_url,
    external_status,
    expiration
  ) VALUES (?, ?, ?, ?, ?, ?, ?)
`;

const DEPOSIT_UPDATE_COLUMNS = {
  orderId: "order_id",
  nonce: "nonce",
  qrCopyPaste: "qr_copy_paste",
  qrImageUrl: "qr_image_url",
  externalStatus: "external_status",
  expiration: "expiration",
  updatedAt: "updated_at",
};

function normalizeDepositInput(input) {
  return {
    depositId: input.depositId,
    orderId: input.orderId,
    nonce: input.nonce,
    qrCopyPaste: input.qrCopyPaste,
    qrImageUrl: input.qrImageUrl,
    externalStatus: input.externalStatus ?? "pending",
    expiration: input.expiration ?? null,
  };
}

/**
 * Cria uma cobrança no banco e devolve o registro persistido.
 *
 * @param {D1Database} db Binding D1 nativo do Worker.
 * @param {Record<string, unknown>} input Dados da cobrança a persistir.
 * @returns {Promise<Record<string, unknown> | undefined>} Cobrança recém-persistida.
 */
export async function createDeposit(db, input) {
  const deposit = normalizeDepositInput(input);
  const insertStatement = db.prepare(INSERT_DEPOSIT_SQL).bind(
    deposit.depositId,
    deposit.orderId,
    deposit.nonce,
    deposit.qrCopyPaste,
    deposit.qrImageUrl,
    deposit.externalStatus,
    deposit.expiration,
  );
  const selectStatement = db.prepare(`${DEPOSIT_SELECT_SQL} WHERE deposit_id = ? LIMIT 1`).bind(deposit.depositId);
  const [, selectResult] = await db.batch([insertStatement, selectStatement]);

  return selectResult.results[0];
}

/**
 * Busca uma cobrança pelo seu identificador externo.
 *
 * @param {D1Database} db Binding D1 nativo do Worker.
 * @param {string} depositId Identificador da cobrança.
 * @returns {Promise<Record<string, unknown> | undefined>} Cobrança encontrada, se existir.
 */
export async function getDepositById(db, depositId) {
  return db.prepare(`${DEPOSIT_SELECT_SQL} WHERE deposit_id = ? LIMIT 1`).bind(depositId).first();
}

/**
 * Atualiza parcialmente uma cobrança e devolve o estado mais recente.
 *
 * @param {D1Database} db Binding D1 nativo do Worker.
 * @param {string} depositId Identificador da cobrança.
 * @param {Record<string, unknown>} patch Campos a atualizar.
 * @returns {Promise<Record<string, unknown> | undefined>} Cobrança atualizada.
 */
export async function updateDepositById(db, depositId, patch) {
  const patchEntries = getAllowedPatchEntries(
    {
      ...patch,
      updatedAt: new Date().toISOString(),
    },
    DEPOSIT_UPDATE_COLUMNS,
  );

  if (patchEntries.length === 0) {
    return getDepositById(db, depositId);
  }

  const setClause = patchEntries.map(([column]) => `${column} = ?`).join(", ");
  const values = patchEntries.map(([, value]) => value);
  const updateStatement = db.prepare(`UPDATE deposits SET ${setClause} WHERE deposit_id = ?`).bind(...values, depositId);
  const selectStatement = db.prepare(`${DEPOSIT_SELECT_SQL} WHERE deposit_id = ? LIMIT 1`).bind(depositId);
  const [, selectResult] = await db.batch([updateStatement, selectStatement]);

  return selectResult.results[0];
}

````
