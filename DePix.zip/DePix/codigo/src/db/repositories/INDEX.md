# codigo/src/db/repositories

[Voltar para a pasta anterior](../INDEX.md)

## Arquivos

- [deposit-events-repository.js.md](deposit-events-repository.js.md)
- [deposits-repository.js.md](deposits-repository.js.md)
- [orders-repository.js.md](orders-repository.js.md)

Exportado automaticamente em 15/04/2026, 22:17:46.

Raiz original do repositório: `C:/Users/poske/Desktop/DePix MVP`
