# orders-repository.js

Origem no repositório: `src/db/repositories/orders-repository.js`

````javascript
/**
 * Repositório de pedidos.
 *
 * Este arquivo centraliza as operações básicas de `orders`, evitando que a
 * regra de acesso ao banco fique espalhada pelas rotas e serviços do MVP.
 */
import { getAllowedPatchEntries } from "../client.js";

const ORDER_SELECT_SQL = `
  SELECT
    order_id AS orderId,
    user_id AS userId,
    channel AS channel,
    product_type AS productType,
    amount_in_cents AS amountInCents,
    wallet_address AS walletAddress,
    current_step AS currentStep,
    status AS status,
    split_address AS splitAddress,
    split_fee AS splitFee,
    created_at AS createdAt,
    updated_at AS updatedAt
  FROM orders
`;

const INSERT_ORDER_SQL = `
  INSERT INTO orders (
    order_id,
    user_id,
    channel,
    product_type,
    amount_in_cents,
    wallet_address,
    current_step,
    status,
    split_address,
    split_fee
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`;

const ORDER_UPDATE_COLUMNS = {
  userId: "user_id",
  channel: "channel",
  productType: "product_type",
  amountInCents: "amount_in_cents",
  walletAddress: "wallet_address",
  currentStep: "current_step",
  status: "status",
  splitAddress: "split_address",
  splitFee: "split_fee",
  updatedAt: "updated_at",
};

function normalizeOrderInput(input) {
  return {
    orderId: input.orderId,
    userId: input.userId,
    channel: input.channel ?? "telegram",
    productType: input.productType,
    amountInCents: input.amountInCents ?? null,
    walletAddress: input.walletAddress ?? null,
    currentStep: input.currentStep ?? "draft",
    status: input.status ?? "draft",
    splitAddress: input.splitAddress ?? null,
    splitFee: input.splitFee ?? null,
  };
}

/**
 * Cria um pedido novo no banco e devolve o registro persistido.
 *
 * @param {D1Database} db Binding D1 nativo do Worker.
 * @param {Record<string, unknown>} input Dados do pedido a persistir.
 * @returns {Promise<Record<string, unknown> | undefined>} Pedido recém-persistido.
 */
export async function createOrder(db, input) {
  const order = normalizeOrderInput(input);
  const insertStatement = db.prepare(INSERT_ORDER_SQL).bind(
    order.orderId,
    order.userId,
    order.channel,
    order.productType,
    order.amountInCents,
    order.walletAddress,
    order.currentStep,
    order.status,
    order.splitAddress,
    order.splitFee,
  );
  const selectStatement = db.prepare(`${ORDER_SELECT_SQL} WHERE order_id = ? LIMIT 1`).bind(order.orderId);
  const [, selectResult] = await db.batch([insertStatement, selectStatement]);

  return selectResult.results[0];
}

/**
 * Busca um pedido pelo seu identificador interno.
 *
 * @param {D1Database} db Binding D1 nativo do Worker.
 * @param {string} orderId Identificador do pedido.
 * @returns {Promise<Record<string, unknown> | undefined>} Pedido encontrado, se existir.
 */
export async function getOrderById(db, orderId) {
  return db.prepare(`${ORDER_SELECT_SQL} WHERE order_id = ? LIMIT 1`).bind(orderId).first();
}

/**
 * Atualiza parcialmente um pedido e devolve o estado mais recente.
 *
 * @param {D1Database} db Binding D1 nativo do Worker.
 * @param {string} orderId Identificador do pedido.
 * @param {Record<string, unknown>} patch Campos que precisam ser atualizados.
 * @returns {Promise<Record<string, unknown> | undefined>} Pedido atualizado.
 */
export async function updateOrderById(db, orderId, patch) {
  const patchEntries = getAllowedPatchEntries(
    {
      ...patch,
      updatedAt: new Date().toISOString(),
    },
    ORDER_UPDATE_COLUMNS,
  );

  if (patchEntries.length === 0) {
    return getOrderById(db, orderId);
  }

  const setClause = patchEntries.map(([column]) => `${column} = ?`).join(", ");
  const values = patchEntries.map(([, value]) => value);
  const updateStatement = db.prepare(`UPDATE orders SET ${setClause} WHERE order_id = ?`).bind(...values, orderId);
  const selectStatement = db.prepare(`${ORDER_SELECT_SQL} WHERE order_id = ? LIMIT 1`).bind(orderId);
  const [, selectResult] = await db.batch([updateStatement, selectStatement]);

  return selectResult.results[0];
}

````
