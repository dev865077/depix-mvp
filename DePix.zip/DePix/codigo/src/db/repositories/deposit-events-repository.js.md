# deposit-events-repository.js

Origem no repositório: `src/db/repositories/deposit-events-repository.js`

````javascript
/**
 * Repositório de histórico de eventos externos.
 *
 * Este arquivo concentra a persistência de `deposit_events`, que será usada
 * pelos webhooks e pelo fluxo de recheck para auditoria e reconciliação.
 */
const DEPOSIT_EVENT_SELECT_SQL = `
  SELECT
    id AS id,
    order_id AS orderId,
    deposit_id AS depositId,
    source AS source,
    external_status AS externalStatus,
    bank_tx_id AS bankTxId,
    blockchain_tx_id AS blockchainTxId,
    raw_payload AS rawPayload,
    received_at AS receivedAt
  FROM deposit_events
`;

const INSERT_DEPOSIT_EVENT_SQL = `
  INSERT INTO deposit_events (
    order_id,
    deposit_id,
    source,
    external_status,
    bank_tx_id,
    blockchain_tx_id,
    raw_payload
  ) VALUES (?, ?, ?, ?, ?, ?, ?)
  RETURNING
    id AS id,
    order_id AS orderId,
    deposit_id AS depositId,
    source AS source,
    external_status AS externalStatus,
    bank_tx_id AS bankTxId,
    blockchain_tx_id AS blockchainTxId,
    raw_payload AS rawPayload,
    received_at AS receivedAt
`;

/**
 * Registra um novo evento externo no histórico e devolve o registro salvo.
 *
 * @param {D1Database} db Binding D1 nativo do Worker.
 * @param {Record<string, unknown>} input Evento externo a persistir.
 * @returns {Promise<Record<string, unknown> | undefined>} Evento recém-persistido.
 */
export async function createDepositEvent(db, input) {
  return db.prepare(INSERT_DEPOSIT_EVENT_SQL).bind(
    input.orderId,
    input.depositId,
    input.source,
    input.externalStatus,
    input.bankTxId ?? null,
    input.blockchainTxId ?? null,
    input.rawPayload,
  ).first();
}

/**
 * Busca um evento pelo identificador interno autoincremental.
 *
 * @param {D1Database} db Binding D1 nativo do Worker.
 * @param {number | undefined} id Identificador interno do evento.
 * @returns {Promise<Record<string, unknown> | undefined>} Evento encontrado, se existir.
 */
export async function getDepositEventById(db, id) {
  if (typeof id !== "number") {
    return undefined;
  }

  return db.prepare(`${DEPOSIT_EVENT_SELECT_SQL} WHERE id = ? LIMIT 1`).bind(id).first();
}

/**
 * Lista os eventos mais recentes de um depósito específico.
 *
 * @param {D1Database} db Binding D1 nativo do Worker.
 * @param {string} depositId Identificador da cobrança.
 * @returns {Promise<Array<Record<string, unknown>>>} Eventos ordenados do mais novo para o mais antigo.
 */
export async function listDepositEventsByDepositId(db, depositId) {
  const result = await db.prepare(`${DEPOSIT_EVENT_SELECT_SQL} WHERE deposit_id = ? ORDER BY id DESC`).bind(depositId).all();

  return result.results;
}

````
