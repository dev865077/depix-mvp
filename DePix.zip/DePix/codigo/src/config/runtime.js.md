# runtime.js

Origem no repositório: `src/config/runtime.js`

````javascript
/**
 * Leitura e saneamento da configuração de runtime do Worker.
 *
 * Este módulo concentra as regras de ambiente do projeto. Ele valida bindings
 * obrigatórios, diferencia local/test/production e devolve apenas um resumo
 * seguro dos segredos configurados, sem nunca expor valores sensíveis.
 */

const APP_ENVIRONMENTS = new Set(["local", "test", "production"]);
const LOG_LEVELS = new Set(["debug", "info", "warn", "error"]);

/**
 * Garante que um binding obrigatório exista antes de a aplicação continuar.
 *
 * @param {string | undefined} value Valor bruto recebido do ambiente.
 * @param {string} key Nome do binding para gerar erro útil.
 * @returns {string} Valor validado e pronto para uso.
 */
export function assertRequiredString(value, key) {
  if (!value || value.trim().length === 0) {
    throw new Error(`Missing required binding: ${key}`);
  }

  return value;
}

/**
 * Converte um binding textual em inteiro positivo para configuração operacional.
 *
 * @param {string | undefined} value Valor bruto recebido do ambiente.
 * @param {string} key Nome do binding para gerar erro útil.
 * @returns {number} Número inteiro positivo validado.
 */
export function assertPositiveInteger(value, key) {
  const parsedValue = Number.parseInt(assertRequiredString(value, key), 10);

  if (!Number.isInteger(parsedValue) || parsedValue <= 0) {
    throw new Error(`Invalid positive integer binding: ${key}`);
  }

  return parsedValue;
}

/**
 * Lê os bindings do Worker e transforma isso em uma configuração segura.
 *
 * @param {Record<string, string | undefined>} env Bindings recebidos do Cloudflare Worker.
 * @returns {{
 *   appName: string,
 *   environment: "local" | "test" | "production",
 *   logLevel: "debug" | "info" | "warn" | "error",
 *   eulenApiBaseUrl: string,
 *   eulenApiTimeoutMs: number,
 *   database: {
 *     bindingConfigured: boolean
 *   },
 *   secrets: {
 *     telegramBotTokenConfigured: boolean,
 *     telegramWebhookSecretConfigured: boolean,
 *     eulenApiTokenConfigured: boolean,
 *     eulenWebhookSecretConfigured: boolean
 *   }
 * }}
 */
export function readRuntimeConfig(env) {
  const appName = assertRequiredString(env.APP_NAME, "APP_NAME");
  const rawEnvironment = assertRequiredString(env.APP_ENV, "APP_ENV");
  const rawLogLevel = assertRequiredString(env.LOG_LEVEL, "LOG_LEVEL");
  const eulenApiBaseUrl = assertRequiredString(env.EULEN_API_BASE_URL, "EULEN_API_BASE_URL");
  const eulenApiTimeoutMs = assertPositiveInteger(env.EULEN_API_TIMEOUT_MS, "EULEN_API_TIMEOUT_MS");

  if (!APP_ENVIRONMENTS.has(rawEnvironment)) {
    throw new Error(`Invalid APP_ENV value: ${rawEnvironment}`);
  }

  if (!LOG_LEVELS.has(rawLogLevel)) {
    throw new Error(`Invalid LOG_LEVEL value: ${rawLogLevel}`);
  }

  return {
    appName,
    environment: rawEnvironment,
    logLevel: rawLogLevel,
    eulenApiBaseUrl,
    eulenApiTimeoutMs,
    database: {
      bindingConfigured: Boolean(env.DB),
    },
    secrets: {
      telegramBotTokenConfigured: Boolean(env.TELEGRAM_BOT_TOKEN),
      telegramWebhookSecretConfigured: Boolean(env.TELEGRAM_WEBHOOK_SECRET),
      eulenApiTokenConfigured: Boolean(env.EULEN_API_TOKEN),
      eulenWebhookSecretConfigured: Boolean(env.EULEN_WEBHOOK_SECRET),
    },
  };
}

````
