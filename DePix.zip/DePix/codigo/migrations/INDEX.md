# codigo/migrations

[Voltar para a pasta anterior](../INDEX.md)

## Arquivos

- [0000_initial_schema.sql.md](0000_initial_schema.sql.md)

Exportado automaticamente em 15/04/2026, 22:17:46.

Raiz original do repositório: `C:/Users/poske/Desktop/DePix MVP`
