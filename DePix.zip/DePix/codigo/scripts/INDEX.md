# codigo/scripts

[Voltar para a pasta anterior](../INDEX.md)

## Arquivos

- [exportar-repositorio-para-obsidian-md.js.md](exportar-repositorio-para-obsidian-md.js.md)

Exportado automaticamente em 15/04/2026, 22:17:46.

Raiz original do repositório: `C:/Users/poske/Desktop/DePix MVP`
