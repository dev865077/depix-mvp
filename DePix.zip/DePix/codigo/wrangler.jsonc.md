# wrangler.jsonc

Origem no repositório: `wrangler.jsonc`

````json
// Configuração principal do Cloudflare Worker.
// O arquivo diferencia local, teste e produção sem colocar segredos em código.
{
  "$schema": "./node_modules/wrangler/config-schema.json",
  "name": "depix-mvp",
  "main": "src/index.js",
  "compatibility_date": "2026-04-13",
  "observability": {
    "enabled": true
  },
  "d1_databases": [
    {
      "binding": "DB",
      "database_name": "depix-mvp-local",
      "migrations_dir": "migrations"
    }
  ],
  "vars": {
    "APP_NAME": "depix-mvp",
    "APP_ENV": "local",
    "LOG_LEVEL": "debug",
    "EULEN_API_BASE_URL": "https://depix.eulen.app/api",
    "EULEN_API_TIMEOUT_MS": "10000"
  },
  "env": {
    "test": {
      "d1_databases": [
        {
          "binding": "DB",
          "database_name": "depix-mvp-test",
          "migrations_dir": "migrations"
        }
      ],
      "vars": {
        "APP_NAME": "depix-mvp",
        "APP_ENV": "test",
        "LOG_LEVEL": "info",
        "EULEN_API_BASE_URL": "https://depix.eulen.app/api",
        "EULEN_API_TIMEOUT_MS": "10000"
      }
    },
    "production": {
      "d1_databases": [
        {
          "binding": "DB",
          "database_name": "depix-mvp-production",
          "database_id": "e4a13633-8e26-4c1a-aa9e-db8e35360cb4",
          "migrations_dir": "migrations"
        }
      ],
      "vars": {
        "APP_NAME": "depix-mvp",
        "APP_ENV": "production",
        "LOG_LEVEL": "info",
        "EULEN_API_BASE_URL": "https://depix.eulen.app/api",
        "EULEN_API_TIMEOUT_MS": "10000"
      }
    }
  }
}

````
