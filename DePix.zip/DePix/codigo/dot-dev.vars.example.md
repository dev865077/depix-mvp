# .dev.vars.example

Origem no repositório: `.dev.vars.example`

````text
# Exemplo de variáveis locais para desenvolvimento.
# Este arquivo documenta o formato esperado, mas nunca deve guardar segredos reais.
APP_ENV=local
APP_NAME=depix-mvp
LOG_LEVEL=debug
EULEN_API_BASE_URL=https://depix.eulen.app/api
EULEN_API_TIMEOUT_MS=10000
TELEGRAM_BOT_TOKEN=replace-with-telegram-bot-token
TELEGRAM_WEBHOOK_SECRET=replace-with-telegram-webhook-secret
EULEN_API_TOKEN=replace-with-eulen-api-token
EULEN_WEBHOOK_SECRET=replace-with-eulen-webhook-secret

````
