# health.test.js

Origem no repositório: `test/health.test.js`

````javascript
/**
 * Smoke test do healthcheck do Worker.
 *
 * Este teste valida a base mais importante do BG-01 dentro do runtime de
 * Cloudflare Workers: o Worker sobe, o entrypoint responde via Hono e o
 * endpoint de health expõe um resumo seguro do ambiente.
 */
import { SELF } from "cloudflare:test";
import { describe, expect, it } from "vitest";

/**
 * Consulta o endpoint de health do Worker em execução dentro do runtime de teste.
 *
 * @returns {Promise<{ response: Response, body: any }>} Resposta HTTP e corpo JSON já parseado.
 */
export async function fetchHealthResponse() {
  const response = await SELF.fetch("https://example.com/health");
  const body = await response.json();

  return { response, body };
}

/**
 * Executa as asserções principais do smoke test do healthcheck.
 *
 * @returns {Promise<void>} Promessa resolvida quando todas as asserções passam.
 */
export async function assertHealthResponse() {
  const { response, body } = await fetchHealthResponse();

  expect(response.status).toBe(200);
  expect(body.status).toBe("ok");
  expect(body.environment).toBe("local");
  expect(body.configuration.database.bindingConfigured).toBe(true);
  expect(body.configuration.secrets.telegramBotTokenConfigured).toBe(false);
}

describe("health route", () => {
  it("returns the runtime status", assertHealthResponse);
});

````
