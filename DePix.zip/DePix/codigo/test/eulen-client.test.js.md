# eulen-client.test.js

Origem no repositório: `test/eulen-client.test.js`

````javascript
/**
 * Testes controlados do client Eulen.
 *
 * Este arquivo valida a construção de headers obrigatórios, a chamada de ping e
 * o tratamento base de autenticação, nonce e async mode sem depender da API
 * externa real.
 */
import { afterEach, describe, expect, it, vi } from "vitest";

import {
  buildEulenRequestHeaders,
  EulenApiError,
  normalizeAsyncMode,
  pingEulen,
  requestEulenApi,
} from "../src/clients/eulen-client.js";

const EULEN_ENV = {
  EULEN_API_BASE_URL: "https://depix.eulen.app/api",
  EULEN_API_TIMEOUT_MS: "10000",
  EULEN_API_TOKEN: "token_test_123",
};

/**
 * Restaura mocks globais do fetch após cada teste do client.
 */
afterEach(function restoreFetchMock() {
  vi.restoreAllMocks();
});

/**
 * Valida os headers obrigatórios exigidos pela Eulen.
 */
export function assertRequiredHeaders() {
  const { headers, nonce, asyncMode } = buildEulenRequestHeaders({
    token: "token_test_123",
    nonce: "nonce_test_123",
    asyncMode: "auto",
  });

  expect(headers.get("Authorization")).toBe("Bearer token_test_123");
  expect(headers.get("X-Nonce")).toBe("nonce_test_123");
  expect(headers.get("X-Async")).toBe("auto");
  expect(nonce).toBe("nonce_test_123");
  expect(asyncMode).toBe("auto");
}

/**
 * Valida que o ping monta corretamente a chamada base para a Eulen.
 *
 * @returns {Promise<void>} Promessa resolvida quando todas as asserções passam.
 */
export async function assertPingRequest() {
  const fetchSpy = vi.spyOn(globalThis, "fetch").mockResolvedValue(
    new Response(JSON.stringify({ response: { msg: "Pong!" }, async: false }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
      },
    }),
  );

  const response = await pingEulen(EULEN_ENV, {
    nonce: "nonce_ping_001",
    asyncMode: "auto",
  });

  expect(fetchSpy).toHaveBeenCalledTimes(1);
  expect(fetchSpy.mock.calls[0][0]).toBe("https://depix.eulen.app/api/ping");
  expect(fetchSpy.mock.calls[0][1]?.method).toBe("GET");
  expect(fetchSpy.mock.calls[0][1]?.headers.get("Authorization")).toBe("Bearer token_test_123");
  expect(fetchSpy.mock.calls[0][1]?.headers.get("X-Nonce")).toBe("nonce_ping_001");
  expect(fetchSpy.mock.calls[0][1]?.headers.get("X-Async")).toBe("auto");
  expect(response.status).toBe(200);
  expect(response.nonce).toBe("nonce_ping_001");
}

/**
 * Valida que o client padroniza falhas HTTP da Eulen.
 *
 * @returns {Promise<void>} Promessa resolvida quando a asserção do erro passa.
 */
export async function assertHttpErrorHandling() {
  vi.spyOn(globalThis, "fetch").mockResolvedValue(
    new Response(JSON.stringify({ response: { errorMessage: "Unauthorized" }, async: false }), {
      status: 401,
      headers: {
        "Content-Type": "application/json",
      },
    }),
  );

  await expect(
    requestEulenApi(EULEN_ENV, {
      path: "/ping",
      method: "GET",
      nonce: "nonce_error_001",
      asyncMode: "auto",
    }),
  ).rejects.toBeInstanceOf(EulenApiError);
}

describe("eulen client", () => {
  it("builds the required auth, nonce and async headers", assertRequiredHeaders);
  it("executes ping with the expected request shape", assertPingRequest);
  it("throws a standardized error on non-2xx responses", assertHttpErrorHandling);
  it("accepts only supported async modes", function assertAsyncModes() {
    expect(normalizeAsyncMode(undefined)).toBe("auto");
    expect(normalizeAsyncMode("true")).toBe("true");
    expect(normalizeAsyncMode("false")).toBe("false");
    expect(normalizeAsyncMode("auto")).toBe("auto");
  });
});

````
