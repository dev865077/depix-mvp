# codigo/test

[Voltar para a pasta anterior](../INDEX.md)

## Arquivos

- [db.repositories.test.js.md](db.repositories.test.js.md)
- [eulen-client.test.js.md](eulen-client.test.js.md)
- [health.test.js.md](health.test.js.md)

Exportado automaticamente em 15/04/2026, 22:17:46.

Raiz original do repositório: `C:/Users/poske/Desktop/DePix MVP`
