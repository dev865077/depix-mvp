# package.json

Origem no repositório: `package.json`

````json
{
  "name": "depix-mvp",
  "version": "1.0.0",
  "description": "MVP base do bot DePix rodando em Cloudflare Workers com Hono.",
  "private": true,
  "type": "module",
  "main": "src/index.js",
  "scripts": {
    "dev": "wrangler dev",
    "test": "vitest --run",
    "obsidian:export": "node scripts/exportar-repositorio-para-obsidian-md.js",
    "cf:types": "wrangler types",
    "db:migrate:local": "wrangler d1 migrations apply DB --local",
    "db:query:local": "wrangler d1 execute DB --local",
    "deploy:test": "wrangler deploy --env test",
    "deploy:production": "wrangler deploy --env production"
  },
  "keywords": [],
  "author": "",
  "license": "ISC",
  "dependencies": {
    "hono": "4.12.12"
  },
  "devDependencies": {
    "@cloudflare/vitest-pool-workers": "0.14.6",
    "vitest": "4.1.4",
    "wrangler": "4.82.2"
  }
}

````
