- ligado a [[Misc/DePix/Contexto|Contexto]]
- ligado a [[Misc/DePix/Faturamento Automações|Faturamento Automações]]
- ligado a [[Misc/DePix/Arquitetura Tecnica do MVP|Arquitetura Tecnica do MVP]]

## Ideia

Usar o mesmo motor do bot `DePix` para vender:

- curso
- mentoria
- conteudo fechado
- acesso a canal privado
- arquivos e mensagens premium

A tese e simples:

- cobranca Pix continua quase igual
- webhook e reconciliacao continuam quase iguais
- a maior variacao esta na entrega final

Em vez de entregar `DePix`, o sistema pode entregar link, arquivo, convite ou liberacao manual.

## O que reaproveita quase inteiro

- `Cloudflare Worker`, `Hono`, `grammY`, `D1`, `SQL cru`
- `env.DB.batch()` nos fluxos criticos
- `orders`, `deposits`, `deposit_events`
- `nonce`, `depositEntryId`, webhook, recheck e logs
- maquina de estados do pedido
- client da Eulen

Fluxo tecnico:

1. usuario entra no bot
2. escolhe o item
3. sistema cria pedido
4. sistema gera cobranca Pix
5. webhook confirma pagamento
6. sistema executa o fulfillment

## O que muda de verdade

O pagamento muda pouco. O que muda e a camada de fulfillment.

Campos minimos novos:

- `productType`
- `productId`
- `fulfillmentType`
- `fulfillmentStatus`

No banco, o nucleo continua o mesmo:

- `orders`
- `deposits`
- `deposit_events`

Produtos digitais entram como extensao pequena, sem mudar o trilho de cobranca.

Estrutura de codigo mais barata:

- `payment core`
- `conversation layer`
- `fulfillment adapters`

O `payment core` fica quase igual. O `conversation layer` so passa a perguntar qual item o usuario quer. O ponto real de variacao vira o adapter final:

- enviar arquivo
- liberar link
- adicionar em canal
- marcar mentoria como paga
- notificar operador

## Menor esforco

O caminho mais barato parece ser:

1. manter o mesmo `Worker`
2. manter o mesmo `D1`
3. manter o mesmo trilho de pagamento
4. adicionar tipos de produto
5. adicionar tipos de fulfillment

Se a comunicacao ficar confusa, o bot pode ser separado sem mudar quase nada na base tecnica.

Isso preserva:

- a mesma infra
- o mesmo fluxo de pagamento
- a mesma reconciliacao
- o mesmo modelo operacional

## Onde isso vira produto

Isso parece especialmente bom para:

- creators pequenos
- influenciadores
- grupos fechados
- vendas rapidas de acesso
- produtos digitais simples

Exemplos de entrega final:

- link privado
- arquivo premium
- convite para canal
- mensagem liberando acesso
- liberacao manual assistida

Tudo isso continua em cima do mesmo pedido e da mesma confirmacao de pagamento.

O limite principal nao e tecnico. E comercial e operacional:

- UX
- suporte
- controle de acesso
- clareza entre produto financeiro e produto digital

## Conclusao

Vender conteudo digital via Pix no Telegram parece uma extensao natural do que ja esta sendo construido.

Nao parece nova arquitetura. Parece uma nova camada de produto em cima do mesmo motor de:

- pedido
- cobranca
- confirmacao
- reconciliacao
- entrega
