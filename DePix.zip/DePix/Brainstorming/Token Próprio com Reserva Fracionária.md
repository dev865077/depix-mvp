- ligado a [[Misc/DePix/Brainstorming/Pool Interna de DePix|Pool Interna de DePix]]
- ligado a [[Misc/DePix/Contexto|Contexto]]

## Ideia

Criar um produto fechado em que o usuario nao use `DePix` diretamente na maior parte do tempo.

O usuario veria e moveria apenas:

- saldo interno
- token interno
- ou recibos de `Chaumian e-cash`

O `DePix` ficaria no backend como reserva e trilho de liquidacao. Blockchain entraria so em deposito, saque, rebalance e liquidacao externa.

## Como funcionaria

Entrada:

1. o usuario deposita
2. o sistema recebe valor externo
3. o sistema credita saldo interno
4. a reserva em `DePix` e ajustada

Movimentacao interna:

1. usuario transfere saldo
2. o ledger interno atualiza saldos
3. nao ha transacao on-chain

Saida:

1. usuario pede saque
2. o sistema verifica saldo e liquidez
3. liquida usando `DePix` e blockchain
4. baixa o saldo interno

## Diferenca para a pool interna

| Modelo | O usuario segura | O sistema segura | Blockchain |
|---|---|---|---|
| Pool interna | `DePix` real | estoque de `DePix` | entra com frequencia moderada |
| Token proprio | saldo interno / token interno | reserva em `DePix` | entra so em borda |

Na pool interna, o usuario ainda lida com o ativo real. No token proprio, ele passa a lidar com um passivo do sistema.

## Vantagens

- menos chamadas para a `Eulen`
- menos movimentacao on-chain
- menor custo marginal
- mais eficiencia de capital
- UX mais rapida
- mais controle sobre ledger, liquidez e saque

Com reserva fracionaria, o sistema nao precisa manter `100%` do passivo em `DePix`. Isso aumenta eficiencia e margem potencial.

## Riscos

- o produto vira conta fechada / emissor de saldo interno
- o risco de liquidez sobe muito
- o risco de confianca sobe muito
- erro de ledger, custodia ou saque vira risco sistemico

Tabela mental simples:

| Passivo com usuarios | Reserva em `DePix` | Cobertura |
|---|---:|---:|
| 100 | 100 | 100% |
| 100 | 70 | 70% |
| 100 | 50 | 50% |
| 100 | 30 | 30% |

Quanto menor a cobertura, maior a eficiencia e maior o risco de corrida de saque.

## Quando faz sentido

Faz sentido se houver:

- app proprio
- usuarios mantendo saldo interno
- bastante transferencia interna
- saque relativamente baixo em relacao ao saldo total
- capacidade real de operar ledger e liquidez

Nao faz sentido se o produto continuar sendo compra, recebimento rapido do ativo real e saque frequente.

## Papel do `Chaumian e-cash`

Nao e o centro da ideia. E so uma camada opcional para:

- melhorar privacidade interna
- melhorar UX
- permitir movimentacao mais leve entre usuarios

O centro continua sendo ledger centralizado, reserva em `DePix` e politica de liquidez.

## Conclusao

Essa ideia faz sentido para um produto fechado, centralizado, com saldo interno e pouca dependencia de blockchain no dia a dia.

Ela e bem mais agressiva do que usar a `Eulen` direto ou operar apenas pool interna de `DePix`.

O ganho potencial e grande. O risco tambem.
