# Pool Interna de DePix

Documento de brainstorming conectado a:

- [[Misc/DePix/Contexto|Contexto]]
- [[Misc/DePix/Faturamento Automações|Faturamento Automações]]
- [[Misc/DePix/Docs/Pix2DePix API - Documentacao Completa|Pix2DePix API - Documentacao Completa]]

## Objetivo

Discutir se, no futuro, vale a pena operar com pool interna de `DePix` em vez de depender da `Eulen` em toda compra e venda.

## Logica da pool propria

Sem pool interna:

- compra do cliente usa `Eulen`
- venda do cliente usa `Eulen`
- a taxa externa incide no volume bruto

Com pool interna:

- o sistema mantem saldo proprio de `DePix`
- compras e vendas podem se compensar internamente
- a `Eulen` entra so no rebalance

Ganho real:

- sem pool: custo sobre o bruto
- com pool: custo sobre o liquido

## Premissas usadas

Fonte publica:

- [FAQ Depix.Online](https://depix.online/faq)

Cenario-base:

- `100` ordens por mes
- ticket medio de `R$ 1.000`
- volume bruto total de `R$ 100.000`
- sem pool: compra de `R$ 1.000` paga `3% + R$ 0,99` e venda de `R$ 1.000` paga `5%`
- com pool: rebalance em blocos de `R$ 5.000`, compra a `1,5% + R$ 0,99` e venda a `3%`

Os calculos abaixo comparam so custo `Eulen`. Nao incluem fee de rede, custodia, spread, capital parado ou risco.

## Formula simples

```text
custo sem pool = custo sobre todas as compras + custo sobre todas as vendas
custo com pool = custo apenas sobre o volume liquido rebalanceado
```

## Cenarios comparativos

| Cenario | Mix do mes | Custo sem pool | Custo com pool | Reducao |
|---|---|---:|---:|---:|
| `1` | `100` compras, `0` vendas | `R$ 3.099,00` | `R$ 1.519,80` | `50,96%` |
| `2` | `80` compras, `20` vendas | `R$ 3.479,20` | `R$ 911,88` | `73,79%` |
| `3` | `60` compras, `40` vendas | `R$ 3.859,40` | `R$ 303,96` | `92,12%` |
| `4` | `50` compras, `50` vendas | `R$ 4.049,50` | `~ R$ 0 recorrente` | `~ 100%` |
| `5` | `20` compras, `80` vendas | `R$ 4.619,80` | `R$ 1.800,00` | `61,04%` |

## Como ler os cenarios

- fluxo unilateral: a pool ajuda, mas menos
- fluxo misto: o ganho cresce rapido
- fluxo equilibrado: a `Eulen` pode quase sumir do custo recorrente

O fator decisivo nao e so volume. E volume com compensacao interna entre compra e venda.

## Regra de decisao

A pool interna tende a valer a pena quando:

- o volume mensal ja e relevante
- o sistema tem os dois lados do mercado
- parte importante das compras e vendas se compensa internamente

Ela tende a nao valer a pena quando:

- o volume ainda e baixo
- o fluxo e quase todo de um lado so
- a operacao ainda nao quer carregar inventario proprio

## Conclusao

Sim, pool propria pode reduzir muito custo. Mas o ganho real vem de internalizar compra e venda e usar a `Eulen` so para o liquido.

Resumo direto:

- fluxo unilateral: ganho limitado
- fluxo misto: ganho forte
- fluxo bem compensado: ganho muito forte
