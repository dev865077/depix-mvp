# Participacao na Pool SideSwap

## Ideia

Usar capital proprio para participar diretamente do mercado/pool de `DePix` na `SideSwap`, disputando fluxo com a propria `Eulen`.

A tese e simples: se a `Eulen` ganha no spread, eu tambem posso ganhar se conseguir prover liquidez no mesmo mercado.

Formula base:

```text
lucro = volume executado x spread capturado
```

## Como funcionaria

Entrar no mesmo mercado com capital proprio e abrir ordens com spread melhor, por exemplo:

- `1,4%` em vez de `1,5%`

Se minhas ordens forem priorizadas pelo melhor preco, o fluxo pode bater em mim antes de bater na `Eulen`.

## Principal barreira economica

Para montar estoque inicial de `DePix` e para rebalancear, eu posso ter de pagar `Eulen`.

Entao a pergunta central e:

```text
quantas vezes eu consigo girar meu estoque antes de precisar rebalancear pela Eulen?
```

Se eu girar pouco, o custo da `Eulen` pesa muito. Se eu girar varias vezes, esse custo fica diluido e eu comeco a competir de verdade no spread.

## Leitura pratica

- se eu depender da `Eulen` em toda operacao, eu nao compito
- se eu usar a `Eulen` so para montar e rebalancear inventory, eu posso capturar parte do spread
- quanto maior o giro interno, mais forte fica a tese

## O que validar

- se esse mercado aceita liquidez externa
- como as ordens entram na fila de prioridade
- se o book e publico ou se existe vantagem interna da `Eulen`
- quanto do spread e realmente capturavel por um terceiro
- quantos giros eu consigo antes de precisar rebalancear

## Conclusao

Essa ideia faz sentido como brainstorm porque pode:

- ganhar no spread
- usar capital proprio para render
- reduzir dependencia do bot como unica fonte de receita

O limite nao e tecnico. E economico:

- acesso real ao mercado
- prioridade de execucao
- capacidade de rotacao
- custo de entrada e saida via `Eulen`
